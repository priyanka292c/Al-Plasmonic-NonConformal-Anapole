"""
generate_conceptual_scheme1.py
Redesigned publication-quality Scheme 1 for ACS Nano:
Conceptual distinction between prior empirical observation (Dahiya & Kumar, 2022)
and the present electrodynamic framework.

Features:
- High contrast, vivid, professional ACS Nano aesthetic
- Large, crystal-clear typography (9-13 pt, completely readable when scaled)
- Beautiful 2.5D nanocube and cross-sectional ray optics / near-field graphics
- Polished mathematical cards and clear visual hierarchy
- Perfectly tuned layout: zero overlaps, clean offsets, generous margins
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches

# Set clean publication styling
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['mathtext.fontset'] = 'dejavusans'

def create_scheme1():
    # Large, balanced canvas: 11.5 x 7.6 inches at 300 DPI
    fig = plt.figure(figsize=(11.5, 7.6), dpi=300)
    fig.patch.set_facecolor('#FFFFFF')
    
    # Grid definition: 2 rows x 3 columns with ample margins and gutters
    margin_l = 0.035
    margin_b = 0.035
    gap_x = 0.028
    gap_y = 0.045
    w_p = (1.0 - 2 * margin_l - 2 * gap_x) / 3.0   # ~0.291
    h_p = (1.0 - 2 * margin_b - gap_y) / 2.0         # ~0.442
    
    pos = {
        'a': [margin_l, margin_b + h_p + gap_y, w_p, h_p],
        'b': [margin_l + w_p + gap_x, margin_b + h_p + gap_y, w_p, h_p],
        'c': [margin_l + 2*(w_p + gap_x), margin_b + h_p + gap_y, w_p, h_p],
        'd': [margin_l, margin_b, w_p, h_p],
        'e': [margin_l + w_p + gap_x, margin_b, w_p, h_p],
        'f': [margin_l + 2*(w_p + gap_x), margin_b, w_p, h_p],
    }
    
    # -------------------------------------------------------------------------
    # Helper: Draw Panel Outer Card
    # -------------------------------------------------------------------------
    def setup_panel(rect, border_color='#94A3B8', bg_color='#FFFFFF'):
        ax = fig.add_axes(rect)
        ax.set_facecolor(bg_color)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.axis('off')
        card = patches.FancyBboxPatch((0.005, 0.005), 0.99, 0.99,
                                      boxstyle="round,pad=0.015,rounding_size=0.03",
                                      facecolor=bg_color, edgecolor=border_color,
                                      linewidth=1.4, zorder=1)
        ax.add_patch(card)
        return ax

    def draw_header_pill(ax, tag, title, pill_color='#0F172A', text_color='#FFFFFF'):
        pill = patches.FancyBboxPatch((0.03, 0.88), 0.94, 0.09,
                                      boxstyle="round,pad=0.01,rounding_size=0.025",
                                      facecolor=pill_color, edgecolor='none', zorder=2)
        ax.add_patch(pill)
        ax.text(0.06, 0.925, tag, fontsize=10.0, fontweight='bold', color='#FEF08A',
                va='center', zorder=6)
        ax.text(0.14, 0.925, title, fontsize=9.0, fontweight='bold', color=text_color,
                va='center', zorder=6)

    # =========================================================================
    # PANEL (a): Prior Empirical Observation (Dahiya & Kumar, 2022)
    # =========================================================================
    ax_a = setup_panel(pos['a'], border_color='#DC2626', bg_color='#FAFAFA')
    draw_header_pill(ax_a, '(a)', 'Prior Empirical Observation (2022)', pill_color='#991B1B')
    
    # Outer spherical mantle
    circ = patches.Circle((0.26, 0.59), 0.20, facecolor='#BAE6FD', alpha=0.45,
                          edgecolor='#0284C7', linewidth=1.5, linestyle='-', zorder=3)
    ax_a.add_patch(circ)
    
    # 2.5D Isometric nanocube (Al core)
    poly_fl = patches.Polygon([[0.17, 0.50], [0.26, 0.44], [0.26, 0.64], [0.17, 0.70]],
                              facecolor='#94A3B8', edgecolor='#1E293B', linewidth=1.2, zorder=5)
    poly_fr = patches.Polygon([[0.26, 0.44], [0.35, 0.50], [0.35, 0.70], [0.26, 0.64]],
                              facecolor='#64748B', edgecolor='#1E293B', linewidth=1.2, zorder=5)
    poly_top = patches.Polygon([[0.17, 0.70], [0.26, 0.64], [0.35, 0.70], [0.26, 0.76]],
                               facecolor='#CBD5E1', edgecolor='#1E293B', linewidth=1.2, zorder=5)
    ax_a.add_patch(poly_fl)
    ax_a.add_patch(poly_fr)
    ax_a.add_patch(poly_top)
    
    ax_a.text(0.26, 0.55, "Al Core\n100 nm", fontsize=8.0, fontweight='bold',
              color='#0F172A', ha='center', va='center', zorder=6)
    
    ax_a.text(0.26, 0.35, "Spherical Mantle\n(Non-Conformal)", fontsize=7.2,
              fontweight='bold', color='#0369A1', ha='center', va='top', zorder=6)
    
    # Arrow to plot
    ax_a.annotate("", xy=(0.55, 0.59), xytext=(0.47, 0.59),
                  arrowprops=dict(arrowstyle="-|>", color='#475569', lw=1.6, mutation_scale=10), zorder=6)
    
    # Mini empirical plot
    plot_box = patches.Rectangle((0.57, 0.40), 0.39, 0.38, facecolor='#FFFFFF',
                                 edgecolor='#94A3B8', linewidth=1.0, zorder=3)
    ax_a.add_patch(plot_box)
    
    t_pts = np.array([0.15, 0.35, 0.55, 0.75, 0.90])
    shift_pts = -(1.2*t_pts - 0.4*t_pts**2 + 0.15*t_pts**3)
    t_c = np.linspace(0.05, 0.95, 40)
    shift_c = -(1.2*t_c - 0.4*t_c**2 + 0.15*t_c**3)
    
    x_c = 0.59 + 0.35 * t_c
    y_c = 0.73 + 0.30 * (shift_c / 1.1)
    x_p = 0.59 + 0.35 * t_pts
    y_p = 0.73 + 0.30 * (shift_pts / 1.1)
    
    ax_a.plot(x_c, y_c, color='#DC2626', lw=2.2, zorder=4)
    ax_a.plot(x_p, y_p, 's', color='#DC2626', markeredgecolor='#7F1D1D', markersize=4.5, zorder=5)
    
    ax_a.text(0.76, 0.71, r"$\Delta E \propto t_{\mathrm{ox}}^3$", fontsize=9.5,
              fontweight='bold', color='#DC2626', ha='center', zorder=6)
    ax_a.text(0.76, 0.43, r"Oxide $t_{\mathrm{ox}}$ (nm)", fontsize=7.2, color='#475569', ha='center', zorder=6)
    
    # Bottom callout card
    card_a = patches.FancyBboxPatch((0.04, 0.04), 0.92, 0.24,
                                    boxstyle="round,pad=0.01,rounding_size=0.025",
                                    facecolor='#FEF2F2', edgecolor='#F87171', lw=1.1, zorder=2)
    ax_a.add_patch(card_a)
    ax_a.text(0.07, 0.22, "Dahiya & Kumar, Mater. Today Commun. (2022):",
              fontsize=7.8, fontweight='bold', color='#991B1B', va='center', zorder=6)
    ax_a.text(0.07, 0.15, "• Cubic LSPR shift observed empirically via BEM",
              fontsize=7.2, color='#7F1D1D', va='center', zorder=6)
    ax_a.text(0.07, 0.09, "• Origin of cubic scaling remained unresolved",
              fontsize=7.2, color='#7F1D1D', va='center', zorder=6)

    # =========================================================================
    # PANEL (b): Controlled Boundary Clearance Geometry
    # =========================================================================
    ax_b = setup_panel(pos['b'], border_color='#0284C7', bg_color='#FAFAFA')
    draw_header_pill(ax_b, '(b)', 'Boundary Clearance Geometry', pill_color='#0369A1')
    
    u = np.linspace(-0.36, 0.36, 100)
    facet_y = 0.43
    ax_b.plot(0.5 + u, np.full_like(u, facet_y), color='#1E293B', lw=2.5, zorder=5)
    core_block = patches.Rectangle((0.14, 0.33), 0.72, 0.10, facecolor='#E2E8F0',
                                   hatch='///', edgecolor='#94A3B8', lw=1.0, zorder=3)
    ax_b.add_patch(core_block)
    ax_b.text(0.5, 0.38, "Planar {100} Al Core Facet", fontsize=8.0, fontweight='bold',
              color='#1E293B', ha='center', va='center', zorder=6)
    
    t_ref = 0.13
    y_conf = facet_y + t_ref
    ax_b.plot(0.5 + u, np.full_like(u, y_conf), '--', color='#10B981', lw=2.0, zorder=6)
    
    y_curv = y_conf + 0.52 * (u**2)
    ax_b.plot(0.5 + u, y_curv, '-', color='#0284C7', lw=2.5, zorder=6)
    
    # Clean labels above curves with leader cues
    ax_b.text(0.84, y_curv[-1] + 0.03, r"$\kappa > 0$ (Curved)", fontsize=7.2, fontweight='bold',
              color='#0284C7', ha='center', zorder=7)
    ax_b.text(0.84, y_conf - 0.035, r"$\kappa = 0$ (Conformal)", fontsize=7.0, fontweight='bold',
              color='#047857', ha='center', zorder=7)
    
    ax_b.fill_between(0.5 + u, np.full_like(u, y_conf), y_curv, color='#38BDF8', alpha=0.35, zorder=4)
    ax_b.text(0.24, y_conf + 0.045, "Dielectric\nOverlap Wedge", fontsize=7.2, fontweight='bold',
              color='#0369A1', ha='center', va='center', zorder=6)
    
    ax_b.annotate("", xy=(0.5, y_conf), xytext=(0.5, facet_y),
                  arrowprops=dict(arrowstyle="<->", color='#D97706', lw=1.8), zorder=6)
    ax_b.text(0.52, (y_conf + facet_y)/2.0, r"$z_{\mathrm{clr}}(0,0) \equiv t$", fontsize=8.2,
              fontweight='bold', color='#B45309', va='center', zorder=7)
    
    card_b = patches.FancyBboxPatch((0.04, 0.04), 0.92, 0.24,
                                    boxstyle="round,pad=0.01,rounding_size=0.025",
                                    facecolor='#F0F9FF', edgecolor='#7DD3FC', lw=1.1, zorder=2)
    ax_b.add_patch(card_b)
    ax_b.text(0.5, 0.22, r"$z_{\mathrm{clr}}(u,v) = t + \frac{\kappa}{L}(u^2+v^2) + \frac{\kappa^3}{L^3}(u^2+v^2)^2 + \dots$",
              fontsize=8.0, fontweight='bold', color='#0369A1', ha='center', va='center', zorder=6)
    ax_b.text(0.07, 0.15, r"• Dimensionless curvature: $\kappa = L / (2R) \in [0, 0.577]$",
              fontsize=7.2, color='#0284C7', va='center', zorder=6)
    ax_b.text(0.07, 0.09, r"• Fixed apex clearance; recovers conformal as $\kappa \to 0$",
              fontsize=7.2, color='#0284C7', va='center', zorder=6)

    # =========================================================================
    # PANEL (c): Evanescent Overlap & Models
    # =========================================================================
    ax_c = setup_panel(pos['c'], border_color='#059669', bg_color='#FAFAFA')
    draw_header_pill(ax_c, '(c)', 'Evanescent Overlap & Models', pill_color='#047857')
    
    decay_box = patches.Rectangle((0.07, 0.40), 0.41, 0.44, facecolor='#FFFFFF',
                                  edgecolor='#94A3B8', linewidth=1.0, zorder=3)
    ax_c.add_patch(decay_box)
    
    z_dist = np.linspace(0, 1, 50)
    I_decay = np.exp(-2.6 * z_dist)
    x_z = 0.09 + 0.37 * z_dist
    y_z = 0.44 + 0.36 * I_decay
    
    ax_c.plot(x_z, y_z, color='#059669', lw=2.4, zorder=5)
    ax_c.fill_between(x_z, 0.44, y_z, color='#6EE7B7', alpha=0.45, zorder=4)
    ax_c.text(0.27, 0.76, r"$|\mathbf{E}_0(z)|^2 = e^{-2z/l_d}$",
              fontsize=7.5, fontweight='bold', color='#065F46', ha='center', zorder=6)
    ax_c.text(0.27, 0.43, r"Distance $z$ (nm)", fontsize=7.0, color='#334155', ha='center', zorder=6)
    
    # Model hierarchy card on right
    mod_card = patches.FancyBboxPatch((0.51, 0.40), 0.45, 0.44,
                                     boxstyle="round,pad=0.015,rounding_size=0.02",
                                     facecolor='#FFFFFF', edgecolor='#CBD5E1', lw=1.1, zorder=3)
    ax_c.add_patch(mod_card)
    ax_c.text(0.735, 0.78, "Model Hierarchy", fontsize=8.0, fontweight='bold',
              color='#0F172A', ha='center', zorder=6)
    
    # Model A pill
    pill_mA = patches.FancyBboxPatch((0.53, 0.60), 0.41, 0.14,
                                     boxstyle="round,pad=0.01,rounding_size=0.02",
                                     facecolor='#EFF6FF', edgecolor='#93C5FD', lw=0.9, zorder=4)
    ax_c.add_patch(pill_mA)
    ax_c.text(0.735, 0.68, "Model A: Closed-Form", fontsize=7.2, fontweight='bold', color='#1D4ED8', ha='center', zorder=6)
    ax_c.text(0.735, 0.63, r"$\bar{l}_d = 24.8$ nm $\rightarrow <3.9\%$ Error", fontsize=6.8, color='#1E40AF', ha='center', zorder=6)
    
    # Model B pill
    pill_mB = patches.FancyBboxPatch((0.53, 0.43), 0.41, 0.14,
                                     boxstyle="round,pad=0.01,rounding_size=0.02",
                                     facecolor='#ECFDF5', edgecolor='#6EE7B7', lw=0.9, zorder=4)
    ax_c.add_patch(pill_mB)
    ax_c.text(0.735, 0.51, "Model B: Field-Informed", fontsize=7.2, fontweight='bold', color='#047857', ha='center', zorder=6)
    ax_c.text(0.735, 0.46, r"2D $|\mathbf{E}_0|^2, l_d(x,y) \rightarrow \mathbf{<1.2\%}$", fontsize=6.8, color='#065F46', ha='center', zorder=6)
    
    card_c = patches.FancyBboxPatch((0.04, 0.04), 0.92, 0.24,
                                    boxstyle="round,pad=0.01,rounding_size=0.025",
                                    facecolor='#ECFDF5', edgecolor='#6EE7B7', lw=1.1, zorder=2)
    ax_c.add_patch(card_c)
    ax_c.text(0.5, 0.22, r"$\Delta\omega \approx -\frac{\Delta\varepsilon}{2 U_{\mathrm{mode}}} \iint_A |\mathbf{E}_0|^2 \left[1 - e^{-2 z_{\mathrm{clr}}/l_d}\right] dA$",
              fontsize=8.0, fontweight='bold', color='#047857', ha='center', va='center', zorder=6)
    ax_c.text(0.07, 0.15, r"• Normalization: Empirical Palik spline ($d[\omega\varepsilon_1]/d\omega \approx 14.82$)",
              fontsize=7.2, color='#065F46', va='center', zorder=6)
    ax_c.text(0.07, 0.09, r"• Damped Drude ($15.12$) is within $2.0\%$ ($\Delta U_{\mathrm{mode}} \approx 1.1\%$)",
              fontsize=7.2, color='#065F46', va='center', zorder=6)

    # =========================================================================
    # PANEL (d): Two Separable Mechanisms
    # =========================================================================
    ax_d = setup_panel(pos['d'], border_color='#7C3AED', bg_color='#FAFAFA')
    draw_header_pill(ax_d, '(d)', 'Two Separable Mechanisms', pill_color='#6D28D9')
    
    card_m1 = patches.FancyBboxPatch((0.05, 0.48), 0.90, 0.36,
                                     boxstyle="round,pad=0.015,rounding_size=0.025",
                                     facecolor='#F5F3FF', edgecolor='#C4B5FD', lw=1.3, zorder=3)
    ax_d.add_patch(card_m1)
    ax_d.text(0.08, 0.77, "Mechanism 1: 1D Intrinsic Sampling", fontsize=8.5,
              fontweight='bold', color='#5B21B6', va='center', zorder=6)
    ax_d.text(0.08, 0.67, r"$1 - e^{-2t/l_d} = \frac{2t}{l_d} - \frac{2t^2}{l_d^2} + \frac{4t^3}{3l_d^3} - \dots$",
              fontsize=8.2, fontweight='bold', color='#6D28D9', va='center', zorder=6)
    ax_d.text(0.08, 0.58, "• Inherent to localized exponential near-field decay",
              fontsize=7.2, color='#4C1D95', va='center', zorder=6)
    ax_d.text(0.08, 0.52, "• Present in all coatings (even flat conformal shells)",
              fontsize=7.2, fontweight='bold', color='#4C1D95', va='center', zorder=6)
    
    card_m2 = patches.FancyBboxPatch((0.05, 0.05), 0.90, 0.39,
                                     boxstyle="round,pad=0.015,rounding_size=0.025",
                                     facecolor='#FFFBEB', edgecolor='#FCD34D', lw=1.3, zorder=3)
    ax_d.add_patch(card_m2)
    ax_d.text(0.08, 0.37, "Mechanism 2: 2D/3D Curvature Modulation", fontsize=8.5,
              fontweight='bold', color='#B45309', va='center', zorder=6)
    ax_d.text(0.08, 0.27, r"$\partial^2 z_{\mathrm{clr}} / \partial t^2 \neq 0, \quad \partial^3 z_{\mathrm{clr}} / \partial t^3 \neq 0$",
              fontsize=8.2, fontweight='bold', color='#92400E', va='center', zorder=6)
    ax_d.text(0.08, 0.18, "• Clearance derivatives couple into overlap integral",
              fontsize=7.2, color='#78350F', va='center', zorder=6)
    ax_d.text(0.08, 0.11, r"• Amplifies terms: $|a_2/a_1| \mathbf{+82.4\%}$, $|a_3/a_1| \mathbf{+167.6\%}$",
              fontsize=7.2, fontweight='bold', color='#78350F', va='center', zorder=6)

    # =========================================================================
    # PANEL (e): Curvature Control: \kappa = L/(2R)
    # =========================================================================
    ax_e = setup_panel(pos['e'], border_color='#1D4ED8', bg_color='#FAFAFA')
    draw_header_pill(ax_e, '(e)', r'Curvature Control: $\kappa = L/(2R)$', pill_color='#1E40AF')
    
    sweep_box = patches.Rectangle((0.10, 0.36), 0.80, 0.46, facecolor='#FFFFFF',
                                  edgecolor='#94A3B8', linewidth=1.0, zorder=3)
    ax_e.add_patch(sweep_box)
    
    k_vals = np.linspace(0, 0.577, 50)
    # Quadratic smooth curve
    a3_scale = 1.0 + 1.676 * (k_vals / 0.577)**1.3
    
    x_sw = 0.14 + 0.72 * (k_vals / 0.577)
    y_sw = 0.40 + 0.38 * ((a3_scale - 1.0) / 1.676)
    
    ax_e.plot(x_sw, y_sw, color='#1D4ED8', lw=2.6, zorder=5)
    ax_e.fill_between(x_sw, 0.40, y_sw, color='#93C5FD', alpha=0.35, zorder=4)
    
    # Conformal limit marker
    ax_e.plot(x_sw[0], y_sw[0], 'o', color='#10B981', markeredgecolor='#065F46', markersize=7.0, zorder=6)
    ax_e.text(x_sw[0] + 0.04, y_sw[0] + 0.10, r"$\kappa=0$ (Conformal Limit)" + "\n" + r"$a_3 \to a_{3,\mathrm{conf}}$",
              fontsize=7.2, fontweight='bold', color='#047857', zorder=7)
    
    # Max curvature marker
    ax_e.plot(x_sw[-1], y_sw[-1], 's', color='#DC2626', markeredgecolor='#991B1B', markersize=7.0, zorder=6)
    ax_e.text(x_sw[-1] - 0.05, y_sw[-1] - 0.07, r"$\kappa=0.577$ (Max Curvature)" + "\n" + r"$\mathbf{+167.6\%}$ Enhancement",
              fontsize=7.2, fontweight='bold', color='#991B1B', ha='right', zorder=7)
    
    ax_e.text(0.50, 0.38, r"Dimensionless Curvature $\kappa = L / (2R)$", fontsize=7.5,
              fontweight='bold', color='#334155', ha='center', zorder=6)
    ax_e.text(0.08, 0.60, r"Normalized $a_3(\kappa) / a_{3,\mathrm{conf}}$", fontsize=7.5,
              fontweight='bold', color='#1E40AF', rotation=90, va='center', zorder=6)
    
    card_e = patches.FancyBboxPatch((0.04, 0.04), 0.92, 0.24,
                                    boxstyle="round,pad=0.01,rounding_size=0.025",
                                    facecolor='#EFF6FF', edgecolor='#93C5FD', lw=1.1, zorder=2)
    ax_e.add_patch(card_e)
    ax_e.text(0.5, 0.22, r"Universal Scaling: $\xi = t_{\mathrm{ox}}/\bar{l}_d$ (1D), $\; \kappa = L/(2R)$ (2D)",
              fontsize=8.0, fontweight='bold', color='#1D4ED8', ha='center', va='center', zorder=6)
    ax_e.text(0.07, 0.15, r"• Maps diverse geometries onto common scaling law",
              fontsize=7.2, color='#1E40AF', va='center', zorder=6)
    ax_e.text(0.07, 0.09, r"• Continuous recovery of conformal limit as $\kappa \to 0$",
              fontsize=7.2, color='#1E40AF', va='center', zorder=6)

    # =========================================================================
    # PANEL (f): Quasi-Anapole Response (5.02 eV)
    # =========================================================================
    ax_f = setup_panel(pos['f'], border_color='#DC2626', bg_color='#FAFAFA')
    draw_header_pill(ax_f, '(f)', 'Quasi-Anapole Response (5.02 eV)', pill_color='#B91C1C')
    
    np_box = patches.Rectangle((0.07, 0.40), 0.41, 0.44, facecolor='#FFFFFF',
                               edgecolor='#94A3B8', linewidth=1.0, zorder=3)
    ax_f.add_patch(np_box)
    
    # Electric dipole arrow (red, upward)
    ax_f.annotate("", xy=(0.17, 0.78), xytext=(0.17, 0.48),
                  arrowprops=dict(arrowstyle="->,head_width=0.35,head_length=0.45", color='#DC2626', lw=2.5), zorder=5)
    ax_f.text(0.15, 0.63, r"$\mathbf{p}$", fontsize=10.0, fontweight='bold', color='#DC2626', ha='right', zorder=6)
    
    # Toroidal dipole circulation
    arc_l = patches.Arc((0.34, 0.63), 0.15, 0.24, angle=0, theta1=90, theta2=270,
                        color='#059669', lw=2.0, linestyle='-', zorder=4)
    arc_r = patches.Arc((0.34, 0.63), 0.15, 0.24, angle=0, theta1=270, theta2=90,
                        color='#059669', lw=2.0, linestyle='-', zorder=4)
    ax_f.add_patch(arc_l)
    ax_f.add_patch(arc_r)
    
    # Toroidal dipole arrow (downward, opposing p)
    ax_f.annotate("", xy=(0.34, 0.48), xytext=(0.34, 0.78),
                  arrowprops=dict(arrowstyle="->,head_width=0.35,head_length=0.45", color='#059669', lw=2.5), zorder=5)
    ax_f.text(0.36, 0.63, r"$-ik n_b \mathbf{T}$", fontsize=8.5, fontweight='bold', color='#059669', ha='left', zorder=6)
    
    ax_f.text(0.275, 0.44, r"Destructive: $\Delta\phi = 174.2^\circ$", fontsize=6.8,
              fontweight='bold', color='#1E293B', ha='center', zorder=6)
    
    # Multipolar power card
    chan_box = patches.FancyBboxPatch((0.51, 0.40), 0.45, 0.44,
                                      boxstyle="round,pad=0.015,rounding_size=0.02",
                                      facecolor='#FFFFFF', edgecolor='#CBD5E1', lw=1.1, zorder=3)
    ax_f.add_patch(chan_box)
    ax_f.text(0.735, 0.78, "Power Channels at 5.02 eV", fontsize=7.5, fontweight='bold',
              color='#0F172A', ha='center', zorder=4)
    
    ax_f.text(0.54, 0.68, r"Octupole ($P_{E3}$):", fontsize=7.0, color='#1E293B', zorder=6)
    ax_f.text(0.93, 0.68, r"$\mathbf{92.9\%}$", fontsize=7.5, fontweight='bold', color='#0284C7', ha='right', zorder=6)
    
    ax_f.text(0.54, 0.59, r"Quadrupole ($P_{E2}$):", fontsize=7.0, color='#1E293B', zorder=6)
    ax_f.text(0.93, 0.59, r"$4.1\%$", fontsize=7.2, color='#64748B', ha='right', zorder=6)
    
    ax_f.text(0.54, 0.50, r"Magnetic ($P_{M1}$):", fontsize=7.0, color='#1E293B', zorder=6)
    ax_f.text(0.93, 0.50, r"$2.4\%$", fontsize=7.2, color='#64748B', ha='right', zorder=6)
    
    ax_f.text(0.54, 0.43, r"Dipolar ($P_{p+ikT}$):", fontsize=7.0, color='#DC2626', fontweight='bold', zorder=6)
    ax_f.text(0.93, 0.43, r"$\mathbf{<0.7\%}$", fontsize=7.2, fontweight='bold', color='#DC2626', ha='right', zorder=6)
    
    card_f = patches.FancyBboxPatch((0.04, 0.04), 0.92, 0.24,
                                    boxstyle="round,pad=0.01,rounding_size=0.025",
                                    facecolor='#FEF2F2', edgecolor='#F87171', lw=1.1, zorder=2)
    ax_f.add_patch(card_f)
    ax_f.text(0.5, 0.22, r"Coherent Dipolar Channel Suppression: $>99.3\%$",
              fontsize=8.2, fontweight='bold', color='#991B1B', ha='center', va='center', zorder=6)
    ax_f.text(0.07, 0.15, r"• $\mathbf{p} \approx -ik n_b \mathbf{T}$ cancellation unmasks octupole ($92.9\%$)",
              fontsize=7.2, color='#7F1D1D', va='center', zorder=6)
    ax_f.text(0.07, 0.09, r"• Establishes electric–toroidal quasi-anapole-like state",
              fontsize=7.2, color='#7F1D1D', va='center', zorder=6)
    
    # Save outputs
    out_dir = "manuscript_figures"
    os.makedirs(out_dir, exist_ok=True)
    pdf_path = os.path.join(out_dir, "Scheme1_conceptual_framework.pdf")
    png_path = os.path.join(out_dir, "Scheme1_conceptual_framework.png")
    
    plt.savefig(pdf_path, dpi=300, bbox_inches='tight', pad_inches=0.03)
    plt.savefig(png_path, dpi=300, bbox_inches='tight', pad_inches=0.03)
    plt.close(fig)
    print(f"Successfully generated {pdf_path} and {png_path}")

if __name__ == '__main__':
    create_scheme1()
