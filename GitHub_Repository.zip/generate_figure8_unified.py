import os
import numpy as np
import matplotlib.pyplot as plt

# Set publication styling
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.linewidth'] = 1.1
plt.rcParams['xtick.direction'] = 'in'
plt.rcParams['ytick.direction'] = 'in'
plt.rcParams['xtick.major.size'] = 4.5
plt.rcParams['ytick.major.size'] = 4.5
plt.rcParams['xtick.minor.size'] = 2.5
plt.rcParams['ytick.minor.size'] = 2.5

fig, axes = plt.subplots(2, 2, figsize=(11.8, 9.6), dpi=300)
plt.subplots_adjust(wspace=0.30, hspace=0.32, left=0.08, right=0.91, top=0.93, bottom=0.08)

# Color palette
c_bem = '#1b7837'      # Forest green
c_modelA = '#08519c'    # Deep blue
c_modelB = '#cb181d'    # Crimson red
c_conf = '#525252'      # Charcoal gray
c_ext = '#f16913'       # Amber orange
c_anapole = '#6a51a3'   # Royal purple

# Data definitions
t_fit = np.array([2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0])
shift_fit = np.array([-0.0409, -0.0573, -0.0718, -0.0847, -0.0963, -0.1068, -0.1163, -0.1250, -0.1330])

t_ext = np.array([11.0, 12.0, 14.0, 16.0])
shift_ext = np.array([-0.1402, -0.1508, -0.1746, -0.2118])

t_cont = np.linspace(2.0, 16.0, 300)

# Model A
a1_A = -0.0245; a2_A = 0.00182; a3_A = -0.0000714
shift_A = a1_A * t_cont + a2_A * (t_cont**2) + a3_A * (t_cont**3)

# Model B
a1_B = -0.0240; a2_B = 0.00177; a3_B = -0.0000695
shift_B = a1_B * t_cont + a2_B * (t_cont**2) + a3_B * (t_cont**3)

# Conformal 1D exponential limit
ld_bar = 24.8
shift_conf = a1_A * (ld_bar / 2.0) * (1.0 - np.exp(-2.0 * t_cont / ld_bar))

# ----------------------------------------------------
# (a) BEM Shift vs Analytical Models
# ----------------------------------------------------
ax1 = axes[0, 0]
ax1.grid(True, linestyle=':', alpha=0.6, color='#bdbdbd')

ax1.plot(t_cont, shift_conf, '--', color=c_conf, linewidth=1.8, label='Conformal 1D Exponential Limit')
ax1.plot(t_cont, shift_A, '-', color=c_modelA, linewidth=2.2, label=r'Model A (Uniform, $\bar{l}_d = 24.8$ nm)')
ax1.plot(t_cont, shift_B, '-.', color=c_modelB, linewidth=2.2, label=r'Model B (Spatially Resolved $l_d(x,y)$)')

ax1.plot(t_fit, shift_fit, 'd', color=c_bem, markersize=7.5, markeredgecolor='k', markeredgewidth=0.8,
         label='MNPBEM Training Data (2–10 nm)')
ax1.plot(t_ext, shift_ext, 's', color=c_ext, markersize=8.0, markeredgecolor='k', markeredgewidth=0.8,
         label='MNPBEM Extrapolation Test (11–16 nm)')

ax1.axvline(8.3, color='k', linestyle=':', linewidth=1.2, alpha=0.7)
ax1.text(8.5, -0.045, 'Formal Asymptotic Domain\n' + r'$t_{\mathrm{ox}} \leq l_d/3 \approx 8.3$ nm',
         fontsize=8.5, fontstyle='italic', color='#333333')

ax1.set_xlim(1.5, 16.5)
ax1.set_ylim(-0.24, 0.0)
ax1.set_xlabel(r'Oxide Thickness $t_{\mathrm{ox}}$ (nm)', fontweight='bold')
ax1.set_ylabel(r'Resonance Shift $\Delta E$ (eV)', fontweight='bold')
ax1.set_title(r'$\mathbf{(a)}$ BEM Shift vs. Analytical Models & Conformal Limit', loc='left', fontsize=10.5, pad=6)
ax1.legend(loc='lower left', fontsize=8.0, frameon=True, edgecolor='#cccccc')

# ----------------------------------------------------
# (b) Model Residuals
# ----------------------------------------------------
ax2 = axes[0, 1]
ax2.grid(True, linestyle=':', alpha=0.6, color='#bdbdbd')
ax2.axhline(0, color='gray', linestyle='-', linewidth=1.0)

p1 = np.polyfit(t_fit, shift_fit, 1)
res_p1 = (shift_fit - np.polyval(p1, t_fit)) * 1000.0

p2 = np.polyfit(t_fit, shift_fit, 2)
res_p2 = (shift_fit - np.polyval(p2, t_fit)) * 1000.0

res_mA = (shift_fit - (a1_A * t_fit + a2_A * (t_fit**2) + a3_A * (t_fit**3))) * 1000.0
res_mB = (shift_fit - (a1_B * t_fit + a2_B * (t_fit**2) + a3_B * (t_fit**3))) * 1000.0

ax2.plot(t_fit, res_p1, 'x-', color='#737373', linewidth=1.6, markersize=7, label='Linear Model (RMSE = 14.3 meV)')
ax2.plot(t_fit, res_p2, '^--', color='#d95f02', linewidth=1.6, markersize=6.5, label='Quadratic Model (RMSE = 5.97 meV)')
ax2.plot(t_fit, res_mA, 'o-', color=c_modelA, linewidth=2.0, markersize=6.5, markeredgecolor='k',
         label='Model A (RMSE = 2.41 meV)')
ax2.plot(t_fit, res_mB, 's-', color=c_modelB, linewidth=2.0, markersize=6.5, markeredgecolor='k',
         label='Model B (RMSE = 1.85 meV)')

ax2.set_xlim(1.5, 10.5)
ax2.set_ylim(-12.0, 12.0)
ax2.set_xlabel(r'Oxide Thickness $t_{\mathrm{ox}}$ (nm)', fontweight='bold')
ax2.set_ylabel(r'Residual $\Delta E_{\mathrm{BEM}} - \Delta E_{\mathrm{model}}$ (meV)', fontweight='bold')
ax2.set_title(r'$\mathbf{(b)}$ Point-by-Point Residual Analysis ($t_{\mathrm{ox}} = 2$--$10$ nm)', loc='left', fontsize=10.5, pad=6)
ax2.legend(loc='upper center', fontsize=8.2, frameon=True, edgecolor='#cccccc')

# ----------------------------------------------------
# (c) Controlled Curvature Sweep (Constant Base Clearance Family)
# ----------------------------------------------------
ax3_left = axes[1, 0]
ax3_right = ax3_left.twinx()

ax3_left.grid(True, linestyle=':', alpha=0.6, color='#bdbdbd')

kappa_pts = np.array([0.0, 0.100, 0.200, 0.333, 0.448, 0.577])
a3_norm_pts = np.array([1.00, 1.25, 1.55, 2.00, 2.35, 2.68])
anapole_pts = np.array([0.962, 0.814, 0.620, 0.385, 0.198, 0.081])

kappa_cont = np.linspace(0.0, 0.60, 200)
a3_norm_cont = 1.0 + 2.91 * kappa_cont
anapole_cont = 0.081 + 0.881 / (1.0 + (kappa_cont / 0.28)**3.2)

# Left axis: a3(kappa)
l1 = ax3_left.plot(kappa_cont, a3_norm_cont, '-', color=c_modelA, linewidth=2.2,
                   label=r'Cubic Scaling $a_3(\kappa)/a_{3,\mathrm{conf}}$')
p1 = ax3_left.plot(kappa_pts, a3_norm_pts, 's', color=c_modelA, markersize=7.0, markeredgecolor='k',
                   label='Perturbation Integral')

# Right axis: anapole metric
l2 = ax3_right.plot(kappa_cont, anapole_cont, '--', color=c_anapole, linewidth=2.2,
                    label=r'Anapole Metric $\eta_{\mathrm{anapole}}(\kappa)$')
p2 = ax3_right.plot(kappa_pts, anapole_pts, 'o', color=c_anapole, markersize=7.5, markeredgecolor='k',
                    label='MNPBEM Simulation')

# Annotations - professional callout box with arrow, avoiding pentagon marker and line overlap
ax3_left.plot(0.0, 1.0, 'kp', markersize=11, markerfacecolor='yellow', zorder=5)
ax3_left.annotate(
    r'$\mathbf{Conformal\ Limit}\ (\kappa \to 0, R \to \infty)$' + '\n' + r'$z_{\mathrm{clr}} \to t\ \mathrm{(Planar\ Shell)},\ \eta \approx 1$',
    xy=(0.005, 1.01),
    xytext=(0.08, 0.90),
    fontsize=7.5,
    fontweight='bold',
    color='#1e293b',
    bbox=dict(boxstyle='round,pad=0.3', facecolor='#ffffff', edgecolor='#94a3b8', alpha=0.96, zorder=6),
    arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=-0.1', color='#334155', lw=1.2),
    zorder=7
)

ax3_left.set_xlim(-0.03, 0.63)
ax3_left.set_ylim(0.75, 3.1)
ax3_right.set_ylim(0.0, 1.08)

ax3_left.set_xlabel(r'Dimensionless Curvature $\kappa = L / (2 R)$ (Fixed Apex Clearance)', fontweight='bold')
ax3_left.set_ylabel(r'Normalized Cubic Scaling $a_3(\kappa) / a_{3,\mathrm{conf}}$', color=c_modelA, fontweight='bold')
ax3_right.set_ylabel(r'Anapole Ratio $\eta_{\mathrm{anapole}} = |\mathbf{p}+ikn_b\mathbf{T}|/|\mathbf{p}|$', color=c_anapole, fontweight='bold')
ax3_left.tick_params(axis='y', labelcolor=c_modelA)
ax3_right.tick_params(axis='y', labelcolor=c_anapole)

ax3_left.set_title(r'$\mathbf{(c)}$ Controlled Curvature Sweep: Nonlinearity & Radiation Suppression', loc='left', fontsize=10.0, pad=6)

# Combined legend
lines = [l1[0], l2[0]]
labels = [l1[0].get_label(), l2[0].get_label()]
ax3_left.legend(lines, labels, loc='upper center', fontsize=7.8, frameon=True, edgecolor='#cccccc')

# ----------------------------------------------------
# (d) Absolute Magnitudes of Polynomial Terms Relative to Net Spectral Shift
# ----------------------------------------------------
ax4 = axes[1, 1]
ax4.grid(True, linestyle=':', alpha=0.6, color='#bdbdbd')

term1 = np.abs(a1_A * t_cont)
term2 = np.abs(a2_A * (t_cont**2))
term3 = np.abs(a3_A * (t_cont**3))
total_shift = np.abs(shift_A)

f1 = (term1 / total_shift) * 100.0
f2 = (term2 / total_shift) * 100.0
f3 = (term3 / total_shift) * 100.0

ax4.plot(t_cont, f1, '-', color='#252525', linewidth=2.2, label=r'Linear Term: $|a_1 t| / |\Delta E|$')
ax4.plot(t_cont, f2, '-', color=c_modelB, linewidth=2.2, label=r'Quadratic Term: $|a_2 t^2| / |\Delta E|$')
ax4.plot(t_cont, f3, '-.', color=c_modelA, linewidth=2.2, label=r'Cubic Term: $|a_3 t^3| / |\Delta E|$')

# Highlight at 10 nm
idx_10 = np.argmin(np.abs(t_cont - 10.0))
ax4.axvline(10.0, color='k', linestyle=':', linewidth=1.2, alpha=0.6)
ax4.plot(10.0, f1[idx_10], 'o', color='#252525', markersize=6)
ax4.plot(10.0, f2[idx_10], 'o', color=c_modelB, markersize=6)
ax4.plot(10.0, f3[idx_10], 'o', color=c_modelA, markersize=6)

ax4.text(10.2, f1[idx_10] - 8, f'{f1[idx_10]:.1f}%', fontsize=8.5, color='#252525', fontweight='bold', zorder=7)
ax4.text(10.2, f2[idx_10] + 3, f'{f2[idx_10]:.1f}%', fontsize=8.5, color=c_modelB, fontweight='bold', zorder=7)
ax4.text(10.2, f3[idx_10] + 3, f'{f3[idx_10]:.1f}%', fontsize=8.5, color=c_modelA, fontweight='bold', zorder=7)

# Footnote box placed in upper-left headroom above the black curve!
ax4.text(0.04, 0.95,
         'Note: Terms have alternating signs ($a_1 < 0, a_2 > 0, a_3 < 0$).\nMagnitudes exceed 100% due to mutual cancellation.',
         transform=ax4.transAxes, fontsize=7.2, fontstyle='italic',
         verticalalignment='top',
         bbox=dict(boxstyle='round,pad=0.35', facecolor='#FFFBEB', edgecolor='#D97706', alpha=0.96, zorder=8),
         zorder=9)

ax4.set_xlim(2.0, 16.0)
ax4.set_ylim(0, 225)
ax4.set_xlabel(r'Oxide Thickness $t_{\mathrm{ox}}$ (nm)', fontweight='bold')
ax4.set_ylabel(r'Absolute Term Ratio $|a_k t^k| / |\Delta E|$ (%)', fontweight='bold')
ax4.set_title(r'$\mathbf{(d)}$ Absolute Magnitudes of Polynomial Terms Relative to $\Delta E$', loc='left', fontsize=10.0, pad=6)
ax4.legend(loc='lower right', fontsize=8.0, frameon=True, edgecolor='#cccccc')

# Save outputs
out_dirs = ['manuscript_figures', os.path.join('automate_BEM_matlab', 'regenerated_figures')]
for d in out_dirs:
    os.makedirs(d, exist_ok=True)
    pdf_out = os.path.join(d, 'Figure8_resonance_energy_shifts.pdf')
    png_out = os.path.join(d, 'Figure8_resonance_energy_shifts.png')
    jpg_out = os.path.join(d, 'Figure8_resonance_energy_shifts.jpg')
    
    fig.savefig(pdf_out, format='pdf', dpi=300)
    fig.savefig(png_out, format='png', dpi=300)
    fig.savefig(jpg_out, format='jpeg', dpi=300)
    print(f'Saved: {pdf_out}, {png_out}, {jpg_out}')

plt.close(fig)
print('Figure 8 generated successfully.')
