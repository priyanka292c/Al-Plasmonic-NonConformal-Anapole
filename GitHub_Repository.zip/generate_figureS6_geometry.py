import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import numpy as np
import os

# Output directory
out_dir = r"d:/Priyanka/Research/Submitted/Working/Anu work/Anu work/manuscript_figures"
os.makedirs(out_dir, exist_ok=True)

fig = plt.figure(figsize=(14, 10), dpi=300)

# Colors
c_facet = '#3b82f6'    # Blue for facet caps
c_edge = '#10b981'     # Emerald for edge fillets
c_corner = '#f59e0b'   # Amber for corner octants
c_core = '#6b7280'     # Gray for metal core

L = 100.0  # nm
half_L = L / 2.0  # 50 nm
t = 4.0    # nm apex clearance

# Function to generate facet cap points
def get_facet_cap(R, L_val, t_val, n=15):
    u = np.linspace(-L_val/2, L_val/2, n)
    v = np.linspace(-L_val/2, L_val/2, n)
    U, V = np.meshgrid(u, v)
    if np.isinf(R):
        Z = np.full_like(U, half_L + t_val)
    else:
        rad = np.maximum(R**2 - U**2 - V**2, 0.0)
        Z = half_L + t_val + R - np.sqrt(rad)
    return U, V, Z

# Function to generate edge fillet (+z, +x edge)
def get_edge_fillet(R, L_val, t_val, n_u=15, n_th=10):
    y = np.linspace(-L_val/2, L_val/2, n_u)
    theta = np.linspace(0, np.pi/2, n_th)
    Y, TH = np.meshgrid(y, theta)
    if np.isinf(R):
        rho = np.full_like(Y, t_val)
    else:
        rad = np.maximum(R**2 - (L_val/2)**2 - Y**2, 0.0)
        rho = t_val + R - np.sqrt(rad)
    X = half_L + rho * np.cos(TH)
    Z = half_L + rho * np.sin(TH)
    return X, Y, Z

# Subplot (a): 26-Patch Watertight Assembly Schematic
ax1 = fig.add_subplot(2, 2, 1, projection='3d')
ax1.set_title('(a) 26-Patch Watertight Boundary Decomposition', fontsize=11, fontweight='bold', pad=10)

# Render Core
def plot_cube(ax, size, color, alpha=0.3):
    r = [-size/2, size/2]
    X, Y = np.meshgrid(r, r)
    ax.plot_surface(X, Y, np.full_like(X, size/2), color=color, alpha=alpha)
    ax.plot_surface(X, Y, np.full_like(X, -size/2), color=color, alpha=alpha)
    ax.plot_surface(X, np.full_like(X, size/2), Y, color=color, alpha=alpha)
    ax.plot_surface(X, np.full_like(X, -size/2), Y, color=color, alpha=alpha)
    ax.plot_surface(np.full_like(X, size/2), X, Y, color=color, alpha=alpha)
    ax.plot_surface(np.full_like(X, -size/2), X, Y, color=color, alpha=alpha)

plot_cube(ax1, L, c_core, alpha=0.25)

# Render 6 facet caps for kappa = 0.577 (R = 86.6 nm)
R_val = 86.60
U, V, Z_top = get_facet_cap(R_val, L, t)
ax1.plot_surface(U, V, Z_top, color=c_facet, alpha=0.65, edgecolor='none')
ax1.plot_surface(U, V, -Z_top, color=c_facet, alpha=0.65, edgecolor='none')
ax1.plot_surface(Z_top, U, V, color=c_facet, alpha=0.65, edgecolor='none')
ax1.plot_surface(-Z_top, U, V, color=c_facet, alpha=0.65, edgecolor='none')
ax1.plot_surface(U, Z_top, V, color=c_facet, alpha=0.65, edgecolor='none')
ax1.plot_surface(U, -Z_top, V, color=c_facet, alpha=0.65, edgecolor='none')

# Render representative edge fillet
X_e, Y_e, Z_e = get_edge_fillet(R_val, L, t)
ax1.plot_surface(X_e, Y_e, Z_e, color=c_edge, alpha=0.8, edgecolor='none')
ax1.plot_surface(-X_e, Y_e, Z_e, color=c_edge, alpha=0.8, edgecolor='none')
ax1.plot_surface(X_e, Y_e, -Z_e, color=c_edge, alpha=0.8, edgecolor='none')
ax1.plot_surface(-X_e, Y_e, -Z_e, color=c_edge, alpha=0.8, edgecolor='none')

ax1.set_xlim([-75, 75]); ax1.set_ylim([-75, 75]); ax1.set_zlim([-75, 75])
ax1.set_xlabel('x (nm)', fontsize=8); ax1.set_ylabel('y (nm)', fontsize=8); ax1.set_zlabel('z (nm)', fontsize=8)
ax1.view_init(elev=25, azim=40)

# Custom legend for (a)
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
legend_elements = [
    Patch(facecolor=c_facet, edgecolor='k', label='6 Facet Caps $z_{\\rm clr}(u,v)$'),
    Patch(facecolor=c_edge, edgecolor='k', label='12 Edge Fillets $\\rho(u)$'),
    Patch(facecolor=c_corner, edgecolor='k', label='8 Corner Octants $r_{\\rm crn}$'),
    Patch(facecolor=c_core, edgecolor='k', alpha=0.4, label='Al Nanocube Core ($L=100$ nm)')
]
ax1.legend(handles=legend_elements, loc='upper left', fontsize=7.5, framealpha=0.9)

# Subplot (b): Closed Geometry at kappa = 0 (Conformal Limit, R -> inf)
ax2 = fig.add_subplot(2, 2, 2, projection='3d')
ax2.set_title(r'(b) Planar Conformal Limit ($\kappa = 0$, $R \to \infty$)', fontsize=11, fontweight='bold', pad=10)
plot_cube(ax2, L, c_core, alpha=0.2)
plot_cube(ax2, L + 2*t, c_facet, alpha=0.5)
ax2.set_xlim([-75, 75]); ax2.set_ylim([-75, 75]); ax2.set_zlim([-75, 75])
ax2.set_xlabel('x (nm)', fontsize=8); ax2.set_ylabel('y (nm)', fontsize=8); ax2.set_zlabel('z (nm)', fontsize=8)
ax2.view_init(elev=25, azim=40)
ax2.text2D(0.05, 0.90, "Uniform clearance: $z_{\\rm clr} \\equiv t = 4$ nm\nMinkowski dilation of cube", transform=ax2.transAxes, fontsize=8, color='#1e3a8a')

# Subplot (c): Closed Geometry at kappa = 0.333 (Intermediate Curvature, R = 150 nm)
ax3 = fig.add_subplot(2, 2, 3, projection='3d')
ax3.set_title(r'(c) Intermediate Curvature ($\kappa = 0.333$, $R = 150$ nm)', fontsize=11, fontweight='bold', pad=10)
plot_cube(ax3, L, c_core, alpha=0.2)
R_mid = 150.0
U_m, V_m, Z_top_m = get_facet_cap(R_mid, L, t)
ax3.plot_surface(U_m, V_m, Z_top_m, color=c_facet, alpha=0.6, edgecolor='none')
ax3.plot_surface(U_m, V_m, -Z_top_m, color=c_facet, alpha=0.6, edgecolor='none')
ax3.plot_surface(Z_top_m, U_m, V_m, color=c_facet, alpha=0.6, edgecolor='none')
ax3.plot_surface(-Z_top_m, U_m, V_m, color=c_facet, alpha=0.6, edgecolor='none')
ax3.plot_surface(U_m, Z_top_m, V_m, color=c_facet, alpha=0.6, edgecolor='none')
ax3.plot_surface(U_m, -Z_top_m, V_m, color=c_facet, alpha=0.6, edgecolor='none')
X_em, Y_em, Z_em = get_edge_fillet(R_mid, L, t)
ax3.plot_surface(X_em, Y_em, Z_em, color=c_edge, alpha=0.75, edgecolor='none')
ax3.plot_surface(-X_em, Y_em, Z_em, color=c_edge, alpha=0.75, edgecolor='none')
ax3.plot_surface(X_em, Y_em, -Z_em, color=c_edge, alpha=0.75, edgecolor='none')
ax3.plot_surface(-X_em, Y_em, -Z_em, color=c_edge, alpha=0.75, edgecolor='none')
ax3.set_xlim([-75, 75]); ax3.set_ylim([-75, 75]); ax3.set_zlim([-75, 75])
ax3.set_xlabel('x (nm)', fontsize=8); ax3.set_ylabel('y (nm)', fontsize=8); ax3.set_zlabel('z (nm)', fontsize=8)
ax3.view_init(elev=25, azim=40)
ax3.text2D(0.05, 0.90, "Apex clearance: $t = 4$ nm\nEdge clearance: $12.8$ nm", transform=ax3.transAxes, fontsize=8, color='#065f46')

# Subplot (d): Closed Geometry at kappa = 0.577 (Max Curvature, R = 86.6 nm) with Mesh Lines
ax4 = fig.add_subplot(2, 2, 4, projection='3d')
ax4.set_title(r'(d) Maximum Curvature ($\kappa = 0.577$, $R = 86.6$ nm) & Mesh', fontsize=11, fontweight='bold', pad=10)
plot_cube(ax4, L, c_core, alpha=0.2)
ax4.plot_surface(U, V, Z_top, color=c_facet, alpha=0.6, edgecolor='#1d4ed8', linewidth=0.3)
ax4.plot_surface(U, V, -Z_top, color=c_facet, alpha=0.6, edgecolor='#1d4ed8', linewidth=0.3)
ax4.plot_surface(Z_top, U, V, color=c_facet, alpha=0.6, edgecolor='#1d4ed8', linewidth=0.3)
ax4.plot_surface(-Z_top, U, V, color=c_facet, alpha=0.6, edgecolor='#1d4ed8', linewidth=0.3)
ax4.plot_surface(U, Z_top, V, color=c_facet, alpha=0.6, edgecolor='#1d4ed8', linewidth=0.3)
ax4.plot_surface(U, -Z_top, V, color=c_facet, alpha=0.6, edgecolor='#1d4ed8', linewidth=0.3)
ax4.plot_surface(X_e, Y_e, Z_e, color=c_edge, alpha=0.7, edgecolor='#047857', linewidth=0.3)
ax4.plot_surface(-X_e, Y_e, Z_e, color=c_edge, alpha=0.7, edgecolor='#047857', linewidth=0.3)
ax4.plot_surface(X_e, Y_e, -Z_e, color=c_edge, alpha=0.7, edgecolor='#047857', linewidth=0.3)
ax4.plot_surface(-X_e, Y_e, -Z_e, color=c_edge, alpha=0.7, edgecolor='#047857', linewidth=0.3)
ax4.set_xlim([-75, 75]); ax4.set_ylim([-75, 75]); ax4.set_zlim([-75, 75])
ax4.set_xlabel('x (nm)', fontsize=8); ax4.set_ylabel('y (nm)', fontsize=8); ax4.set_zlabel('z (nm)', fontsize=8)
ax4.view_init(elev=25, azim=40)
ax4.text2D(0.05, 0.90, "Apex clearance: $t = 4$ nm\nEdge clearance: $19.9$ nm\nCorner clearance: $28.9$ nm", transform=ax4.transAxes, fontsize=8, color='#9a3412')

plt.subplots_adjust(left=0.02, right=0.98, top=0.95, bottom=0.03, wspace=0.1, hspace=0.15)

# Save outputs
fig_pdf = os.path.join(out_dir, "FigureS6_3D_curvature_mesh_geometry.pdf")
fig_png = os.path.join(out_dir, "FigureS6_3D_curvature_mesh_geometry.png")
fig_jpg = os.path.join(out_dir, "FigureS6_3D_curvature_mesh_geometry.jpg")

plt.savefig(fig_pdf, bbox_inches='tight')
plt.savefig(fig_png, dpi=300, bbox_inches='tight')
plt.savefig(fig_jpg, dpi=300, bbox_inches='tight')
plt.close(fig)
print(f"Generated Figure S6 at:\n  {fig_pdf}\n  {fig_png}\n  {fig_jpg}")
