# Curvature-Modulated Nonlinear Plasmon Resonance Shifts and Quasi-Anapole Response in Non-Conformal Oxide-Coated Aluminum Nanocubes

[![Paper PDF](https://img.shields.io/badge/Manuscript-PDF%20(29%20Pages)-red?style=for-the-badge&logo=adobeacrobatreader)](./manuscript.pdf)
[![Supplementary PDF](https://img.shields.io/badge/Supplementary-PDF%20(24%20Pages)-darkred?style=for-the-badge&logo=adobeacrobatreader)](./supplementary.pdf)
[![Cover Letter](https://img.shields.io/badge/Cover%20Letter-PDF%20(2%20Pages)-teal?style=for-the-badge&logo=adobeacrobatreader)](./cover_letter.pdf)
[![Response Audit](https://img.shields.io/badge/Response%20Audit-PDF%20(25%20Pages)-purple?style=for-the-badge&logo=adobeacrobatreader)](./response_to_reviewers.pdf)
[![Graphical Abstract](https://img.shields.io/badge/TOC%20%26%20GA-Vector%20%26%20300%20DPI-blue?style=for-the-badge&logo=artstation)](./TOC_graphic.png)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg?style=for-the-badge)](https://opensource.org/licenses/MIT)

---

## 👥 Author Information

1. **Priyanka**  
   *Department of Physics & Astrophysics, University of Delhi, Delhi 110007, India*  
   *Email:* `priyanka292c@gmail.com`

2. **Ram Soorat** (*Corresponding Author)  
   *Department of School of Technologies, Woxsen University, Hyderabad, Telangana 502345, India*  
   *Email:* `rsoorat@gmail.com`

---

## 🚀 ACS Paragon Plus Submission Checklist

This repository contains the finalized submission package for **ACS Nano**. Please follow the exact submission configuration below:

### 📤 Files to Upload to ACS Paragon Plus:
1. **Manuscript File**: [`manuscript.pdf`](./manuscript.pdf) (29 pages, complete with unheaded Introduction, Results and Discussion, Conclusions, Methods at the end, 14 figures including Scheme 1, equations, and references) or LaTeX package [`manuscript.tex`](./manuscript.tex).
2. **Supporting Information**: [`supplementary.pdf`](./supplementary.pdf) (24 pages, Sections S1–S9 including the 20-row Dahiya & Kumar 2022 differentiation table, perturbation derivations, Palik primary normalization, damped Drude analysis, mesh refinement, and multipolar decomposition).
3. **Cover Letter**: [`cover_letter.pdf`](./cover_letter.pdf) (2 pages, addressed to Editor-in-Chief Prof. Xiaodong Chen, featuring complete scientific highlights and 6 suggested peer reviewers without conflicts).
4. **Table of Contents (TOC) / Graphical Abstract Graphic**: [`TOC_graphic.pdf`](./TOC_graphic.pdf) / [`TOC_graphic.png`](./TOC_graphic.png) (and [`graphical_abstract.png`](./graphical_abstract.png), formatted strictly to $3.25'' \times 1.75''$ at 300 DPI).

### ⚠️ Important Submission Note (Item 21 Audit):
* **Do NOT upload** [`response_to_reviewers.pdf`](./response_to_reviewers.pdf) to ACS Paragon Plus during initial submission.  
  *Rationale*: This is a **new submission**, not a revised manuscript. The comprehensive 25-page response document is maintained in this repository as an internal audit and technical defense reserve to address reviewer inquiries during peer review.

---

## 🎨 Table of Contents (TOC) / Graphical Abstract

<p align="center">
  <img src="./TOC_graphic.png" alt="TOC Graphic: Curvature, Nonlinear LSPR, and Electric-Toroidal Interference" width="85%"/>
</p>

*Figure TOC: Conceptual and quantitative summary linking geometric boundary curvature $\kappa = L/(2R)$, dielectric near-field overlap, nonlinear higher-order LSPR shifts, destructive electric–toroidal interference, and coherent dipolar channel suppression ($>99.3\%$) with dominant octupolar background ($P_{E3} \approx 92.9\%$).*

---

## 📖 Scientific Abstract

We develop an electrodynamic framework that separates intrinsic evanescent-field sampling from geometric modulation of higher-order localized surface plasmon resonance (LSPR) shift coefficients in non-conformal aluminum (Al) nanocubes, and relates this modulation to electric–toroidal radiation suppression. While conformal dielectric coatings produce predominantly linear resonance shifts ($\Delta E \propto t_{\text{ox}}$) in the thin-shell limit, non-conformal convex mantles enclosing cubic cores exhibit a nonlinear thickness dependence that is compactly represented by a cubic expansion ($\Delta E = \sum_{k=0}^3 a_k t_{\text{ox}}^k$) over the investigated thin-shell regime. Cavity perturbation theory based on Lorentz reciprocity reveals two physically separable contributions: 
1. **Intrinsic nonlinear sampling** of the evanescent near field ($1 - e^{-2t/l_d}$), present even in planar conformal coatings; and 
2. **Curvature-induced spatial clearance gradients** that amplify higher-order coefficients ($+167.6\%$ analytically for $|a_3/a_1|$, $+202.2\%$ in full-wave BEM).

A spatially resolved model (**Model B**) achieves quantitative agreement ($<1.2\%$ discrepancy) with retarded boundary element simulations. Within an idealized curvature family ($\kappa = L/(2R) \in [0, 0.577]$) at fixed core size and reference apex clearance ($z_{\text{clr}}(0,0,t) \equiv t$), the higher-order coefficients smoothly recover the conformal planar limit as $\kappa \to 0$. Concurrently, boundary curvature is associated with a redistribution of displacement currents into a poloidal circulation, **yielding destructive electric–toroidal dipole interference** ($\vec{p} \approx -ik n_b \vec{T}$, $\Delta\phi = 174.2^\circ$). At $5.02\text{ eV}$, this produces an electric–toroidal quasi-anapole-like state with **$>99.3\%$ suppression of the coherent electric-dipolar radiative channel**, revealing a **dominant octupolar background channel** ($P_{E3} \approx 92.9\%$).

---

## 🔬 Key Scientific & Technical Achievements

1. **Clear Novelty Positioning & Prior Art Distinction**:  
   Dahiya & Kumar (*Mater. Today Commun.* 31 (2022) 103668) first observed the empirical cubic thickness dependence. The present work provides the unresolved physical and electrodynamic origin through Lorentz-reciprocity perturbation theory and boundary curvature. A full 20-row comparative matrix is provided in Supporting Information Table S1.

2. **Analytical Perturbation Theory & Model Hierarchy**:  
   - **Model A (Averaged Clearance)**: Discrepancy $< 3.9\%$ relative to full retarded MNPBEM.
   - **Model B (Field-Informed Spatially Resolved Overlap)**: Discrepancy $< 1.2\%$ relative to full retarded MNPBEM.
   - Decoupled intrinsic decay ($1 - e^{-2t/l_d}$) from geometric curvature derivatives.

3. **Universal Dimensionless Formulation**:  
   Resonance shifts map onto a universal scaling function:
   $$\xi = \frac{t_{\text{ox}}}{\bar{l}_d}, \quad \kappa = \frac{L}{2R}, \quad \frac{\Delta E}{E_{\text{scale}}} = \mathcal{F}(\xi, \kappa)$$
   as depicted in Scheme 1 of the manuscript.

4. **Rigorous Watertight Geometry**:  
   The non-conformal mantle is represented as a watertight 26-patch conforming manifold ($C^0$-continuous, adaptive Delaunay meshing) with zero topological seams. The controlled curvature family ($\kappa \in [0, 0.577]$) provides an idealized geometry control cleanly distinguished from the complete physical PVP/$\text{Al}_2\text{O}_3$ core-shell architecture.

5. **Multipolar Analysis & Radiation Channel Suppression**:  
   At $E = 5.02\text{ eV}$, poloidal displacement currents establish destructive interference ($\mathbf{p} \approx -ik n_b \mathbf{T}$, $\Delta\phi = 174.2^\circ$), yielding $>99.3\%$ suppression of the coherent electric-dipolar radiative channel and revealing a dominant octupolar background channel ($P_{E3} \approx 92.9\%$).

6. **Statistical & Asymptotic Rigor**:  
   - $\Delta\text{AIC} \approx 1.7$ and $\Delta\text{BIC} \approx 1.9$ confirm the cubic polynomial is statistically parsimonious while properly acknowledging the quartic model remains competitive.
   - Extrapolation to $t_{\text{ox}} = 11$--$16\text{ nm}$ achieves $\text{MRE} \approx 3.22\%$, explicitly presented as numerical out-of-sample extrapolation rather than formal asymptotic validity outside the thin-shell regime.

---

## 📁 Repository Directory Structure

```text
├── manuscript.pdf                  # Final Manuscript PDF (29 pages, 14 figures incl. Scheme 1)
├── manuscript.tex                  # Primary LaTeX source
├── supplementary.pdf               # Supplementary Information PDF (24 pages, Sections S1-S9)
├── supplementary.tex               # Supplementary LaTeX source
├── cover_letter.pdf                # ACS Nano Editor Cover Letter (exact 2 pages)
├── cover_letter.tex                # Cover letter LaTeX source
├── response_to_reviewers.pdf       # Technical Audit & Rebuttal Reserve File (exact 25 pages)
├── response_to_reviewers.tex       # Response LaTeX source
├── TOC_graphic.pdf / .png / .jpg   # ACS Nano Table of Contents graphic (vector & 300 DPI)
├── graphical_abstract.pdf / .png   # Detailed Graphical Abstract
├── references.bib                  # BibTeX library (37 peer-reviewed references with DOIs)
├── ACS_Nano_Submission_Package.zip # Consolidated journal submission archive (10.6 MB)
├── GitHub_Repository.zip           # Complete GitHub-ready package (< 25 MB web upload limit)
│
├── manuscript_figures/             # High-resolution figures (PDF, PNG, JPG)
│   ├── Scheme1_conceptual_framework.pdf / .png
│   ├── Figure1_geometry_schematic.pdf / .png / .jpg
│   ├── Figure2_sphere_eels_scattering.pdf / .png / .jpg
│   ├── Figure3_sphere_colormaps_maps.pdf / .png / .jpg
│   ├── Figure4_cube_conformal_eels.pdf / .png / .jpg
│   ├── Figure5_cube_convex_eels.pdf / .png / .jpg
│   ├── Figure6_surface_charge_maps.pdf / .png / .jpg
│   ├── Figure7_optical_scattering.pdf / .png / .jpg
│   ├── Figure8_resonance_energy_shifts.pdf / .png / .jpg
│   ├── Figure9_polarization_definitions_sphere.pdf / .png / .jpg
│   ├── Figure10_conformal_nanocube_polarization.pdf / .png / .jpg
│   ├── Figure11_convex_nanocube_polarization.pdf / .png / .jpg
│   ├── Figure12_time_resolved_charge_rotation.pdf / .png / .jpg
│   └── Figure13_chiral_oblique_dichroism.pdf / .png / .jpg
│
└── automate_BEM_matlab/            # Full MNPBEM17 Automation Suite
```

---

## 📑 Supplementary Information Structure

- **Section S1:** Scope & Feature Differentiation from Dahiya & Kumar (2022) (Table S1, 20 structural parameters).
- **Section S2:** Detailed Derivation of Electrodynamic Cavity Perturbation Overlap Integrals and Two-Mechanism Decomposition.
- **Section S3:** Near-Field Evanescent Decay Length Extraction ($l_d(x,y)$) and Facet Weighting.
- **Section S4:** MNPBEM Numerical Discretization, Watertight 26-Patch Mesh, and Convergence Benchmarks.
- **Section S5:** Cartesian Multipolar Decomposition, Poloidal Currents, and Coherent Dipolar Channel Suppression ($>99.3\%$).
- **Section S6:** Information-Theoretic Model Comparison (AIC/BIC), Residual Analysis, and Numerical Extrapolation ($t_{\text{ox}} = 11$--$16\text{ nm}$).
- **Section S7:** Material Dielectric Functions, Empirical Palik Al Spline Interpolation, and Primary Mode Normalization ($d[\omega\varepsilon_1]/d\omega \approx 14.82$).
- **Section S8:** Optical Torque Upper Bounds and Mechanical Rotational Considerations (Hydrodynamic Drag & Substrate Pinning).
- **Section S9:** Supporting Polarization Dynamics, Refractive-Index Sensing, Charge Rotors, and Extrinsic Circular Dichroism (Figures S3–S6).

---

## 📜 Citation

```bibtex
@article{Priyanka2026Curvature,
  author    = {Priyanka and Soorat, Ram},
  title     = {Curvature-Modulated Nonlinear Plasmon Resonance Shifts and Quasi-Anapole Response in Non-Conformal Oxide-Coated Aluminum Nanocubes},
  journal   = {ACS Nano},
  year      = {2026},
  note      = {Submitted}
}
```

---
*Licensed under the [MIT License](./LICENSE).*
