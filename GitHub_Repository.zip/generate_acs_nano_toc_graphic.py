"""
generate_acs_nano_toc_graphic.py
Generates the official ACS Nano Table of Contents (TOC) / Abstract Graphic.
ACS Nano specifications:
- Width: ~3.25 to 3.5 inches (8.25-8.89 cm)
- Height: ~1.75 inches (4.45 cm)
- Resolution: >= 300 DPI
- Clean, minimal, high-impact 3-message layout:
  Panel 1: Non-conformal Al nanocube -> Curvature-modulated near-field overlap
  Panel 2: Nonlinear LSPR shift -> Model B: <1.2% discrepancy
  Panel 3: Electric-toroidal quasi-anapole -> >99.3% coherent dipolar channel suppression
"""

import os
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np

def create_toc_graphic():
    # ACS Nano standard dimensions in inches
    fig_width = 3.50  # inches (8.89 cm)
    fig_height = 1.75 # inches (4.45 cm)
    
    fig = plt.figure(figsize=(fig_width, fig_height), dpi=300)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 3.50)
    ax.set_ylim(0, 1.75)
    ax.axis('off')
    
    # Background card with subtle border
    bg = patches.FancyBboxPatch((0.02, 0.02), 3.46, 1.71,
                                boxstyle="round,pad=0,rounding_size=0.08",
                                facecolor="#F8FAFC", edgecolor="#CBD5E1", linewidth=0.8)
    ax.add_patch(bg)
    
    # -------------------------------------------------------------
    # Panel 1 (Left): Non-conformal Al Nanocube (x: 0.08 to 1.15)
    # -------------------------------------------------------------
    ax.text(0.60, 1.58, "Non-Conformal Mantle", fontsize=5.8, fontweight='bold',
            color='#0F172A', ha='center', va='center')
    
    # Cube core (Metallic Al)
    cube_front = patches.Rectangle((0.35, 0.45), 0.50, 0.45,
                                   facecolor='#94A3B8', edgecolor='#334155', linewidth=0.8, zorder=3)
    ax.add_patch(cube_front)
    cube_top = patches.Polygon([[0.35, 0.90], [0.55, 1.08], [1.05, 1.08], [0.85, 0.90]],
                               facecolor='#CBD5E1', edgecolor='#334155', linewidth=0.8, zorder=3)
    ax.add_patch(cube_top)
    cube_right = patches.Polygon([[0.85, 0.45], [1.05, 0.63], [1.05, 1.08], [0.85, 0.90]],
                                facecolor='#64748B', edgecolor='#334155', linewidth=0.8, zorder=3)
    ax.add_patch(cube_right)
    
    ax.text(0.60, 0.67, "Al Core\n100 nm", fontsize=5.2, fontweight='bold',
            color='#0F172A', ha='center', va='center', zorder=4)
    
    # Curved convex dielectric mantle
    theta = np.linspace(0, np.pi, 100)
    arc_x = 0.60 + 0.42 * np.cos(theta)
    arc_y = 0.45 + 0.82 * np.sin(theta)
    ax.plot(arc_x, arc_y, color='#0284C7', linewidth=1.3, linestyle='-', zorder=5)
    
    # Shaded non-conformal clearance area
    ax.fill_between(arc_x, 0.90, arc_y, where=(arc_y >= 0.90),
                    color='#38BDF8', alpha=0.35, zorder=2)
    
    # Panel 1 Bottom Message
    badge_p1 = patches.FancyBboxPatch((0.08, 0.08), 1.04, 0.32,
                                     boxstyle="round,pad=0,rounding_size=0.03",
                                     facecolor='#EFF6FF', edgecolor='#93C5FD', linewidth=0.6, zorder=6)
    ax.add_patch(badge_p1)
    ax.text(0.60, 0.24, "Curvature-Modulated", fontsize=4.8, fontweight='bold',
            color='#1E40AF', ha='center', va='center', zorder=7)
    ax.text(0.60, 0.14, "Near-Field Overlap", fontsize=4.6, fontweight='bold',
            color='#1D4ED8', ha='center', va='center', zorder=7)
    
    # Connecting Arrow 1 -> 2
    ax.annotate("", xy=(1.22, 0.88), xytext=(1.14, 0.88),
                arrowprops=dict(arrowstyle="-|>", color='#0284C7', lw=1.2, mutation_scale=6))

    # -------------------------------------------------------------
    # Panel 2 (Middle): Nonlinear LSPR Shift (x: 1.25 to 2.30)
    # -------------------------------------------------------------
    ax.text(1.78, 1.58, "Nonlinear LSPR Shift", fontsize=5.8, fontweight='bold',
            color='#0F172A', ha='center', va='center')
    
    box_mid = patches.FancyBboxPatch((1.25, 0.22), 1.06, 1.22,
                                     boxstyle="round,pad=0,rounding_size=0.05",
                                     facecolor="#F0FDF4", edgecolor="#86EFAC", linewidth=0.7)
    ax.add_patch(box_mid)
    
    # Mini curve illustration inside middle box
    t_m = np.linspace(0, 1, 50)
    dE_lin_m = -t_m
    dE_cub_m = -1.2*t_m + 0.35*t_m**2 - 0.08*t_m**3
    x_plot = 1.36 + 0.84 * t_m
    y_lin  = 1.28 + 0.40 * (dE_lin_m + 0.5)
    y_cub  = 1.28 + 0.40 * (dE_cub_m + 0.5)
    ax.plot(x_plot, y_lin, '--', color='#94A3B8', lw=1.0)
    ax.plot(x_plot, y_cub, '-', color='#DC2626', lw=1.5)
    
    # High-impact badge
    badge_mid = patches.FancyBboxPatch((1.30, 0.36), 0.96, 0.42,
                                      boxstyle="round,pad=0,rounding_size=0.04",
                                      facecolor='#DC2626', edgecolor='none', zorder=3)
    ax.add_patch(badge_mid)
    ax.text(1.78, 0.60, "Model B Agreement", fontsize=5.0, fontweight='bold',
            color='#FFFFFF', ha='center', va='center', zorder=4)
    ax.text(1.78, 0.46, "< 1.2% Discrepancy", fontsize=5.4, fontweight='bold',
            color='#FEF08A', ha='center', va='center', zorder=4)
    
    ax.text(1.78, 0.12, "Curvature-Enhanced Coefficients", fontsize=4.4, fontstyle='italic',
            color='#166534', ha='center', va='center')

    # Connecting Arrow 2 -> 3
    ax.annotate("", xy=(2.41, 0.88), xytext=(2.33, 0.88),
                arrowprops=dict(arrowstyle="-|>", color='#16A34A', lw=1.2, mutation_scale=6))

    # -------------------------------------------------------------
    # Panel 3 (Right): Quasi-Anapole State (x: 2.45 to 3.42)
    # -------------------------------------------------------------
    ax.text(2.93, 1.58, "Quasi-Anapole State", fontsize=5.8, fontweight='bold',
            color='#0F172A', ha='center', va='center')
    
    box_right = patches.FancyBboxPatch((2.43, 0.22), 1.00, 1.22,
                                       boxstyle="round,pad=0,rounding_size=0.05",
                                       facecolor="#FFF7ED", edgecolor="#FDBA74", linewidth=0.7)
    ax.add_patch(box_right)
    
    # Interference formula
    ax.text(2.93, 1.30, r"$\mathbf{p} \approx -ik n_b \mathbf{T}$", fontsize=5.8, fontweight='bold',
            color='#991B1B', ha='center')
    ax.text(2.93, 1.15, r"$\Delta\phi = 174.2^\circ \quad (5.02\text{ eV})$", fontsize=4.8,
            color='#7F1D1D', ha='center')
    
    # High-impact suppression badge
    badge_r = patches.FancyBboxPatch((2.47, 0.48), 0.92, 0.46,
                                     boxstyle="round,pad=0,rounding_size=0.04",
                                     facecolor='#047857', edgecolor='none', zorder=3)
    ax.add_patch(badge_r)
    ax.text(2.93, 0.74, "Coherent Dipole Channel", fontsize=4.7, fontweight='bold',
            color='#FFFFFF', ha='center', va='center', zorder=4)
    ax.text(2.93, 0.58, ">99.3% Suppression", fontsize=5.4, fontweight='bold',
            color='#A7F3D0', ha='center', va='center', zorder=4)
    
    ax.text(2.93, 0.32, "Dominant Octupole (92.9%)", fontsize=4.5, fontweight='bold',
            color='#B45309', ha='center')
    ax.text(2.93, 0.12, "Electric-Toroidal Cancellation", fontsize=4.4, fontstyle='italic',
            color='#9A3412', ha='center')

    # Output paths
    outputs = [
        "manuscript_figures/TOC_graphic.pdf",
        "manuscript_figures/TOC_graphic.png",
        "manuscript_figures/TOC_graphic.jpg",
        "TOC_graphic.pdf",
        "TOC_graphic.png",
        "TOC_graphic.jpg"
    ]
    
    for path in outputs:
        os.makedirs(os.path.dirname(path) if os.path.dirname(path) else '.', exist_ok=True)
        plt.savefig(path, dpi=300, bbox_inches='tight', pad_inches=0.01)
    
    plt.close()
    print("Successfully generated all TOC graphics.")

if __name__ == '__main__':
    create_toc_graphic()
