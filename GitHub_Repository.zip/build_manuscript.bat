@echo off
echo ========================================================
echo   Compiling Manuscript with MiKTeX (pdflatex + bibtex)
echo ========================================================

REM Run pdflatex pass 1
pdflatex -interaction=nonstopmode -synctex=1 manuscript.tex

REM Run bibtex to resolve citations
bibtex manuscript

REM Run pdflatex pass 2
pdflatex -interaction=nonstopmode -synctex=1 manuscript.tex

REM Run pdflatex pass 3 (resolve cross-references and citations)
pdflatex -interaction=nonstopmode -synctex=1 manuscript.tex

if exist manuscript.pdf (
    echo ========================================================
    echo   Compilation Successful: manuscript.pdf generated!
    echo ========================================================
) else (
    echo [ERROR] manuscript.pdf was not generated!
)
