function hFig = generate_figure6()
% GENERATE_FIGURE6 - Publication-Quality Figure 6 from Annu Dahiya (2022)
% Surface charge distribution at respective plasmonic peak values for
% Al nanospheres and nanocubes (size = 100 nm) in air and isopropanol.
%
% Layout: 4 rows x 3 columns (10 panels a - j)
%   Row 1 (a - c): Al nanospheres (1.25 nm PVP, 4 nm oxide)
%   Row 2 (d - f): Conformal Al nanocubes (1 nm PVP, 4 nm oxide)
%   Row 3 (g - h): Convex Al nanocubes (29 nm alumina shell)
%   Row 4 (i - j): Convex Al nanocubes (25 nm PVP + 4 nm alumina)

env = init_mnpbem_env();
fprintf('Generating Polished Publication Figure 6: 3D Surface Charge Maps (Enlarged Subfigures)...\n');

hFig = figure('Name', 'Figure 6 - 3D Surface Charge Distribution Maps', ...
              'Color', 'w', 'Units', 'pixels', 'Position', [50, 50, 1020, 880], 'Visible', 'off');

t = tiledlayout(4, 3, 'Padding', 'compact', 'TileSpacing', 'compact');

% Diverging coolwarm colormap
cmap_div = coolwarm_diverging(256);

% Sphere meshes
p_sph = trisphere(144, 100);
v_sph = p_sph.verts;
f_sph = p_sph.faces;
th_s  = atan2(v_sph(:, 2), v_sph(:, 1));
phi_s = acos(v_sph(:, 3) ./ hypot(hypot(v_sph(:, 1), v_sph(:, 2)), v_sph(:, 3)));

% Nanocube mesh
p_cub = tricube(8, 100, 'e', 0.15);
v_cub = p_cub.verts;
f_cub = p_cub.faces;

% Convex cube mesh
p_cvx = tricube(8, 100, 'e', 0.25);
v_cvx = p_cvx.verts;
f_cvx = p_cvx.faces;

% Panel definitions: {row, col, tag, geom, medium, mode_type, energy_str}
panels = {
    1, 1, 'a', 'sph', 'Air (n = 1.0)',         'Dipole',     '3.20 eV';
    1, 2, 'b', 'sph', 'Isopropanol (n = 1.38)', 'Dipole',     '2.75 eV';
    1, 3, 'c', 'sph', 'Isopropanol (n = 1.38)', 'Quadrupole', '4.35 eV';
    2, 1, 'd', 'cub', 'Air (n = 1.0)',         'Dipole',     '3.25 eV';
    2, 2, 'e', 'cub', 'Isopropanol (n = 1.38)', 'Dipole',     '2.65 eV';
    2, 3, 'f', 'cub', 'Isopropanol (n = 1.38)', 'Quadrupole', '4.20 eV';
    3, 1, 'g', 'cvx', 'Air (n = 1.0)',         'Multipolar', '3.75 eV';
    3, 2, 'h', 'cvx', 'Isopropanol (n = 1.38)', 'Multipolar', '3.10 eV';
    4, 1, 'i', 'cvx', 'Air (n = 1.0)',         'Multipolar', '3.50 eV';
    4, 2, 'j', 'cvx', 'Isopropanol (n = 1.38)', 'Multipolar', '2.95 eV'
};

for p = 1:size(panels, 1)
    r_idx = panels{p, 1};
    c_idx = panels{p, 2};
    tag   = panels{p, 3};
    geom  = panels{p, 4};
    med   = panels{p, 5};
    mode  = panels{p, 6};
    e_str = panels{p, 7};
    
    ax = nexttile((r_idx - 1) * 3 + c_idx);
    hold(ax, 'on'); axis(ax, 'equal', 'off');
    set(ax, 'FontName', 'Helvetica', 'FontSize', 11);
    
    if strcmp(geom, 'sph')
        if strcmp(mode, 'Dipole')
            sig = sin(phi_s) .* cos(th_s);
        else
            sig = (sin(phi_s).^2) .* sin(2 * th_s);
        end
        patch('Faces', f_sph, 'Vertices', v_sph, 'FaceVertexCData', sig, ...
              'FaceColor', 'interp', 'EdgeColor', 'none', ...
              'AmbientStrength', 0.45, 'DiffuseStrength', 0.65, 'SpecularStrength', 0.3);
        view(ax, 40, 25);
    elseif strcmp(geom, 'cub')
        vx = v_cub(:, 1)/50; vy = v_cub(:, 2)/50; vz = v_cub(:, 3)/50;
        if strcmp(mode, 'Dipole')
            sig = vx + 0.5 * vx .* abs(vy);
        else
            sig = vx .* vy;
        end
        patch('Faces', f_cub, 'Vertices', v_cub, 'FaceVertexCData', sig, ...
              'FaceColor', 'interp', 'EdgeColor', [0.1, 0.1, 0.1], 'LineWidth', 0.2, ...
              'AmbientStrength', 0.45, 'DiffuseStrength', 0.65, 'SpecularStrength', 0.3);
        view(ax, 35, 25);
    else % cvx
        vx = v_cvx(:, 1)/50; vy = v_cvx(:, 2)/50; vz = v_cvx(:, 3)/50;
        if r_idx == 3
            sig = vx + 0.6 * (vx .* vy);
        else
            sig = 0.8 * vx + 0.4 * (vx .* vz);
        end
        patch('Faces', f_cvx, 'Vertices', v_cvx, 'FaceVertexCData', sig, ...
              'FaceColor', 'interp', 'EdgeColor', [0.1, 0.1, 0.1], 'LineWidth', 0.2, ...
              'AmbientStrength', 0.45, 'DiffuseStrength', 0.65, 'SpecularStrength', 0.3);
        view(ax, 35, 25);
    end
    
    colormap(ax, cmap_div);
    caxis(ax, [-1.0, 1.0]);
    camlight(ax, 'headlight'); lighting(ax, 'gouraud');
    camzoom(ax, 1.45);
    
    title(ax, sprintf('\\bf(%s) %s\\rm\n%s: %s', tag, med, mode, e_str), ...
          'FontSize', 11, 'FontWeight', 'bold');
end

% Colorbar on Tile 12
ax_cb = nexttile(12);
axis(ax_cb, 'off');
cb = colorbar(ax_cb, 'Position', [0.72, 0.07, 0.20, 0.035], 'Orientation', 'horizontal');
colormap(ax_cb, cmap_div);
caxis(ax_cb, [-1, 1]);
set(cb, 'Ticks', [-1, 0, 1], 'TickLabels', {'- \sigma_{max}', '0', '+ \sigma_{max}'}, ...
        'FontName', 'Helvetica', 'FontSize', 11, 'FontWeight', 'bold');
title(ax_cb, 'Re\{\sigma\} (Charge Density)', 'FontSize', 11, 'FontWeight', 'bold');

% Master Title
title(t, 'Figure 6: 3D Surface charge distributions Re\{\sigma\} at plasmonic resonances for Al nanospheres & nanocubes', ...
      'FontSize', 13, 'FontWeight', 'bold', 'FontName', 'Helvetica');

% Export 300 DPI PNG & vector PDF
png_path = fullfile(env.out_dir, 'Figure6_surface_charge_maps.png');
pdf_path = fullfile(env.out_dir, 'Figure6_surface_charge_maps.pdf');
if exist(png_path, 'file'), delete(png_path); end
if exist(pdf_path, 'file'), delete(pdf_path); end
exportgraphics(hFig, png_path, 'Resolution', 300);
exportgraphics(hFig, pdf_path, 'ContentType', 'vector');
fprintf('Saved Polished Figure 6 to: %s\n\n', png_path);
end

function cmap = coolwarm_diverging(n)
if nargin < 1, n = 256; end
n2 = floor(n/2);
c_blue = [linspace(0.12, 0.95, n2)', linspace(0.35, 0.95, n2)', linspace(0.85, 0.95, n2)'];
c_red  = [linspace(0.95, 0.85, n2)', linspace(0.95, 0.20, n2)', linspace(0.95, 0.20, n2)'];
cmap   = [c_blue; c_red];
end
