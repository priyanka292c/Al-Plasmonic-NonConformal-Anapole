function hFig = generate_figure1()
% GENERATE_FIGURE1 - Publication-Quality Figure 1 from Annu Dahiya (2022)
% Plane wave interaction and different EELS impact parameters:
%   (a) Al nanosphere with spherical PVP & oxide shell (Plane wave excitation)
%   (b) Al nanosphere with EELS electron beam trajectory and impact parameters
%   (c) Al nanocube with conformal cubic shell (Plane wave excitation)
%   (d) Al nanocube conformal with EELS beam at corner, edge, and face
%   (e) Al nanocube with convex spherical/ellipsoidal shell (Plane wave excitation)
%   (f) Al nanocube convex with EELS beam at corner, edge, and face
%
% Publication Sizing:
%   - Large, prominent 3D meshes with tight camera framing (camzoom)
%   - Prominent vector labels, large typography (12-13 pt), high-contrast lighting

env = init_mnpbem_env();
fprintf('Generating Polished Publication Figure 1: 3D Geometry & Excitation Schematics (Enlarged Subfigures)...\n');

hFig = figure('Name', 'Figure 1 - Geometry and Excitation Schematics', ...
              'Color', 'w', 'Units', 'pixels', 'Position', [50, 50, 980, 640], 'Visible', 'off');

t = tiledlayout(2, 3, 'Padding', 'compact', 'TileSpacing', 'compact');

% Color definitions matching publication convention
col_al   = [0.85, 0.88, 0.92];   % Aluminum core (metallic silver)
col_pvp  = [0.20, 0.55, 0.90];   % PVP ligand shell (azure)
col_ox   = [0.25, 0.80, 0.40];   % Alumina Al2O3 layer (emerald)
col_beam = [0.95, 0.20, 0.15];   % High-energy electron beam (red)

%% ----------------------------------------------------
% Panel (a): Nanosphere with Plane Wave Illumination
%% ----------------------------------------------------
ax1 = nexttile;
hold(ax1, 'on'); box(ax1, 'off');
set(ax1, 'FontName', 'Helvetica', 'FontSize', 12, 'LineWidth', 1.2);

p_core = trisphere(144, 100);
p_pvp  = trisphere(144, 102.5);
p_ox   = trisphere(144, 110.5);

patch('Faces', p_core.faces, 'Vertices', p_core.verts, ...
      'FaceColor', col_al, 'EdgeColor', 'none', 'FaceAlpha', 1.0, ...
      'AmbientStrength', 0.45, 'DiffuseStrength', 0.65, 'SpecularStrength', 0.5);
patch('Faces', p_pvp.faces, 'Vertices', p_pvp.verts, ...
      'FaceColor', col_pvp, 'EdgeColor', 'none', 'FaceAlpha', 0.35);
patch('Faces', p_ox.faces, 'Vertices', p_ox.verts, ...
      'FaceColor', col_ox, 'EdgeColor', [0.15, 0.6, 0.3], 'FaceAlpha', 0.25, 'LineWidth', 0.5);

quiver3(ax1, -65, 0, -65, 0, 0, 42, 'LineWidth', 2.8, 'Color', [0.1, 0.1, 0.8], 'MaxHeadSize', 0.6);
text(ax1, -65, 0, -20, '\bf k\rm (z)', 'FontSize', 11.5, 'FontWeight', 'bold', 'Color', [0.1, 0.1, 0.8]);
quiver3(ax1, -65, 0, -65, 42, 0, 0, 'LineWidth', 2.8, 'Color', [0.8, 0.1, 0.1], 'MaxHeadSize', 0.6);
text(ax1, -20, 0, -65, '\bf E\rm (x)', 'FontSize', 11.5, 'FontWeight', 'bold', 'Color', [0.8, 0.1, 0.1]);

title(ax1, '\bf(a) Nanosphere: Plane Wave\rm', 'FontSize', 12.5);
axis(ax1, 'equal'); axis(ax1, [-75, 75, -75, 75, -75, 75]);
view(ax1, 35, 25); camlight(ax1, 'headlight'); lighting(ax1, 'gouraud');
camzoom(ax1, 1.25);
axis(ax1, 'off');

%% ----------------------------------------------------
% Panel (b): Nanosphere EELS Impact Parameters
%% ----------------------------------------------------
ax2 = nexttile;
hold(ax2, 'on'); box(ax2, 'off');
set(ax2, 'FontName', 'Helvetica', 'FontSize', 12, 'LineWidth', 1.2);

patch('Faces', p_core.faces, 'Vertices', p_core.verts, ...
      'FaceColor', col_al, 'EdgeColor', 'none', 'FaceAlpha', 0.95);
patch('Faces', p_ox.faces, 'Vertices', p_ox.verts, ...
      'FaceColor', col_ox, 'EdgeColor', 'none', 'FaceAlpha', 0.25);

b_vals = [0, 25, 50, 60];
for ib = 1:length(b_vals)
    bx = b_vals(ib);
    plot3(ax2, [bx, bx], [0, 0], [-80, 80], '--', 'Color', col_beam, 'LineWidth', 1.8);
    quiver3(ax2, bx, 0, 60, 0, 0, 20, 'Color', col_beam, 'LineWidth', 2.2, 'MaxHeadSize', 0.8);
    plot3(ax2, bx, 0, 0, 'o', 'MarkerFaceColor', col_beam, 'MarkerEdgeColor', 'k', 'MarkerSize', 7);
end
text(ax2, 5, 0, -75, '\bf e^- beam\rm', 'FontSize', 11.5, 'FontWeight', 'bold', 'Color', col_beam);

title(ax2, '\bf(b) Nanosphere: EELS Impact (b)\rm', 'FontSize', 12.5);
axis(ax2, 'equal'); axis(ax2, [-75, 75, -75, 75, -75, 75]);
view(ax2, 0, 90); camlight(ax2, 'headlight'); lighting(ax2, 'gouraud');
camzoom(ax2, 1.25);
axis(ax2, 'off');

%% ----------------------------------------------------
% Panel (c): Conformal Nanocube: Plane Wave Illumination
%% ----------------------------------------------------
ax3 = nexttile;
hold(ax3, 'on'); box(ax3, 'off');
set(ax3, 'FontName', 'Helvetica', 'FontSize', 12, 'LineWidth', 1.2);

cube_geom_core = tricube(8, 100, 'e', 0.15);
cube_geom_pvp  = tricube(8, 102.5, 'e', 0.15);
cube_geom_ox   = tricube(8, 110.5, 'e', 0.15);

patch('Faces', cube_geom_core.faces, 'Vertices', cube_geom_core.verts, ...
      'FaceColor', col_al, 'EdgeColor', 'none', 'FaceAlpha', 1.0);
patch('Faces', cube_geom_pvp.faces, 'Vertices', cube_geom_pvp.verts, ...
      'FaceColor', col_pvp, 'EdgeColor', 'none', 'FaceAlpha', 0.35);
patch('Faces', cube_geom_ox.faces, 'Vertices', cube_geom_ox.verts, ...
      'FaceColor', col_ox, 'EdgeColor', [0.15, 0.6, 0.3], 'FaceAlpha', 0.25, 'LineWidth', 0.5);

quiver3(ax3, -75, -75, -75, 0, 0, 48, 'LineWidth', 2.8, 'Color', [0.1, 0.1, 0.8], 'MaxHeadSize', 0.6);
text(ax3, -75, -75, -22, '\bf k\rm (z)', 'FontSize', 11.5, 'FontWeight', 'bold', 'Color', [0.1, 0.1, 0.8]);
quiver3(ax3, -75, -75, -75, 48, 0, 0, 'LineWidth', 2.8, 'Color', [0.8, 0.1, 0.1], 'MaxHeadSize', 0.6);
text(ax3, -22, -75, -75, '\bf E\rm (x)', 'FontSize', 11.5, 'FontWeight', 'bold', 'Color', [0.8, 0.1, 0.1]);

title(ax3, '\bf(c) Conformal Cube: Plane Wave\rm', 'FontSize', 12.5);
axis(ax3, 'equal'); axis(ax3, [-85, 85, -85, 85, -85, 85]);
view(ax3, 35, 25); camlight(ax3, 'headlight'); lighting(ax3, 'gouraud');
camzoom(ax3, 1.25);
axis(ax3, 'off');

%% ----------------------------------------------------
% Panel (d): Conformal Nanocube: EELS Impact Modes
%% ----------------------------------------------------
ax4 = nexttile;
hold(ax4, 'on'); box(ax4, 'off');
set(ax4, 'FontName', 'Helvetica', 'FontSize', 12, 'LineWidth', 1.2);

patch('Faces', cube_geom_core.faces, 'Vertices', cube_geom_core.verts, ...
      'FaceColor', col_al, 'EdgeColor', 'none', 'FaceAlpha', 0.95);
patch('Faces', cube_geom_ox.faces, 'Vertices', cube_geom_ox.verts, ...
      'FaceColor', col_ox, 'EdgeColor', [0.15, 0.6, 0.3], 'FaceAlpha', 0.25);

pts = [50, 50; 50, 0; 0, 0];
labels = {'Corner', 'Edge', 'Face'};
for ip = 1:3
    px = pts(ip, 1); py = pts(ip, 2);
    plot3(ax4, [px, px], [py, py], [-80, 80], '--', 'Color', col_beam, 'LineWidth', 1.8);
    quiver3(ax4, px, py, 60, 0, 0, 20, 'Color', col_beam, 'LineWidth', 2.2, 'MaxHeadSize', 0.8);
    plot3(ax4, px, py, 50, 'o', 'MarkerFaceColor', col_beam, 'MarkerEdgeColor', 'k', 'MarkerSize', 7);
    text(ax4, px + 6, py, 55, ['\bf' labels{ip} '\rm'], 'FontSize', 11, 'Color', 'k');
end

title(ax4, '\bf(d) Conformal Cube: EELS Impacts\rm', 'FontSize', 12.5);
axis(ax4, 'equal'); axis(ax4, [-85, 85, -85, 85, -85, 85]);
view(ax4, 35, 25); camlight(ax4, 'headlight'); lighting(ax4, 'gouraud');
camzoom(ax4, 1.25);
axis(ax4, 'off');

%% ----------------------------------------------------
% Panel (e): Convex Nanocube: Plane Wave Illumination
%% ----------------------------------------------------
ax5 = nexttile;
hold(ax5, 'on'); box(ax5, 'off');
set(ax5, 'FontName', 'Helvetica', 'FontSize', 12, 'LineWidth', 1.2);

p_convex_pvp = trisphere(144, 125);
p_convex_ox  = trisphere(144, 133);

patch('Faces', cube_geom_core.faces, 'Vertices', cube_geom_core.verts, ...
      'FaceColor', col_al, 'EdgeColor', 'none', 'FaceAlpha', 1.0);
patch('Faces', p_convex_pvp.faces, 'Vertices', p_convex_pvp.verts, ...
      'FaceColor', col_pvp, 'EdgeColor', 'none', 'FaceAlpha', 0.30);
patch('Faces', p_convex_ox.faces, 'Vertices', p_convex_ox.verts, ...
      'FaceColor', col_ox, 'EdgeColor', [0.15, 0.6, 0.3], 'FaceAlpha', 0.20, 'LineWidth', 0.5);

quiver3(ax5, -85, -85, -85, 0, 0, 50, 'LineWidth', 2.8, 'Color', [0.1, 0.1, 0.8], 'MaxHeadSize', 0.6);
quiver3(ax5, -85, -85, -85, 50, 0, 0, 'LineWidth', 2.8, 'Color', [0.8, 0.1, 0.1], 'MaxHeadSize', 0.6);

title(ax5, '\bf(e) Convex Cube: Plane Wave\rm', 'FontSize', 12.5);
axis(ax5, 'equal'); axis(ax5, [-95, 95, -95, 95, -95, 95]);
view(ax5, 35, 25); camlight(ax5, 'headlight'); lighting(ax5, 'gouraud');
camzoom(ax5, 1.25);
axis(ax5, 'off');

%% ----------------------------------------------------
% Panel (f): Convex Nanocube: EELS Impact Modes
%% ----------------------------------------------------
ax6 = nexttile;
hold(ax6, 'on'); box(ax6, 'off');
set(ax6, 'FontName', 'Helvetica', 'FontSize', 12, 'LineWidth', 1.2);

patch('Faces', cube_geom_core.faces, 'Vertices', cube_geom_core.verts, ...
      'FaceColor', col_al, 'EdgeColor', 'none', 'FaceAlpha', 0.95);
patch('Faces', p_convex_ox.faces, 'Vertices', p_convex_ox.verts, ...
      'FaceColor', col_ox, 'EdgeColor', 'none', 'FaceAlpha', 0.20);

for ip = 1:3
    px = pts(ip, 1); py = pts(ip, 2);
    plot3(ax6, [px, px], [py, py], [-85, 85], '--', 'Color', col_beam, 'LineWidth', 1.8);
    quiver3(ax6, px, py, 70, 0, 0, 20, 'Color', col_beam, 'LineWidth', 2.2, 'MaxHeadSize', 0.8);
    plot3(ax6, px, py, 60, 'o', 'MarkerFaceColor', col_beam, 'MarkerEdgeColor', 'k', 'MarkerSize', 7);
    text(ax6, px + 6, py, 65, ['\bf' labels{ip} '\rm'], 'FontSize', 11, 'Color', 'k');
end

title(ax6, '\bf(f) Convex Cube: EELS Impacts\rm', 'FontSize', 12.5);
axis(ax6, 'equal'); axis(ax6, [-95, 95, -95, 95, -95, 95]);
view(ax6, 35, 25); camlight(ax6, 'headlight'); lighting(ax6, 'gouraud');
camzoom(ax6, 1.25);
axis(ax6, 'off');

% Master Title
title(t, 'Figure 1: Plane wave interaction and EELS impact parameters for Al nanospheres and nanocubes', ...
      'FontSize', 13.5, 'FontWeight', 'bold', 'FontName', 'Helvetica');

% Save high-resolution outputs
png_path = fullfile(env.out_dir, 'Figure1_geometry_schematic.png');
pdf_path = fullfile(env.out_dir, 'Figure1_geometry_schematic.pdf');
exportgraphics(hFig, png_path, 'Resolution', 300);
exportgraphics(hFig, pdf_path, 'ContentType', 'vector');
fprintf('Saved Polished Figure 1 to: %s\n\n', png_path);
end
