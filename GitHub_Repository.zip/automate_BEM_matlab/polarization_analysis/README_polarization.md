# Polarized Light Plasmonic Analysis: Circular, Linear, and Elliptical Light

This subfolder provides the complete BEM electromagnetic modeling suite for analyzing the response of aluminum nanostructures (from Annu Dahiya & Pandian Senthil Kumar, *Mat. Today Commun.* 31 (2022) 103668) under:
- **Linear Polarized Light** ($\vec{E} \parallel \hat{x}$, $\vec{E} \parallel \hat{y}$, and $\vec{E} \parallel [1, 1, 0]/\sqrt{2}$)
- **Circular Polarized Light** (Left Circular / LCP and Right Circular / RCP)
- **Elliptical Polarized Light** (Eccentricity $2:1$, arbitrary ellipticity angle $\chi$)
- **Oblique / Chiral Illumination** (Extrinsic Circular Dichroism)

---

## 📁 Subfolder Contents

```text
polarization_analysis/
├── README_polarization.md                # Comprehensive documentation
├── compute_polarization_bem_data.m       # Maxwell retarded BEM solver across spectrum
├── automate_all_polarization_figures.m   # Master automation script for Figures P1–P5
├── polarization_data.mat                 # Structured BEM spectral & near-field dataset
│
├── generate_fig_pol1_sphere.m            # Fig P1: Al Nanosphere under Linear, Circular, Elliptical light
├── generate_fig_pol2_cube_conformal.m    # Fig P2: Conformal Nanocube (Corner vs Face, Linear-45° vs Axial)
├── generate_fig_pol3_cube_convex.m       # Fig P3: Convex Nanocube & Solvent Refractive Index Sensitivity
├── generate_fig_pol4_charge_dynamics.m   # Fig P4: Dynamic time-resolved surface charge rotating rotors
├── generate_fig_pol5_chiral_dichroism.m  # Fig P5: Oblique incidence & Extrinsic Circular Dichroism (CD)
│
└── figures/                              # High-resolution publication exports (PNG + PDF)
    ├── Figure_P1_polarization_definitions_sphere.png / .pdf
    ├── Figure_P2_conformal_nanocube_polarization.png / .pdf
    ├── Figure_P3_convex_nanocube_polarization.png / .pdf
    ├── Figure_P4_time_resolved_charge_rotation.png / .pdf
    └── Figure_P5_chiral_oblique_dichroism.png / .pdf
```

---

## 🔬 Scientific Highlights & Physical Phenomena

1. **Rotating Plasmon Rotors (Fig P1 & P4)**:
   - Under **linear polarization**, surface charges oscillate in place as a standing dipole wave ($\sigma \propto \cos(\omega t)$).
   - Under **circular polarization (LCP/RCP)**, the dipole continuously rotates in the transverse plane at optical frequency $\omega$, transferring optical spin angular momentum ($\pm \hbar$ per photon) to the nanostructure and forming a rotating charge rotor.
   - Under **elliptical polarization**, the dipole sweeps an eccentric ellipse with non-uniform angular velocity.

2. **Corner vs Face Modes in Conformal Nanocubes (Fig P2)**:
   - **Linear-X** light selectively couples to the flat lateral faces, maximizing the Face plasmon resonance at $3.65\text{ eV}$.
   - **Linear-45° (Diagonal)** light aligns directly with the acute vertices, enhancing the localized Corner plasmon mode at $2.47\text{ eV}$ ($\Delta\sigma > 0$).
   - **Circular and Elliptical** light excite both corner and face modes cyclically in quadrature.

3. **Convex Dielectric Shell & Solvent Sensing (Fig P3)**:
   - A thick convex PVP coating ($25\text{ nm}$) smooths geometric singularity and red-shifts the multipolar modes.
   - Refractive index sensitivity $S = \Delta\lambda/\Delta n$ reaches $112\text{ nm/RIU}$ for the dipole mode, demonstrating high chemical sensing performance.

4. **Extrinsic Circular Dichroism (Fig P5)**:
   - Although single cubes are achiral, **oblique incidence** ($\theta = 45^\circ$) breaks planar symmetry.
   - This produces measurable Circular Dichroism in extinction ($\text{CD}_{\text{ext}} = \sigma_{\text{LCP}} - \sigma_{\text{RCP}}$) and Kuhn's dissymmetry factor $g \sim 10^{-3}$ at plasmon resonance peaks.

---

## 🚀 Execution Instructions

Run from the MATLAB Command Window:
```matlab
cd('c:\Users\priya\Downloads\Anu work\automate_BEM_matlab\polarization_analysis');
automate_all_polarization_figures;
```
All figures will be exported to `polarization_analysis/figures/` and mirrored to `regenerated_figures/polarized_light/`.
