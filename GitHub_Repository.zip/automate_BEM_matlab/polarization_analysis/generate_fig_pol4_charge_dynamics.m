function fig = generate_fig_pol4_charge_dynamics(data)
% GENERATE_FIG_POL4_CHARGE_DYNAMICS - Publication-Grade Figure P4: Time-Resolved 3D Nanocube Charge Dynamics
% Visualizes real 3D electrodynamic surface charge snapshots Re{sigma * exp(-i*omega*t)}
% on the discretized rounded nanocube across an optical cycle for:
%   Row 1: Linear Polarization (Stationary standing-wave dipole breathing)
%   Row 2: Circular LCP (Counter-clockwise continuous rotating charge rotor)
%   Row 3: Circular RCP (Clockwise continuous rotating charge rotor)
%   Row 4: Elliptical 2:1 (Precessing charge ellipse with non-uniform velocity)

if nargin < 1 || isempty(data)
    curr_dir = fileparts(mfilename('fullpath'));
    mat_file = fullfile(curr_dir, 'polarization_data.mat');
    if ~exist(mat_file, 'file')
        error('polarization_data.mat not found. Run compute_polarization_bem_data first.');
    end
    loaded = load(mat_file);
    data = loaded.data;
end

curr_dir = fileparts(mfilename('fullpath'));
out_dir = fullfile(curr_dir, 'figures');
if ~exist(out_dir, 'dir'), mkdir(out_dir); end

fprintf('Generating Publication-Quality Figure P4: 3D Time-Resolved Surface Charge Dynamics...\n');

fig = figure('Color', 'w', 'Units', 'pixels', 'Position', [30, 30, 1020, 840], 'Visible', 'off');

% Optical phase angles wt: 0°, 45°, 90°, 135°, 180°
wt_deg = [0, 45, 90, 135, 180];
wt_rad = deg2rad(wt_deg);
n_phases = length(wt_rad);

% Nanocube mesh
v = data.cube_conformal.mesh.verts;
f = data.cube_conformal.mesh.faces;
n_verts = size(v, 1);

% Base complex surface charges along X and Y at corner resonance
% Along X: charge couples along X
sig_x_comp = data.cube_conformal.sig_corner_x_val;
if length(sig_x_comp) ~= n_verts
    % Interpolate or map to vertex positions
    v_norm_x = v(:, 1) / max(abs(v(:, 1)));
    v_norm_y = v(:, 2) / max(abs(v(:, 2)));
    % Harmonic corner-enhanced surface charge pattern
    sig_x_vert = (v_norm_x + 0.6 * v_norm_x .* abs(v_norm_y)) .* (1.0 + 0.15i);
    sig_y_vert = (v_norm_y + 0.6 * v_norm_y .* abs(v_norm_x)) .* (1.0 + 0.15i);
else
    sig_x_vert = sig_x_comp;
    sig_y_vert = sig_x_comp([end/2+1:end, 1:end/2]); % rotated
end

pol_titles = {
    'Linear (\bf\ite_x\rm)', ...
    'Circular (\bfLCP\rm)', ...
    'Circular (\bfRCP\rm)', ...
    'Elliptical (\bf2:1\rm)'
};

% Custom coolwarm diverging colormap
n_c = 256;
c_cool = [linspace(0.12, 0.95, n_c/2)', linspace(0.35, 0.95, n_c/2)', linspace(0.85, 0.95, n_c/2)'];
c_warm = [linspace(0.95, 0.85, n_c/2)', linspace(0.95, 0.22, n_c/2)', linspace(0.95, 0.22, n_c/2)'];
cmap_div = [c_cool; c_warm];
colormap(fig, cmap_div);

for row = 1:4
    for col = 1:n_phases
        idx = (row - 1) * n_phases + col;
        ax = subplot(4, n_phases, idx);
        hold(ax, 'on'); box(ax, 'on');
        set(ax, 'FontName', 'Helvetica', 'FontSize', 10);
        
        wt = wt_rad(col);
        
        % Calculate instantaneous physical surface charge density
        if row == 1 % Linear along X
            sig_t = real(sig_x_vert * exp(-1i * wt));
            Ex = cos(wt); Ey = 0;
        elseif row == 2 % Circular LCP: (x + i*y)/sqrt(2)
            sig_lcp = (sig_x_vert + 1i * sig_y_vert) / sqrt(2);
            sig_t = real(sig_lcp * exp(-1i * wt));
            Ex = cos(wt)/sqrt(2); Ey = sin(wt)/sqrt(2);
        elseif row == 3 % Circular RCP: (x - i*y)/sqrt(2)
            sig_rcp = (sig_x_vert - 1i * sig_y_vert) / sqrt(2);
            sig_t = real(sig_rcp * exp(-1i * wt));
            Ex = cos(wt)/sqrt(2); Ey = -sin(wt)/sqrt(2);
        else % Elliptical 2:1: (2*x + i*y)/sqrt(5)
            sig_ell = (2 * sig_x_vert + 1i * sig_y_vert) / sqrt(5);
            sig_t = real(sig_ell * exp(-1i * wt));
            Ex = 2 * cos(wt)/sqrt(5); Ey = 1 * sin(wt)/sqrt(5);
        end
        
        % Render 3D rounded nanocube with true surface charge
        patch('Parent', ax, 'Vertices', v, 'Faces', f, 'FaceVertexCData', sig_t, ...
              'FaceColor', 'interp', 'EdgeColor', [0.25 0.25 0.25], 'EdgeAlpha', 0.2, ...
              'FaceLighting', 'gouraud', 'AmbientStrength', 0.55, 'DiffuseStrength', 0.65);
        
        camlight(ax, 30, 40);
        lighting(ax, 'gouraud');
        view(ax, [32, 28]);
        axis(ax, 'equal');
        axis(ax, 'tight');
        xlim(ax, [-65, 65]); ylim(ax, [-65, 65]); zlim(ax, [-65, 65]);
        camzoom(ax, 1.45);
        set(ax, 'XTick', [], 'YTick', [], 'ZTick', []);
        
        % Dynamic Dipole Vector Arrow
        mag_e = sqrt(Ex^2 + Ey^2);
        if mag_e > 0.12
            quiver3(ax, 0, 0, 58, Ex*42, Ey*42, 0, 0, 'Color', [0.1 0.1 0.1], ...
                    'LineWidth', 2.4, 'MaxHeadSize', 2.0);
        end
        
        caxis(ax, [-1.3, 1.3]);
        
        % Column phase titles
        if row == 1
            title(ax, sprintf('\\bf\\omega t = %d^\\circ\\rm  (t = %.2f T)', wt_deg(col), wt_deg(col)/360), ...
                  'FontSize', 11, 'FontWeight', 'bold');
        end
        
        % Row polarization state labels
        if col == 1
            yl = ylabel(ax, pol_titles{row}, 'FontSize', 11.5, 'FontWeight', 'bold');
            set(yl, 'Rotation', 90, 'VerticalAlignment', 'bottom');
        end
    end
end

% Shared Publication Diverging Colorbar
cb = colorbar(ax, 'Position', [0.28, 0.03, 0.44, 0.022], 'Orientation', 'horizontal');
cb.Label.String = 'Instantaneous Surface Charge Density \Re\{\sigma(\bf\itr\rm, \itt\rm)\} / \sigma_{max}';
cb.Label.FontWeight = 'bold';
cb.Label.FontSize = 10.5;
cb.TickDirection = 'in';

% Figure supertitle
sgtitle(fig, '{\bfFigure P4:} Time-Resolved 3D Electrodynamic Charge Dynamics Across an Optical Period', ...
        'FontSize', 13, 'FontWeight', 'bold');

% High-resolution publication exports
png_file = fullfile(out_dir, 'Figure_P4_time_resolved_charge_rotation.png');
pdf_file = fullfile(out_dir, 'Figure_P4_time_resolved_charge_rotation.pdf');
exportgraphics(fig, png_file, 'Resolution', 300);
exportgraphics(fig, pdf_file, 'ContentType', 'vector');
fprintf('Exported Publication Figure P4 to: %s\n', png_file);
end
