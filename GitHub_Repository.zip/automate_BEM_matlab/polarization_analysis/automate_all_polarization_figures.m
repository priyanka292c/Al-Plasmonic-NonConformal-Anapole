function automate_all_polarization_figures()
% AUTOMATE_ALL_POLARIZATION_FIGURES - Master script for Polarized Light Analysis
% Generates Figures P1 to P5 for Linear, Circular, and Elliptical polarization.
%
% Nanostructures: Al Nanosphere, Conformal Nanocube, Convex Nanocube, Oblique Chiral Nanocube
% Outputs: 300 DPI PNG and vector PDF in subfolder 'figures/' and 'regenerated_figures/polarized_light/'

clc; close all;
fprintf('========================================================================\n');
fprintf('  POLARIZED LIGHT PLASMONIC ANALYSIS: BEM AUTOMATION SUITE\n');
fprintf('  Circular (LCP/RCP), Linear (X/Y/45°), Elliptical Polarizations\n');
fprintf('========================================================================\n\n');

startTime = tic;
curr_dir = fileparts(mfilename('fullpath'));
parent_dir = fileparts(curr_dir);
addpath(parent_dir);
addpath(curr_dir);

% 1. Ensure BEM data is computed
fprintf('--- Step 1: Loading / Computing Polarization BEM Dataset ---\n');
data = compute_polarization_bem_data();

% 2. Generate Figures P1 to P5
fprintf('\n--- Step 2: Generating Publication Figures ---\n');
f1 = generate_fig_pol1_sphere(data);
close(f1);

f2 = generate_fig_pol2_cube_conformal(data);
close(f2);

f3 = generate_fig_pol3_cube_convex(data);
close(f3);

f4 = generate_fig_pol4_charge_dynamics(data);
close(f4);

f5 = generate_fig_pol5_chiral_dichroism(data);
close(f5);

% 3. Mirror figures into regenerated_figures/polarized_light
fig_subfolder = fullfile(curr_dir, 'figures');
mirror_dir = fullfile(parent_dir, 'regenerated_figures', 'polarized_light');
if ~exist(mirror_dir, 'dir')
    mkdir(mirror_dir);
end

fig_files = dir(fullfile(fig_subfolder, '*.*'));
for k = 1:length(fig_files)
    if ~fig_files(k).isdir
        copyfile(fullfile(fig_subfolder, fig_files(k).name), ...
                 fullfile(mirror_dir, fig_files(k).name));
    end
end
fprintf('Mirrored all figures to: %s\n', mirror_dir);

totalTime = toc(startTime);

% 4. Summary & Verification
fprintf('\n========================================================================\n');
fprintf('  POLARIZATION STUDY VERIFICATION & EXPORT SUMMARY\n');
fprintf('========================================================================\n');

fig_names = {
    'Figure_P1_polarization_definitions_sphere', ...
    'Figure_P2_conformal_nanocube_polarization', ...
    'Figure_P3_convex_nanocube_polarization', ...
    'Figure_P4_time_resolved_charge_rotation', ...
    'Figure_P5_chiral_oblique_dichroism'
};

all_ok = true;
for i = 1:length(fig_names)
    png_f = fullfile(fig_subfolder, [fig_names{i}, '.png']);
    pdf_f = fullfile(fig_subfolder, [fig_names{i}, '.pdf']);
    
    if exist(png_f, 'file') && exist(pdf_f, 'file')
        d_png = dir(png_f);
        d_pdf = dir(pdf_f);
        fprintf('[OK] Fig P%d: %-42s (PNG: %.1f KB, PDF: %.1f KB)\n', ...
                i, fig_names{i}, d_png.bytes/1024, d_pdf.bytes/1024);
    else
        fprintf('[FAILED] Fig P%d: %-42s\n', i, fig_names{i});
        all_ok = false;
    end
end

fprintf('\nTotal execution time: %.2f seconds.\n', totalTime);
if all_ok
    fprintf('SUCCESS: ALL 5 POLARIZATION FIGURES GENERATED IN SUBFOLDER!\n');
    fprintf('Primary location: %s\n', fig_subfolder);
    fprintf('Mirror location:  %s\n', mirror_dir);
else
    fprintf('WARNING: Some figures failed to generate.\n');
end
fprintf('========================================================================\n');
end
