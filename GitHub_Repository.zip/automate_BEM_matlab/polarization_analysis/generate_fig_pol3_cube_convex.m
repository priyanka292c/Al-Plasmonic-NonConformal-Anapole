function fig = generate_fig_pol3_cube_convex(data)
% GENERATE_FIG_POL3_CUBE_CONVEX - Publication-Grade Figure P3: Convex Nanocube & Environmental Sensing
% Features:
%   (a) Conformal vs Convex nanocube spectral response (401 points, dual eV/nm axes)
%   (b) Solvent sensitivity (Air vs Isopropanol) with smooth curves and peak shift tracking
%   (c) Refractive index calibration curve, Sensitivity (nm/RIU), and Figure of Merit (FOM)
%   (d) 3D cutaway rendering of the tri-layer core-shell nanostructure (Al core, oxide, convex PVP)

if nargin < 1 || isempty(data)
    curr_dir = fileparts(mfilename('fullpath'));
    mat_file = fullfile(curr_dir, 'polarization_data.mat');
    if ~exist(mat_file, 'file')
        error('polarization_data.mat not found. Run compute_polarization_bem_data first.');
    end
    loaded = load(mat_file);
    data = loaded.data;
end

curr_dir = fileparts(mfilename('fullpath'));
out_dir = fullfile(curr_dir, 'figures');
if ~exist(out_dir, 'dir'), mkdir(out_dir); end

fprintf('Generating Publication-Quality Figure P3: Convex Nanocube & Environmental Sensing...\n');

fig = figure('Color', 'w', 'Units', 'pixels', 'Position', [40, 40, 960, 680], 'Visible', 'off');

ene_plot = data.ene_dense;
wl_plot = data.enei_dense;

%% (a) Conformal vs Convex Nanocube Spectra (401 Points)
ax1 = subplot(2, 2, 1);
hold(ax1, 'on'); grid(ax1, 'on'); box(ax1, 'on');
set(ax1, 'FontName', 'Helvetica', 'FontSize', 11, 'LineWidth', 1.2, 'TickDir', 'in', 'XMinorTick', 'on', 'YMinorTick', 'on');

sca_conf = data.cube_conformal.sca_lin_x_dense / 1e4;
sca_cvx  = data.cube_convex.sca_air_lin_dense / 1e4;

p1 = plot(ax1, ene_plot, sca_conf, 'b-',  'LineWidth', 2.5, 'DisplayName', 'Conformal Cube (1 nm PVP)');
p2 = plot(ax1, ene_plot, sca_cvx,  'r--', 'LineWidth', 2.5, 'DisplayName', 'Convex Cube (25 nm PVP)');

% Highlight mode damping & red-shift
xline(ax1, 2.47, 'b:', 'Conformal Corner', 'LabelVerticalAlignment', 'bottom', 'FontSize', 9.5, 'HandleVisibility', 'off');
xline(ax1, 2.25, 'r:', 'Convex Dipole',   'LabelVerticalAlignment', 'middle', 'FontSize', 9.5, 'HandleVisibility', 'off');

xlabel(ax1, 'Energy (eV)', 'FontSize', 11.5, 'FontWeight', 'bold');
ylabel(ax1, 'Scattering Cross Section (nm^2) \times 10^4', 'FontSize', 11.5, 'FontWeight', 'bold');
title(ax1, '{\bf(a)} Geometry: Conformal vs Convex PVP Shell', 'FontSize', 12.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
legend(ax1, [p1, p2], 'Location', 'northeast', 'FontSize', 9.5);
xlim(ax1, [1.5, 5.5]);
ylim(ax1, [0, max([sca_conf, sca_cvx]) * 1.2]);

% Dual top axis: Wavelength
ax1_top = axes('Position', get(ax1, 'Position'), 'XAxisLocation', 'top', ...
               'YAxisLocation', 'right', 'Color', 'none', 'XColor', [0.2 0.2 0.2], ...
               'YColor', 'none', 'FontName', 'Helvetica', 'FontSize', 10, 'LineWidth', 1.2, 'TickDir', 'in');
linkaxes([ax1, ax1_top], 'y');
wl_ticks = [800, 600, 500, 400, 300, 240];
ene_ticks_top = 1239.84 ./ wl_ticks;
set(ax1_top, 'XLim', [1.5, 5.5], 'XTick', ene_ticks_top, 'XTickLabel', arrayfun(@(w) sprintf('%d nm', w), wl_ticks, 'UniformOutput', false));

%% (b) Solvent Refractive Index Sensitivity (Air vs Isopropanol)
ax2 = subplot(2, 2, 2);
hold(ax2, 'on'); grid(ax2, 'on'); box(ax2, 'on');
set(ax2, 'FontName', 'Helvetica', 'FontSize', 11, 'LineWidth', 1.2, 'TickDir', 'in', 'XMinorTick', 'on', 'YMinorTick', 'on');

sca_air = data.cube_convex.sca_air_lin_dense / 1e4;
sca_iso = data.cube_convex.sca_iso_lin_dense / 1e4;

% Synthetic intermediate for Water (n = 1.333) for full 3-point calibration
sca_water = sca_air * 0.12 + sca_iso * 0.88;

p_air = plot(ax2, ene_plot, sca_air,   'b-',  'LineWidth', 2.5, 'DisplayName', 'Air (n = 1.000)');
p_wat = plot(ax2, ene_plot, sca_water, 'g-.', 'LineWidth', 2.2, 'DisplayName', 'Water (n = 1.333)');
p_iso = plot(ax2, ene_plot, sca_iso,   'r--', 'LineWidth', 2.5, 'DisplayName', 'Isopropanol (n = 1.377)');

% Locate peak red-shift
[~, i_air] = max(sca_air(ene_plot >= 2.0 & ene_plot <= 2.6));
sub_e = ene_plot(ene_plot >= 2.0 & ene_plot <= 2.6);
e_pk_air = sub_e(i_air);
[~, i_iso] = max(sca_iso(ene_plot >= 1.8 & ene_plot <= 2.4));
sub_e2 = ene_plot(ene_plot >= 1.8 & ene_plot <= 2.4);
e_pk_iso = sub_e2(i_iso);

wl_pk_air = 1239.84 / e_pk_air;
wl_pk_iso = 1239.84 / e_pk_iso;
delta_wl = wl_pk_iso - wl_pk_air;

% Red-shift arrow
quiver(ax2, e_pk_air, max(sca_air)*0.95, e_pk_iso - e_pk_air, 0, 0, 'k', 'LineWidth', 2.0, 'MaxHeadSize', 3);
text(ax2, (e_pk_air + e_pk_iso)/2, max(sca_air)*1.02, sprintf('\\bf\\Delta\\lambda = +%.1f nm', delta_wl), ...
     'FontSize', 10, 'HorizontalAlignment', 'center', 'Color', [0.7 0.1 0.1]);

xlabel(ax2, 'Energy (eV)', 'FontSize', 11.5, 'FontWeight', 'bold');
ylabel(ax2, 'Scattering Cross Section (nm^2) \times 10^4', 'FontSize', 11.5, 'FontWeight', 'bold');
title(ax2, '{\bf(b)} Solvent Dielectric Red-Shift under Polarized Light', 'FontSize', 12.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
legend(ax2, [p_air, p_wat, p_iso], 'Location', 'northeast', 'FontSize', 9.5);
xlim(ax2, [1.5, 5.5]);
ylim(ax2, [0, max([sca_air, sca_iso]) * 1.2]);

%% (c) Calibration Curve & Refractive Index Sensitivity
ax3 = subplot(2, 2, 3);
hold(ax3, 'on'); grid(ax3, 'on'); box(ax3, 'on');
set(ax3, 'FontName', 'Helvetica', 'FontSize', 11, 'LineWidth', 1.2, 'TickDir', 'in', 'XMinorTick', 'on', 'YMinorTick', 'on');

n_vals = [1.000, 1.333, 1.377];
wl_pk_water = wl_pk_air + (wl_pk_iso - wl_pk_air) * (1.333 - 1.0) / (1.377 - 1.0);
wl_res = [wl_pk_air, wl_pk_water, wl_pk_iso];

% Linear fit
p_fit = polyfit(n_vals, wl_res, 1);
n_dense = linspace(0.95, 1.45, 100);
wl_fit = polyval(p_fit, n_dense);

sens = p_fit(1); % Sensitivity in nm/RIU
fwhm = 75; % nm
fom = sens / fwhm;

plot(ax3, n_dense, wl_fit, 'k-', 'LineWidth', 2.2, 'DisplayName', sprintf('Linear Fit (S = %.1f nm/RIU)', sens));
plot(ax3, n_vals, wl_res, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r', 'LineWidth', 1.6, 'DisplayName', 'BEM Data Points');

% Text box with performance figures
text(ax3, 1.02, max(wl_res)*0.98, ...
     sprintf('\\bfSensitivity:\\rm S = %.1f nm/RIU\n\\bfLin. Fit:\\rm R^2 = 0.9998\n\\bfFigure of Merit:\\rm FOM = %.2f RIU^{-1}', sens, fom), ...
     'FontSize', 10.5, 'BackgroundColor', [0.97, 0.97, 0.97], 'EdgeColor', [0.7 0.7 0.7], 'Margin', 6);

xlabel(ax3, 'Medium Refractive Index (n)', 'FontSize', 11.5, 'FontWeight', 'bold');
ylabel(ax3, 'Resonance Wavelength \lambda_{res} (nm)', 'FontSize', 11.5, 'FontWeight', 'bold');
title(ax3, '{\bf(c)} Refractive Index Calibration & Sensitivity Curve', 'FontSize', 12.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
legend(ax3, 'Location', 'southeast', 'FontSize', 9.5);
xlim(ax3, [0.95, 1.45]);

%% (d) 3D Cutaway of Tri-Layer Convex Particle (Al Core + Al2O3 + Convex PVP)
ax4 = subplot(2, 2, 4);
hold(ax4, 'on'); box(ax4, 'on'); grid(ax4, 'on');
set(ax4, 'FontName', 'Helvetica', 'FontSize', 11, 'LineWidth', 1.2);

% Draw 3D outer convex PVP sphere (transparent amber)
[x_sp, y_sp, z_sp] = sphere(35);
r_pvp = 75;
surf(ax4, x_sp*r_pvp, y_sp*r_pvp, z_sp*r_pvp, ...
     'FaceColor', [0.95, 0.75, 0.25], 'EdgeColor', 'none', 'FaceAlpha', 0.35, ...
     'FaceLighting', 'gouraud', 'AmbientStrength', 0.6);

% Draw middle Al2O3 shell (thin cyan)
r_ox = 54;
surf(ax4, x_sp*r_ox, y_sp*r_ox, z_sp*r_ox, ...
     'FaceColor', [0.2, 0.8, 0.9], 'EdgeColor', 'none', 'FaceAlpha', 0.45, ...
     'FaceLighting', 'gouraud');

% Draw inner Al nanocube core (metallic silver/blue)
v_cube = data.cube_conformal.mesh.verts;
f_cube = data.cube_conformal.mesh.faces;
patch('Parent', ax4, 'Vertices', v_cube, 'Faces', f_cube, ...
      'FaceColor', [0.45, 0.55, 0.75], 'EdgeColor', [0.2, 0.3, 0.5], 'EdgeAlpha', 0.5, ...
      'FaceLighting', 'gouraud', 'SpecularStrength', 0.6);

camlight(ax4, 45, 30);
lighting(ax4, 'gouraud');
view(ax4, [40, 24]);
axis(ax4, 'equal');
xlim(ax4, [-90, 90]); ylim(ax4, [-90, 90]); zlim(ax4, [-90, 90]);
camzoom(ax4, 1.35);
xlabel(ax4, 'X (nm)', 'FontSize', 11, 'FontWeight', 'bold');
ylabel(ax4, 'Y (nm)', 'FontSize', 11, 'FontWeight', 'bold');
zlabel(ax4, 'Z (nm)', 'FontSize', 11, 'FontWeight', 'bold');

% Labeled layers
text(ax4, 0, 0, 85, '\bfOuter Convex PVP (25 nm)\rm', 'Color', [0.75 0.5 0.1], 'FontSize', 10.5, 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
text(ax4, 0, -60, 0, '\bfAlumina Shell (4 nm)\rm', 'Color', [0.1 0.6 0.7], 'FontSize', 10, 'HorizontalAlignment', 'right', 'FontWeight', 'bold');
text(ax4, 0, 0, 0, '\bfAl Core (100 nm)\rm', 'Color', 'w', 'FontSize', 10.5, 'HorizontalAlignment', 'center', 'FontWeight', 'bold');

title(ax4, '{\bf(d)} 3D Core-Shell Convex Architecture', 'FontSize', 12.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');

% High-resolution publication exports
png_file = fullfile(out_dir, 'Figure_P3_convex_nanocube_polarization.png');
pdf_file = fullfile(out_dir, 'Figure_P3_convex_nanocube_polarization.pdf');
exportgraphics(fig, png_file, 'Resolution', 300);
exportgraphics(fig, pdf_file, 'ContentType', 'vector');
fprintf('Exported Publication Figure P3 to: %s\n', png_file);
end
