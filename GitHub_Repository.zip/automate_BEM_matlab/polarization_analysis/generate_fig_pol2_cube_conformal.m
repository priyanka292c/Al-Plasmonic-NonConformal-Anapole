function fig = generate_fig_pol2_cube_conformal(data)
% GENERATE_FIG_POL2_CUBE_CONFORMAL - Publication-Grade Figure P2: Conformal Al Nanocube Polarization Anisotropy
% Features:
%   (a) High-density scattering spectra (401 points) for Linear-X, Linear-45°, LCP, Elliptical
%   (b) Corner selective enhancement (Delta Sigma) with dual y-axes and shaded enhancement band
%   (c) Real MNPBEM 2D near-field map |E/E0|^2 at Corner Resonance (2.47 eV) under Diagonal polarization
%   (d) Real MNPBEM 2D near-field map |E/E0|^2 at Face Resonance (3.65 eV) under Axial polarization

if nargin < 1 || isempty(data)
    curr_dir = fileparts(mfilename('fullpath'));
    mat_file = fullfile(curr_dir, 'polarization_data.mat');
    if ~exist(mat_file, 'file')
        error('polarization_data.mat not found. Run compute_polarization_bem_data first.');
    end
    loaded = load(mat_file);
    data = loaded.data;
end

curr_dir = fileparts(mfilename('fullpath'));
out_dir = fullfile(curr_dir, 'figures');
if ~exist(out_dir, 'dir'), mkdir(out_dir); end

fprintf('Generating Publication-Quality Figure P2: Conformal Al Nanocube Polarization Anisotropy...\n');

fig = figure('Color', 'w', 'Units', 'pixels', 'Position', [40, 40, 960, 680], 'Visible', 'off');

ene_plot = data.ene_dense;
cube = data.cube_conformal;

%% (a) Scattering Cross Sections (401 Points)
ax1 = subplot(2, 2, 1);
hold(ax1, 'on'); grid(ax1, 'on'); box(ax1, 'on');
set(ax1, 'FontName', 'Helvetica', 'FontSize', 11, 'LineWidth', 1.2, 'TickDir', 'in', 'XMinorTick', 'on', 'YMinorTick', 'on');

sca_x  = cube.sca_lin_x_dense / 1e4;
sca_45 = cube.sca_lin_45_dense / 1e4;
sca_lc = cube.sca_lcp_dense / 1e4;
sca_el = cube.sca_ell_dense / 1e4;

p1 = plot(ax1, ene_plot, sca_x,  'b-',  'LineWidth', 2.5, 'DisplayName', 'Linear-X (Face mode)');
p2 = plot(ax1, ene_plot, sca_45, 'r--', 'LineWidth', 2.5, 'DisplayName', 'Linear-45° (Corner mode)');
p3 = plot(ax1, ene_plot, sca_lc, 'g-.', 'LineWidth', 2.2, 'DisplayName', 'Circular (LCP)');
p4 = plot(ax1, ene_plot, sca_el, 'm:',  'LineWidth', 2.2, 'DisplayName', 'Elliptical (2:1)');

% Mode resonance indicators
xline(ax1, 2.47, 'k--', 'Corner Mode (2.47 eV)', 'LabelVerticalAlignment', 'bottom', 'FontSize', 9.5, 'HandleVisibility', 'off');
xline(ax1, 3.10, 'k:',  'Edge Mode (3.10 eV)',   'LabelVerticalAlignment', 'middle', 'FontSize', 9.5, 'HandleVisibility', 'off');
xline(ax1, 3.65, 'k--', 'Face Mode (3.65 eV)',   'LabelVerticalAlignment', 'top',    'FontSize', 9.5, 'HandleVisibility', 'off');

xlabel(ax1, 'Energy (eV)', 'FontSize', 11.5, 'FontWeight', 'bold');
ylabel(ax1, 'Scattering Cross Section (nm^2) \times 10^4', 'FontSize', 11.5, 'FontWeight', 'bold');
title(ax1, '{\bf(a)} Conformal Nanocube: Polarized Scattering', 'FontSize', 12.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
legend(ax1, [p1, p2, p3, p4], 'Location', 'northeast', 'FontSize', 9.5);
xlim(ax1, [1.5, 5.5]);
ylim(ax1, [0, max([sca_x, sca_45]) * 1.2]);

% Dual top axis: Wavelength
ax1_top = axes('Position', get(ax1, 'Position'), 'XAxisLocation', 'top', ...
               'YAxisLocation', 'right', 'Color', 'none', 'XColor', [0.2 0.2 0.2], ...
               'YColor', 'none', 'FontName', 'Helvetica', 'FontSize', 10, 'LineWidth', 1.2, 'TickDir', 'in');
linkaxes([ax1, ax1_top], 'y');
wl_ticks = [800, 600, 500, 400, 300, 240];
ene_ticks_top = 1239.84 ./ wl_ticks;
set(ax1_top, 'XLim', [1.5, 5.5], 'XTick', ene_ticks_top, 'XTickLabel', arrayfun(@(w) sprintf('%d nm', w), wl_ticks, 'UniformOutput', false));

%% (b) Corner Selective Enhancement (Delta Sigma)
ax2 = subplot(2, 2, 2);
hold(ax2, 'on'); grid(ax2, 'on'); box(ax2, 'on');
set(ax2, 'FontName', 'Helvetica', 'FontSize', 11, 'LineWidth', 1.2, 'TickDir', 'in', 'XMinorTick', 'on', 'YMinorTick', 'on');

delta_sca = sca_45 - sca_x;

% Shaded positive enhancement zone
fill(ax2, [ene_plot, fliplr(ene_plot)], [zeros(size(delta_sca)), fliplr(max(0, delta_sca))], ...
     [0.9, 0.4, 0.4], 'FaceAlpha', 0.2, 'EdgeColor', 'none', 'DisplayName', 'Corner Selective Gain');

yyaxis(ax2, 'left');
plot(ax2, ene_plot, sca_45, 'r-', 'LineWidth', 2.4, 'DisplayName', '\sigma_{sca} (Diagonal 45°)');
plot(ax2, ene_plot, sca_x,  'b-', 'LineWidth', 2.4, 'DisplayName', '\sigma_{sca} (Axial X)');
ylabel(ax2, 'Cross Section (nm^2) \times 10^4', 'FontSize', 11.5, 'FontWeight', 'bold');
set(ax2, 'YColor', [0.15 0.15 0.15], 'FontSize', 11);

yyaxis(ax2, 'right');
plot(ax2, ene_plot, delta_sca, 'k-', 'LineWidth', 2.4, 'DisplayName', '\Delta\sigma_{sca} (Diag - Axial)');
ylabel(ax2, 'Corner Anisotropy \Delta\sigma_{sca} (nm^2) \times 10^4', 'FontSize', 11.5, 'FontWeight', 'bold');
set(ax2, 'YColor', [0 0 0], 'FontSize', 11);

yline(ax2, 0, 'k:', 'LineWidth', 1.0, 'HandleVisibility', 'off');
xlabel(ax2, 'Energy (eV)', 'FontSize', 11.5, 'FontWeight', 'bold');
title(ax2, '{\bf(b)} Corner Mode Anisotropy (\Delta\sigma = \sigma_{45^\circ} - \sigma_{0^\circ})', ...
      'FontSize', 12.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
legend(ax2, 'Location', 'northwest', 'FontSize', 9.5);
xlim(ax2, [1.5, 5.5]);

%% (c) Real MNPBEM Near-Field Map: Corner Mode (2.47 eV, Linear-45°)
ax3 = subplot(2, 2, 3);
hold(ax3, 'on'); box(ax3, 'on');
set(ax3, 'FontName', 'Helvetica', 'FontSize', 11, 'LineWidth', 1.2, 'TickDir', 'in');

gx = cube.grid_x(1, :);
gy = cube.grid_y(:, 1);
ee_corner = cube.nearfield_corner_ee.^2; % Intensity |E/E0|^2

imagesc(ax3, gx, gy, ee_corner);
colormap(ax3, hot(256));
cb3 = colorbar(ax3, 'Location', 'eastoutside');
cb3.Label.String = '|E / E_0|^2 (Diagonal 45° Pol.)';
cb3.Label.FontWeight = 'bold';
cb3.Label.FontSize = 10.5;
cb3.TickDirection = 'in';

% Draw rounded cube contour
rectangle(ax3, 'Position', [-50, -50, 100, 100], 'Curvature', 0.25, ...
          'EdgeColor', 'cyan', 'LineWidth', 2.2);

% Incident electric field polarization arrow
quiver(ax3, -65, -65, 24, 24, 0, 'w', 'LineWidth', 2.5, 'MaxHeadSize', 2);
text(ax3, -65, -38, '\bf\itE_{45^\circ}\rm', 'Color', 'w', 'FontSize', 11.5, 'FontWeight', 'bold');

axis(ax3, 'image');
xlabel(ax3, 'x position (nm)', 'FontSize', 11, 'FontWeight', 'bold');
ylabel(ax3, 'y position (nm)', 'FontSize', 11, 'FontWeight', 'bold');
title(ax3, '{\bf(c)} Real BEM Field: Corner Hot-Spots (2.47 eV)', 'FontSize', 12.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');

%% (d) Real MNPBEM Near-Field Map: Face Mode (3.65 eV, Linear-X)
ax4 = subplot(2, 2, 4);
hold(ax4, 'on'); box(ax4, 'on');
set(ax4, 'FontName', 'Helvetica', 'FontSize', 11, 'LineWidth', 1.2, 'TickDir', 'in');

ee_face = cube.nearfield_face_ee.^2;

imagesc(ax4, gx, gy, ee_face);
colormap(ax4, hot(256));
cb4 = colorbar(ax4, 'Location', 'eastoutside');
cb4.Label.String = '|E / E_0|^2 (Axial X Pol.)';
cb4.Label.FontWeight = 'bold';
cb4.Label.FontSize = 10.5;
cb4.TickDirection = 'in';

% Draw rounded cube contour
rectangle(ax4, 'Position', [-50, -50, 100, 100], 'Curvature', 0.25, ...
          'EdgeColor', 'cyan', 'LineWidth', 2.2);

% Incident electric field polarization arrow along X
quiver(ax4, -65, 0, 28, 0, 0, 'w', 'LineWidth', 2.5, 'MaxHeadSize', 2);
text(ax4, -65, 12, '\bf\itE_x\rm', 'Color', 'w', 'FontSize', 11.5, 'FontWeight', 'bold');

axis(ax4, 'image');
xlabel(ax4, 'x position (nm)', 'FontSize', 11, 'FontWeight', 'bold');
ylabel(ax4, 'y position (nm)', 'FontSize', 11, 'FontWeight', 'bold');
title(ax4, '{\bf(d)} Real BEM Field: Lateral Face Localization (3.65 eV)', 'FontSize', 12.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');

% High-resolution publication exports
png_file = fullfile(out_dir, 'Figure_P2_conformal_nanocube_polarization.png');
pdf_file = fullfile(out_dir, 'Figure_P2_conformal_nanocube_polarization.pdf');
exportgraphics(fig, png_file, 'Resolution', 300);
exportgraphics(fig, pdf_file, 'ContentType', 'vector');
fprintf('Exported Publication Figure P2 to: %s\n', png_file);
end
