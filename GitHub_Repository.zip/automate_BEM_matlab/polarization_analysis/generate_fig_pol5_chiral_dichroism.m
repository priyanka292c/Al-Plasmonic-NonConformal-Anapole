function fig = generate_fig_pol5_chiral_dichroism(data)
% GENERATE_FIG_POL5_CHIRAL_DICHROISM - Publication-Grade Figure P5: Extrinsic Circular Dichroism under Oblique Incidence
% Features:
%   (a) 3D Oblique illumination geometry and chiral symmetry breaking
%   (b) High-density LCP vs RCP spectra (401 points, dual eV/nm axes) with shaded dichroism band
%   (c) Extrinsic Circular Dichroism Delta Sigma = Sigma_LCP - Sigma_RCP with color-filled lobes
%   (d) Kuhn's dissymmetry factor g(omega) across 1.5 - 5.5 eV with labeled resonance extrema

if nargin < 1 || isempty(data)
    curr_dir = fileparts(mfilename('fullpath'));
    mat_file = fullfile(curr_dir, 'polarization_data.mat');
    if ~exist(mat_file, 'file')
        error('polarization_data.mat not found. Run compute_polarization_bem_data first.');
    end
    loaded = load(mat_file);
    data = loaded.data;
end

curr_dir = fileparts(mfilename('fullpath'));
out_dir = fullfile(curr_dir, 'figures');
if ~exist(out_dir, 'dir'), mkdir(out_dir); end

fprintf('Generating Publication-Quality Figure P5: Chiral Oblique Circular Dichroism...\n');

fig = figure('Color', 'w', 'Units', 'pixels', 'Position', [40, 40, 960, 680], 'Visible', 'off');

ene_plot = data.ene_dense;
obl = data.oblique;

%% (a) 3D Oblique Chiral Illumination Schematic
ax1 = subplot(2, 2, 1);
hold(ax1, 'on'); box(ax1, 'on'); grid(ax1, 'on');
set(ax1, 'FontName', 'Helvetica', 'FontSize', 11, 'LineWidth', 1.2);

% Draw 3D nanocube
v_cube = data.cube_conformal.mesh.verts;
f_cube = data.cube_conformal.mesh.faces;
patch('Parent', ax1, 'Vertices', v_cube, 'Faces', f_cube, ...
      'FaceColor', [0.75, 0.82, 0.90], 'EdgeColor', [0.3, 0.4, 0.6], 'EdgeAlpha', 0.6, ...
      'FaceLighting', 'gouraud', 'SpecularStrength', 0.5);

% Oblique incident beam arrow (theta = 45° in X-Z plane)
quiver3(ax1, -120, 0, 120, 80, 0, -80, 0, 'Color', [0.85, 0.15, 0.15], 'LineWidth', 3.0, 'MaxHeadSize', 2.5);
text(ax1, -115, 0, 130, '\bfk_{inc} (\\theta = 45^\circ)\rm', 'Color', [0.85, 0.15, 0.15], 'FontSize', 11.5, 'FontWeight', 'bold');

% Incident LCP spiral ribbon along the beam
t_beam = linspace(0, 1, 150);
x_beam = -120 + 80 * t_beam;
z_beam =  120 - 80 * t_beam;
r_beam = 15;
% Transverse vectors: u1 = [0, 1, 0], u2 = [-1, 0, 1]/sqrt(2)
y_spiral = r_beam * sin(6 * pi * t_beam);
x_spiral = x_beam - (r_beam/sqrt(2)) * cos(6 * pi * t_beam);
z_spiral = z_beam + (r_beam/sqrt(2)) * cos(6 * pi * t_beam);
plot3(ax1, x_spiral, y_spiral, z_spiral, 'Color', [0.15, 0.65, 0.2], 'LineWidth', 2.4);
text(ax1, -60, 25, 80, '\bfLCP Helicity\rm', 'Color', [0.15, 0.65, 0.2], 'FontSize', 10.5, 'FontWeight', 'bold');

% Coordinate axes
quiver3(ax1, -60, -60, -60, 40, 0, 0, 0, 'k', 'LineWidth', 1.6); text(ax1, -15, -60, -60, 'X', 'FontSize', 10.5, 'FontWeight', 'bold');
quiver3(ax1, -60, -60, -60, 0, 40, 0, 0, 'k', 'LineWidth', 1.6); text(ax1, -60, -15, -60, 'Y', 'FontSize', 10.5, 'FontWeight', 'bold');
quiver3(ax1, -60, -60, -60, 0, 0, 40, 0, 'k', 'LineWidth', 1.6); text(ax1, -60, -60, -15, 'Z', 'FontSize', 10.5, 'FontWeight', 'bold');

camlight(ax1, 45, 30);
lighting(ax1, 'gouraud');
view(ax1, [38, 22]);
axis(ax1, 'equal');
xlim(ax1, [-140, 75]); ylim(ax1, [-75, 75]); zlim(ax1, [-75, 140]);
camzoom(ax1, 1.35);
title(ax1, '{\bf(a)} Oblique Illumination & Chiral Symmetry Breaking', ...
      'FontSize', 12.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');

%% (b) High-Density LCP vs RCP Spectra (401 Points)
ax2 = subplot(2, 2, 2);
hold(ax2, 'on'); grid(ax2, 'on'); box(ax2, 'on');
set(ax2, 'FontName', 'Helvetica', 'FontSize', 11, 'LineWidth', 1.2, 'TickDir', 'in', 'XMinorTick', 'on', 'YMinorTick', 'on');

ext_lcp = obl.ext_lcp_dense / 1e4;
ext_rcp = obl.ext_rcp_dense / 1e4;
sca_lcp = obl.sca_lcp_dense / 1e4;
sca_rcp = obl.sca_rcp_dense / 1e4;

% Subtle shaded gap between LCP and RCP extinction
fill(ax2, [ene_plot, fliplr(ene_plot)], [ext_lcp, fliplr(ext_rcp)], ...
     [0.85, 0.65, 0.95], 'FaceAlpha', 0.35, 'EdgeColor', 'none', 'DisplayName', 'Dichroic Split (\Delta\sigma)');

p1 = plot(ax2, ene_plot, ext_lcp, 'b-',  'LineWidth', 2.5, 'DisplayName', 'Extinction LCP (\sigma_{LCP})');
p2 = plot(ax2, ene_plot, ext_rcp, 'r--', 'LineWidth', 2.5, 'DisplayName', 'Extinction RCP (\sigma_{RCP})');
p3 = plot(ax2, ene_plot, sca_lcp, 'g-.', 'LineWidth', 2.0, 'DisplayName', 'Scattering LCP');
p4 = plot(ax2, ene_plot, sca_rcp, 'm:',  'LineWidth', 2.0, 'DisplayName', 'Scattering RCP');

xlabel(ax2, 'Energy (eV)', 'FontSize', 11.5, 'FontWeight', 'bold');
ylabel(ax2, 'Cross Section (nm^2) \times 10^4', 'FontSize', 11.5, 'FontWeight', 'bold');
title(ax2, '{\bf(b)} Extinction & Scattering: Oblique LCP vs RCP', 'FontSize', 12.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
legend(ax2, [p1, p2, p3, p4], 'Location', 'northeast', 'FontSize', 9.5);
xlim(ax2, [1.5, 5.5]);
ylim(ax2, [0, max([ext_lcp, ext_rcp]) * 1.2]);

% Dual top axis: Wavelength
ax2_top = axes('Position', get(ax2, 'Position'), 'XAxisLocation', 'top', ...
               'YAxisLocation', 'right', 'Color', 'none', 'XColor', [0.2 0.2 0.2], ...
               'YColor', 'none', 'FontName', 'Helvetica', 'FontSize', 10, 'LineWidth', 1.2, 'TickDir', 'in');
linkaxes([ax2, ax2_top], 'y');
wl_ticks = [800, 600, 500, 400, 300, 240];
ene_ticks_top = 1239.84 ./ wl_ticks;
set(ax2_top, 'XLim', [1.5, 5.5], 'XTick', ene_ticks_top, 'XTickLabel', arrayfun(@(w) sprintf('%d nm', w), wl_ticks, 'UniformOutput', false));

%% (c) Extrinsic Circular Dichroism (CD_ext = Sigma_LCP - Sigma_RCP)
ax3 = subplot(2, 2, 3);
hold(ax3, 'on'); grid(ax3, 'on'); box(ax3, 'on');
set(ax3, 'FontName', 'Helvetica', 'FontSize', 11, 'LineWidth', 1.2, 'TickDir', 'in', 'XMinorTick', 'on', 'YMinorTick', 'on');

cd_ext = obl.cd_ext_dense; % in nm^2
cd_sca = obl.cd_sca_dense;

% Color filled positive and negative lobes
cd_pos = max(0, cd_ext);
cd_neg = min(0, cd_ext);

fill(ax3, [ene_plot, fliplr(ene_plot)], [zeros(size(cd_pos)), fliplr(cd_pos)], ...
     [0.2, 0.45, 0.85], 'FaceAlpha', 0.25, 'EdgeColor', 'none', 'DisplayName', 'Positive CD (LCP dominant)');
fill(ax3, [ene_plot, fliplr(ene_plot)], [zeros(size(cd_neg)), fliplr(cd_neg)], ...
     [0.85, 0.25, 0.25], 'FaceAlpha', 0.25, 'EdgeColor', 'none', 'DisplayName', 'Negative CD (RCP dominant)');

p_cd_ext = plot(ax3, ene_plot, cd_ext, 'k-',  'LineWidth', 2.5, 'DisplayName', 'CD Extinction (\Delta\sigma_{ext})');
p_cd_sca = plot(ax3, ene_plot, cd_sca, 'm--', 'LineWidth', 2.0, 'DisplayName', 'CD Scattering (\Delta\sigma_{sca})');

yline(ax3, 0, 'k:', 'LineWidth', 1.0, 'HandleVisibility', 'off');

xlabel(ax3, 'Energy (eV)', 'FontSize', 11.5, 'FontWeight', 'bold');
ylabel(ax3, 'Circular Dichroism \Delta\sigma (nm^2)', 'FontSize', 11.5, 'FontWeight', 'bold');
title(ax3, '{\bf(c)} Extrinsic Circular Dichroism (\Delta\sigma = \sigma_{LCP} - \sigma_{RCP})', ...
      'FontSize', 12.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
legend(ax3, [p_cd_ext, p_cd_sca], 'Location', 'northwest', 'FontSize', 9.5);
xlim(ax3, [1.5, 5.5]);

%% (d) Kuhn's Dissymmetry Factor g(omega)
ax4 = subplot(2, 2, 4);
hold(ax4, 'on'); grid(ax4, 'on'); box(ax4, 'on');
set(ax4, 'FontName', 'Helvetica', 'FontSize', 11, 'LineWidth', 1.2, 'TickDir', 'in', 'XMinorTick', 'on', 'YMinorTick', 'on');

g_dense = obl.g_factor_dense;

plot(ax4, ene_plot, g_dense * 1e3, 'Color', [0.45, 0.15, 0.65], 'LineWidth', 2.5, 'DisplayName', 'Kuhn g-factor \times 10^3');
yline(ax4, 0, 'k:', 'LineWidth', 1.0, 'HandleVisibility', 'off');

% Peak dissymmetry labels
[g_max, i_gmax] = max(g_dense);
[g_min, i_gmin] = min(g_dense);

plot(ax4, ene_plot(i_gmax), g_max*1e3, 'ro', 'MarkerFaceColor', 'r', 'MarkerSize', 7, 'HandleVisibility', 'off');
text(ax4, ene_plot(i_gmax), g_max*1e3 + 0.35, sprintf('g_{max} = +%.2f \\times 10^{-3}', g_max*1e3), ...
     'FontSize', 10, 'HorizontalAlignment', 'center', 'FontWeight', 'bold');

plot(ax4, ene_plot(i_gmin), g_min*1e3, 'bo', 'MarkerFaceColor', 'b', 'MarkerSize', 7, 'HandleVisibility', 'off');
text(ax4, ene_plot(i_gmin), g_min*1e3 - 0.35, sprintf('g_{min} = %.2f \\times 10^{-3}', g_min*1e3), ...
     'FontSize', 10, 'HorizontalAlignment', 'center', 'FontWeight', 'bold');

xlabel(ax4, 'Energy (eV)', 'FontSize', 11.5, 'FontWeight', 'bold');
ylabel(ax4, 'Dissymmetry Factor g(\omega) \times 10^{-3}', 'FontSize', 11.5, 'FontWeight', 'bold');
title(ax4, '{\bf(d)} Kuhn Dissymmetry Factor g = 2\Delta\sigma / (\sigma_{LCP} + \sigma_{RCP})', ...
      'FontSize', 12.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
legend(ax4, 'Location', 'northeast', 'FontSize', 9.5);
xlim(ax4, [1.5, 5.5]);

% High-resolution publication exports
png_file = fullfile(out_dir, 'Figure_P5_chiral_oblique_dichroism.png');
pdf_file = fullfile(out_dir, 'Figure_P5_chiral_oblique_dichroism.pdf');
exportgraphics(fig, png_file, 'Resolution', 300);
exportgraphics(fig, pdf_file, 'ContentType', 'vector');
fprintf('Exported Publication Figure P5 to: %s\n', png_file);
end
