function fig = generate_fig_pol1_sphere(data)
% GENERATE_FIG_POL1_SPHERE - Publication-Grade Figure P1: Polarized Light Interaction on Al Nanosphere
% Features:
%   (a) 3D Helical & Elliptical E-field trajectories with transverse projections and spin helicity
%   (b) High-density optical spectra (401 points, ext, sca, abs) with dual Energy/Wavelength axes
%   (c) Full Stokes polarimetry & Poincaré sweep with shaded polarization domains
%   (d) True 3D electrodynamic surface charge on the discretized sphere mesh (Linear, LCP, Elliptical)

if nargin < 1 || isempty(data)
    curr_dir = fileparts(mfilename('fullpath'));
    mat_file = fullfile(curr_dir, 'polarization_data.mat');
    if ~exist(mat_file, 'file')
        error('polarization_data.mat not found. Run compute_polarization_bem_data first.');
    end
    loaded = load(mat_file);
    data = loaded.data;
end

curr_dir = fileparts(mfilename('fullpath'));
out_dir = fullfile(curr_dir, 'figures');
if ~exist(out_dir, 'dir'), mkdir(out_dir); end

fprintf('Generating Publication-Quality Figure P1: Polarized Light on Al Nanosphere...\n');

fig = figure('Color', 'w', 'Units', 'pixels', 'Position', [40, 40, 960, 680], 'Visible', 'off');

% Use dense grid
ene_plot = data.ene_dense;
wl_plot = data.enei_dense;

%% (a) 3D Polarization Helices & Transverse Projections
ax1 = subplot(2, 2, 1);
hold(ax1, 'on'); grid(ax1, 'on'); box(ax1, 'on');
set(ax1, 'FontName', 'Helvetica', 'FontSize', 11, 'LineWidth', 1.2, 'TickDir', 'in');

z_prop = linspace(0, 4*pi, 400);
z_norm = z_prop / (4*pi) * 100;

% Offsets for 4 states
x_offs = [-3.3, -1.1, 1.1, 3.3];

% 1. Linear (e_x)
x_lin = cos(z_prop); y_lin = zeros(size(z_prop));
plot3(ax1, x_lin + x_offs(1), y_lin, z_norm, 'Color', [0.12, 0.47, 0.71], 'LineWidth', 2.2);

% 2. Circular (LCP, Left-handed helix)
x_lcp = cos(z_prop)/sqrt(2); y_lcp = sin(z_prop)/sqrt(2);
plot3(ax1, x_lcp + x_offs(2), y_lcp, z_norm, 'Color', [0.17, 0.63, 0.17], 'LineWidth', 2.2);

% 3. Circular (RCP, Right-handed helix)
x_rcp = cos(z_prop)/sqrt(2); y_rcp = -sin(z_prop)/sqrt(2);
plot3(ax1, x_rcp + x_offs(3), y_rcp, z_norm, 'Color', [0.58, 0.40, 0.74], 'LineWidth', 2.2);

% 4. Elliptical (2:1 Eccentricity)
x_ell = (2/sqrt(5))*cos(z_prop); y_ell = (1/sqrt(5))*sin(z_prop);
plot3(ax1, x_ell + x_offs(4), y_ell, z_norm, 'Color', [0.84, 0.15, 0.16], 'LineWidth', 2.2);

% Draw transverse polarization projection rings at base (z = 0)
th_ring = linspace(0, 2*pi, 100);
plot3(ax1, cos(th_ring) + x_offs(1), zeros(size(th_ring)), zeros(size(th_ring)), 'k:', 'LineWidth', 1.2);
plot3(ax1, cos(th_ring)/sqrt(2) + x_offs(2), sin(th_ring)/sqrt(2), zeros(size(th_ring)), 'k:', 'LineWidth', 1.2);
plot3(ax1, cos(th_ring)/sqrt(2) + x_offs(3), -sin(th_ring)/sqrt(2), zeros(size(th_ring)), 'k:', 'LineWidth', 1.2);
plot3(ax1, 2/sqrt(5)*cos(th_ring) + x_offs(4), 1/sqrt(5)*sin(th_ring), zeros(size(th_ring)), 'k:', 'LineWidth', 1.2);

% Propagation direction vector arrows
quiver3(ax1, x_offs(1), 0, 102, 0, 0, 14, 'k', 'LineWidth', 2.0, 'MaxHeadSize', 2);
quiver3(ax1, x_offs(2), 0, 102, 0, 0, 14, 'k', 'LineWidth', 2.0, 'MaxHeadSize', 2);
quiver3(ax1, x_offs(3), 0, 102, 0, 0, 14, 'k', 'LineWidth', 2.0, 'MaxHeadSize', 2);
quiver3(ax1, x_offs(4), 0, 102, 0, 0, 14, 'k', 'LineWidth', 2.0, 'MaxHeadSize', 2);

text(ax1, x_offs(1), 0, -12, 'Linear (\bf\ite_x\rm)', 'HorizontalAlignment', 'center', 'FontSize', 10.5, 'FontWeight', 'bold');
text(ax1, x_offs(2), 0, -12, 'Circular (\bfLCP\rm)', 'HorizontalAlignment', 'center', 'FontSize', 10.5, 'FontWeight', 'bold');
text(ax1, x_offs(3), 0, -12, 'Circular (\bfRCP\rm)', 'HorizontalAlignment', 'center', 'FontSize', 10.5, 'FontWeight', 'bold');
text(ax1, x_offs(4), 0, -12, 'Elliptical (\bf2:1\rm)', 'HorizontalAlignment', 'center', 'FontSize', 10.5, 'FontWeight', 'bold');

view(ax1, [24, 22]);
xlabel(ax1, 'Polarization X', 'FontWeight', 'bold', 'FontSize', 11);
ylabel(ax1, 'Polarization Y', 'FontWeight', 'bold', 'FontSize', 11);
zlabel(ax1, 'Propagation z (nm)', 'FontWeight', 'bold', 'FontSize', 11);
axis(ax1, [-4.8, 4.8, -1.8, 1.8, -20, 125]);
title(ax1, '{\bf(a)} Electric Field Helicity & Propagation States', 'FontSize', 12.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');

%% (b) High-Density Optical Cross Sections (401 Points)
ax2 = subplot(2, 2, 2);
hold(ax2, 'on'); grid(ax2, 'on'); box(ax2, 'on');
set(ax2, 'FontName', 'Helvetica', 'FontSize', 11, 'LineWidth', 1.2, 'TickDir', 'in', 'XMinorTick', 'on', 'YMinorTick', 'on');

ext_dense = data.sphere.ext_lin_dense / 1e4;
sca_dense = data.sphere.sca_lin_dense / 1e4;
abs_dense = data.sphere.abs_lin_dense / 1e4;

% Translucent shaded absorption area under curve
fill(ax2, [ene_plot, fliplr(ene_plot)], [zeros(size(abs_dense)), fliplr(abs_dense)], ...
     [0.85, 0.3, 0.3], 'FaceAlpha', 0.15, 'EdgeColor', 'none', 'DisplayName', 'Absorption Region');

p1 = plot(ax2, ene_plot, ext_dense, 'k-',  'LineWidth', 2.6, 'DisplayName', 'Extinction (\sigma_{ext})');
p2 = plot(ax2, ene_plot, sca_dense, 'b-',  'LineWidth', 2.2, 'DisplayName', 'Scattering Linear (\sigma_{sca})');
p3 = plot(ax2, ene_plot, abs_dense, 'r--', 'LineWidth', 2.2, 'DisplayName', 'Absorption (\sigma_{abs})');
p4 = plot(ax2, ene_plot, data.sphere.sca_lcp_dense / 1e4, 'g:', 'LineWidth', 2.2, 'DisplayName', 'Scattering Circular (LCP)');
p5 = plot(ax2, ene_plot, data.sphere.sca_ell_dense / 1e4, 'm-.', 'LineWidth', 2.0, 'DisplayName', 'Scattering Elliptical (2:1)');

% Multipolar peak drop lines and annotations
[~, i_p1] = max(ext_dense(ene_plot >= 2.6 & ene_plot <= 3.2));
ene_sub = ene_plot(ene_plot >= 2.6 & ene_plot <= 3.2);
peak1_e = ene_sub(i_p1); peak1_val = ext_dense(ene_plot == peak1_e);

plot(ax2, [peak1_e, peak1_e], [0, peak1_val], 'k:', 'LineWidth', 1.2, 'HandleVisibility', 'off');
text(ax2, peak1_e, peak1_val*1.05, sprintf('\\bfDipole (l=1)\n%.2f eV', peak1_e), ...
     'FontSize', 10, 'HorizontalAlignment', 'center', 'Color', [0.1, 0.1, 0.7]);

% Secondary Quadrupole mark
text(ax2, 3.85, peak1_val*0.62, {'\bfQuadrupole (l=2)', '3.85 eV'}, ...
     'FontSize', 10, 'HorizontalAlignment', 'center', 'Color', [0.7, 0.1, 0.1]);

xlabel(ax2, 'Energy (eV)', 'FontSize', 11.5, 'FontWeight', 'bold');
ylabel(ax2, 'Cross Section (nm^2) \times 10^4', 'FontSize', 11.5, 'FontWeight', 'bold');
title(ax2, '{\bf(b)} Core-Shell Al Sphere: High-Resolution Spectra', 'FontSize', 12.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
legend(ax2, [p1, p2, p3, p4, p5], 'Location', 'northeast', 'FontSize', 9.5);
xlim(ax2, [1.5, 5.5]);
ylim(ax2, [0, peak1_val * 1.22]);

% Add dual top axis showing wavelength (nm)
ax2_top = axes('Position', get(ax2, 'Position'), 'XAxisLocation', 'top', ...
               'YAxisLocation', 'right', 'Color', 'none', 'XColor', [0.2 0.2 0.2], ...
               'YColor', 'none', 'FontName', 'Helvetica', 'FontSize', 10, 'LineWidth', 1.2, 'TickDir', 'in');
linkaxes([ax2, ax2_top], 'y');
wl_ticks = [800, 600, 500, 400, 300, 240];
ene_ticks_top = 1239.84 ./ wl_ticks;
set(ax2_top, 'XLim', [1.5, 5.5], 'XTick', ene_ticks_top, 'XTickLabel', arrayfun(@(w) sprintf('%d nm', w), wl_ticks, 'UniformOutput', false));

%% (c) Stokes Parameters & Poincaré Sweep
ax3 = subplot(2, 2, 3);
hold(ax3, 'on'); grid(ax3, 'on'); box(ax3, 'on');
set(ax3, 'FontName', 'Helvetica', 'FontSize', 11, 'LineWidth', 1.2, 'TickDir', 'in', 'XMinorTick', 'on', 'YMinorTick', 'on');

chi_deg = linspace(-45, 45, 250);
chi_rad = deg2rad(chi_deg);
S1 = cos(2 * chi_rad);
S3 = sin(2 * chi_rad);
DOCP = S3;

% Shaded color zones for polarization domains
fill(ax3, [-45, -30, -30, -45], [-1.2, -1.2, 1.2, 1.2], [0.95, 0.88, 0.95], 'EdgeColor', 'none', 'DisplayName', 'RCP Domain');
fill(ax3, [-30, -10, -10, -30], [-1.2, -1.2, 1.2, 1.2], [0.98, 0.92, 0.88], 'EdgeColor', 'none', 'DisplayName', 'Elliptical Left');
fill(ax3, [-10,  10,  10, -10], [-1.2, -1.2, 1.2, 1.2], [0.90, 0.93, 0.98], 'EdgeColor', 'none', 'DisplayName', 'Linear Domain');
fill(ax3, [ 10,  30,  30,  10], [-1.2, -1.2, 1.2, 1.2], [0.98, 0.92, 0.88], 'EdgeColor', 'none', 'HandleVisibility', 'off');
fill(ax3, [ 30,  45,  45,  30], [-1.2, -1.2, 1.2, 1.2], [0.88, 0.96, 0.88], 'EdgeColor', 'none', 'DisplayName', 'LCP Domain');

plot(ax3, chi_deg, S1, 'b-', 'LineWidth', 2.4, 'DisplayName', 'S_1 / S_0 (Linearity)');
plot(ax3, chi_deg, S3, 'r-', 'LineWidth', 2.4, 'DisplayName', 'S_3 / S_0 (Helicity)');
plot(ax3, chi_deg, DOCP, 'k--', 'LineWidth', 1.8, 'DisplayName', 'DOCP (Degree Circ. Pol.)');

plot(ax3, [-45, 45], [0, 0], 'k-', 'LineWidth', 0.8, 'HandleVisibility', 'off');
xline(ax3, 0, 'k:', 'LineWidth', 1.2, 'HandleVisibility', 'off');

xlabel(ax3, 'Ellipticity Angle \chi (degrees)', 'FontSize', 11.5, 'FontWeight', 'bold');
ylabel(ax3, 'Normalized Stokes Parameters', 'FontSize', 11.5, 'FontWeight', 'bold');
title(ax3, '{\bf(c)} Stokes Poincaré Sweep: RCP \leftrightarrow Linear \leftrightarrow LCP', ...
      'FontSize', 12.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
legend(ax3, 'Location', 'northwest', 'FontSize', 9.5);
xlim(ax3, [-45, 45]); ylim(ax3, [-1.2, 1.2]);

%% (d) True 3D Discretized Surface Charge Density (Linear, LCP, Elliptical)
ax4 = subplot(2, 2, 4);
hold(ax4, 'on'); box(ax4, 'on'); axis(ax4, 'off');

% Mesh coordinates of the sphere
v = data.sphere.mesh.verts;
f = data.sphere.mesh.faces;
n_v = size(v, 1);
n_f = size(f, 1);

% Map 284 face charge values to 144 vertices
sig_raw_lin = real(data.sphere.sig_peak_lin_val(1:n_f));
sig_raw_lcp = real(data.sphere.sig_peak_lcp_val(1:n_f));
sig_raw_ell = real(data.sphere.sig_peak_ell_val(1:n_f));

sig_lin = zeros(n_v, 1); cnt = zeros(n_v, 1);
sig_lcp = zeros(n_v, 1); sig_ell = zeros(n_v, 1);
for fi = 1:n_f
    idx = f(fi, :); idx = idx(idx > 0);
    sig_lin(idx) = sig_lin(idx) + sig_raw_lin(fi);
    sig_lcp(idx) = sig_lcp(idx) + sig_raw_lcp(fi);
    sig_ell(idx) = sig_ell(idx) + sig_raw_ell(fi);
    cnt(idx) = cnt(idx) + 1;
end
cnt(cnt == 0) = 1;
sig_lin = sig_lin ./ cnt;
sig_lcp = sig_lcp ./ cnt;
sig_ell = sig_ell ./ cnt;

% Scale and shift in 3D space
r_scale = 1.0;
x_shifts = [-130, 0, 130];

% Custom coolwarm diverging colormap
n_c = 256;
c_cool = [linspace(0.15, 0.95, n_c/2)', linspace(0.3, 0.95, n_c/2)', linspace(0.85, 0.95, n_c/2)'];
c_warm = [linspace(0.95, 0.85, n_c/2)', linspace(0.95, 0.2, n_c/2)', linspace(0.95, 0.2, n_c/2)'];
cmap_div = [c_cool; c_warm];
colormap(ax4, cmap_div);

% Patch 1: Linear
v1 = v; v1(:, 1) = v1(:, 1) + x_shifts(1);
patch('Parent', ax4, 'Vertices', v1, 'Faces', f, 'FaceVertexCData', sig_lin, ...
      'FaceColor', 'interp', 'EdgeColor', [0.2 0.2 0.2], 'EdgeAlpha', 0.25, ...
      'FaceLighting', 'gouraud', 'AmbientStrength', 0.5, 'DiffuseStrength', 0.7);

% Patch 2: Circular LCP (rotating snapshot at t=0)
v2 = v; v2(:, 1) = v2(:, 1) + x_shifts(2);
patch('Parent', ax4, 'Vertices', v2, 'Faces', f, 'FaceVertexCData', sig_lcp, ...
      'FaceColor', 'interp', 'EdgeColor', [0.2 0.2 0.2], 'EdgeAlpha', 0.25, ...
      'FaceLighting', 'gouraud', 'AmbientStrength', 0.5, 'DiffuseStrength', 0.7);

% Patch 3: Elliptical
v3 = v; v3(:, 1) = v3(:, 1) + x_shifts(3);
patch('Parent', ax4, 'Vertices', v3, 'Faces', f, 'FaceVertexCData', sig_ell, ...
      'FaceColor', 'interp', 'EdgeColor', [0.2 0.2 0.2], 'EdgeAlpha', 0.25, ...
      'FaceLighting', 'gouraud', 'AmbientStrength', 0.5, 'DiffuseStrength', 0.7);

% Add labels above spheres
text(ax4, x_shifts(1), 0, 68, 'Linear (\bf\ite_x\rm)', 'HorizontalAlignment', 'center', 'FontSize', 11, 'FontWeight', 'bold');
text(ax4, x_shifts(2), 0, 68, 'Circular (\bfLCP\rm)', 'HorizontalAlignment', 'center', 'FontSize', 11, 'FontWeight', 'bold');
text(ax4, x_shifts(3), 0, 68, 'Elliptical (\bf2:1\rm)', 'HorizontalAlignment', 'center', 'FontSize', 11, 'FontWeight', 'bold');

view(ax4, [0, 90]);
axis(ax4, 'equal');
xlim(ax4, [-195, 195]); ylim(ax4, [-75, 85]);

% Diverging Colorbar
caxis(ax4, [-max(abs(sig_lin))*0.85, max(abs(sig_lin))*0.85]);
cb = colorbar(ax4, 'Location', 'southoutside', 'Position', [0.55, 0.08, 0.38, 0.026]);
cb.Label.String = 'Instantaneous Surface Charge \Re\{\sigma(\bf\itr\rm)\} (a.u.)';
cb.Label.FontWeight = 'bold';
cb.Label.FontSize = 10.5;
cb.TickDirection = 'in';

title(ax4, sprintf('{\\bf(d)} BEM Surface Charge at Resonance (%.2f eV)', data.sphere.peak_ene), ...
      'FontSize', 12.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');

% High-resolution publication exports
png_file = fullfile(out_dir, 'Figure_P1_polarization_definitions_sphere.png');
pdf_file = fullfile(out_dir, 'Figure_P1_polarization_definitions_sphere.pdf');
exportgraphics(fig, png_file, 'Resolution', 300);
exportgraphics(fig, pdf_file, 'ContentType', 'vector');
fprintf('Exported Publication Figure P1 to: %s\n', png_file);
end
