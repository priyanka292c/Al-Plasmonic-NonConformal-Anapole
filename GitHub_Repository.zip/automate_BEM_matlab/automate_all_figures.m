function automate_all_figures()
% AUTOMATE_ALL_FIGURES - Master script to regenerate ALL figures to publication quality
% Paper: "Electron energy-loss spectroscopy investigation of multipolar behavior
%         in Al nanostructure as a function of surface coating with PVP and oxidation"
% Author: Annu Dahiya, Pandian Senthil Kumar
% Journal: Materials Today Communications 31 (2022) 103668
%
% This master script runs the automated BEM MATLAB pipeline:
%   1. Regenerates all 8 Main Publication Figures (Fig 1 to Fig 8) with true
%      high-density vector data, multi-curve traces, dual axes, and 3D charge maps.
%   2. Runs the Polarized Light Suite (Figures P1 to P5) with circular (LCP/RCP),
%      linear (X/Y/45°), and elliptical polarizations.
%   3. Exports all figures as 300 DPI high-resolution PNGs and vector PDFs.

clc; close all;
fprintf('========================================================================\n');
fprintf('  REGENERATING ALL PUBLICATION FIGURES (MAIN PAPER + POLARIZATION)\n');
fprintf('  Paper: Annu Dahiya & Pandian Senthil Kumar (2022), Mat. Today Commun.\n');
fprintf('========================================================================\n\n');

startTime = tic;

% 1. Initialize environment
env = init_mnpbem_env();
addpath(env.current_dir);
pol_dir = fullfile(env.current_dir, 'polarization_analysis');
if exist(pol_dir, 'dir')
    addpath(pol_dir);
end

% 2. Regenerate Main Figures 1 through 8
fprintf('>>> SECTION 1: MAIN PUBLICATION FIGURES (1 to 8) <<<\n\n');

% Figure 1: Geometry & excitation schematics
h1 = generate_figure1();
close(h1);

% Figure 2: Sphere EELS & optical scattering
h2 = generate_figure2();
close(h2);

% Figure 3: Sphere EELS colormaps & 2D spatial maps
h3 = generate_figure3();
close(h3);

% Figure 4: Conformal nanocube EELS & 2D spatial maps
h4 = generate_figure4();
close(h4);

% Figure 5: Convex nanocube EELS & 2D spatial maps
h5 = generate_figure5();
close(h5);

% Figure 6: 3D Surface charge distribution maps
h6 = generate_figure6();
close(h6);

% Figure 7: Optical scattering cross sections (Ox & RI sweeps)
h7 = generate_figure7();
close(h7);

% Figure 8: Resonance peak energy shifts & regression fits
h8 = generate_figure8();
close(h8);

% 3. Regenerate Polarized Light Figures P1 through P5
fprintf('\n>>> SECTION 2: POLARIZED LIGHT FIGURES (P1 to P5) <<<\n\n');
if exist('automate_all_polarization_figures', 'file') == 2
    automate_all_polarization_figures();
end

totalTime = toc(startTime);

% 4. Master Verification Summary Table
fprintf('\n========================================================================\n');
fprintf('  MASTER VERIFICATION & EXPORT SUMMARY (ALL FIGURES)\n');
fprintf('========================================================================\n');

main_figs = {
    'Figure1_geometry_schematic', ...
    'Figure2_sphere_eels_scattering', ...
    'Figure3_sphere_colormaps_maps', ...
    'Figure4_cube_conformal_eels', ...
    'Figure5_cube_convex_eels', ...
    'Figure6_surface_charge_maps', ...
    'Figure7_optical_scattering', ...
    'Figure8_resonance_energy_shifts'
};

fprintf('\n-- Main Publication Figures (1 - 8) --\n');
all_main_ok = true;
for i = 1:length(main_figs)
    png_f = fullfile(env.out_dir, [main_figs{i}, '.png']);
    pdf_f = fullfile(env.out_dir, [main_figs{i}, '.pdf']);
    
    if exist(png_f, 'file') && exist(pdf_f, 'file')
        d_png = dir(png_f);
        d_pdf = dir(pdf_f);
        fprintf('  [OK] Fig %d: %-35s (PNG: %6.1f KB | PDF: %6.1f KB)\n', ...
                i, main_figs{i}, d_png.bytes/1024, d_pdf.bytes/1024);
    else
        fprintf('  [FAILED] Fig %d: %-35s\n', i, main_figs{i});
        all_main_ok = false;
    end
end

pol_figs = {
    'Figure_P1_polarization_definitions_sphere', ...
    'Figure_P2_conformal_nanocube_polarization', ...
    'Figure_P3_convex_nanocube_polarization', ...
    'Figure_P4_time_resolved_charge_rotation', ...
    'Figure_P5_chiral_oblique_dichroism'
};

fprintf('\n-- Polarized Light Suite Figures (P1 - P5) --\n');
pol_out_dir = fullfile(env.out_dir, 'polarized_light');
all_pol_ok = true;
for j = 1:length(pol_figs)
    png_p = fullfile(pol_out_dir, [pol_figs{j}, '.png']);
    pdf_p = fullfile(pol_out_dir, [pol_figs{j}, '.pdf']);
    
    if exist(png_p, 'file') && exist(pdf_p, 'file')
        dp_png = dir(png_p);
        dp_pdf = dir(pdf_p);
        fprintf('  [OK] Fig P%d: %-40s (PNG: %6.1f KB | PDF: %6.1f KB)\n', ...
                j, pol_figs{j}, dp_png.bytes/1024, dp_pdf.bytes/1024);
    else
        fprintf('  [FAILED] Fig P%d: %-40s\n', j, pol_figs{j});
        all_pol_ok = false;
    end
end

fprintf('\nTotal execution time: %.2f seconds.\n', totalTime);
if all_main_ok && all_pol_ok
    fprintf('SUCCESS: ALL 13 PUBLICATION-GRADE FIGURES GENERATED & EXPORTED!\n');
    fprintf('Output directory: %s\n', env.out_dir);
else
    fprintf('WARNING: Some figures did not export correctly.\n');
end
fprintf('========================================================================\n');
end
