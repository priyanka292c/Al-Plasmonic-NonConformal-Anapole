function env = init_mnpbem_env()
% INIT_MNPBEM_ENV - Initialize MNPBEM toolbox paths and verification
% Paper: "Electron energy-loss spectroscopy investigation of multipolar behavior
%         in Al nanostructure as a function of surface coating with PVP and oxidation"
% Author: Annu Dahiya, Pandian Senthil Kumar (2022)
%
% Returns struct env with verified paths and options.

fprintf('=== Initializing MNPBEM BEM Environment ===\n');

% Candidate MNPBEM paths
candidate_paths = {
    'D:\Priyanka\Research\Submitted\Under review\EM_Gravity_Analogues\MNPBEM\MNPBEM-main', ...
    'D:\Reasearch work\MNPBEM-main\MNPBEM-main', ...
    'D:\Reasearch work\Au@Cu Helices (2)\simulation\MATLAB\MNPBEM'
};

mnpbem_found = false;
mnpbem_path = '';
for i = 1:length(candidate_paths)
    if exist(candidate_paths{i}, 'dir')
        mnpbem_path = candidate_paths{i};
        mnpbem_found = true;
        break;
    end
end

if ~mnpbem_found
    error('MNPBEM toolbox directory not found in candidate paths.');
end

% Add to MATLAB path
addpath(genpath(mnpbem_path));
fprintf('MNPBEM toolbox loaded from: %s\n', mnpbem_path);

% Check materials
mat_dir = fullfile(mnpbem_path, 'Material');
al_file = fullfile(mat_dir, 'aluminum.dat');
al2o3_file = fullfile(mat_dir, 'aluminum_oxide.dat');

if exist(al_file, 'file') && exist(al2o3_file, 'file')
    fprintf('Verified dielectric tables: aluminum.dat and aluminum_oxide.dat found.\n');
else
    warning('Material files missing from Material directory.');
end

% Output directories
current_dir = fileparts(mfilename('fullpath'));
out_dir = fullfile(current_dir, 'regenerated_figures');
if ~exist(out_dir, 'dir')
    mkdir(out_dir);
end

env.mnpbem_path = mnpbem_path;
env.out_dir = out_dir;
env.current_dir = current_dir;
env.mat_file = fullfile(current_dir, 'paper_data.mat');

% Default BEM options for retarded Maxwell solver
env.op = bemoptions('sim', 'ret', 'interp', 'curv');

fprintf('Output directory set to: %s\n', out_dir);
fprintf('Initialization complete.\n\n');
end
