function results = run_live_bem_simulation(varargin)
% RUN_LIVE_BEM_SIMULATION - Automated MNPBEM simulation for Al nanostructures
% Paper: "Electron energy-loss spectroscopy investigation of multipolar behavior
%         in Al nanostructure as a function of surface coating with PVP and oxidation"
%
% Usage:
%   results = run_live_bem_simulation('type', 'sphere', 't_pvp', 1.25, 't_ox', 4, 'n_med', 1.0);
%   results = run_live_bem_simulation('type', 'cube_conformal', 't_pvp', 1.0, 't_ox', 4);
%   results = run_live_bem_simulation('type', 'cube_convex', 't_pvp', 25.0, 't_ox', 4);
%
% Options:
%   'type'       : 'sphere', 'cube_conformal', or 'cube_convex' (default: 'sphere')
%   'size'       : Core size in nm (diameter for sphere, edge for cube, default: 100)
%   't_pvp'      : PVP shell thickness in nm (default: 1.25)
%   't_ox'       : Alumina shell thickness in nm (default: 4.0)
%   'n_med'      : Surrounding medium refractive index (default: 1.0)
%   'n_ene'      : Number of energy points (default: 25 for quick execution)
%   'ene_range'  : Energy range in eV [emin, emax] (default: [1.5, 5.5])
%   'plot_fig'   : true/false (default: true)

env = init_mnpbem_env();

p = inputParser;
addParameter(p, 'type', 'sphere', @ischar);
addParameter(p, 'size', 100, @isnumeric);
addParameter(p, 't_pvp', 1.25, @isnumeric);
addParameter(p, 't_ox', 4.0, @isnumeric);
addParameter(p, 'n_med', 1.0, @isnumeric);
addParameter(p, 'n_ene', 25, @isnumeric);
addParameter(p, 'ene_range', [1.5, 5.5], @isnumeric);
addParameter(p, 'plot_fig', true, @islogical);
parse(p, varargin{:});
opt = p.Results;

fprintf('=====================================================\n');
fprintf('Running Automated BEM Simulation:\n');
fprintf('  Structure: %s\n', opt.type);
fprintf('  Core Size: %d nm\n', opt.size);
fprintf('  PVP Shell: %.2f nm (RI = 1.5274)\n', opt.t_pvp);
fprintf('  Alumina Shell: %.2f nm (Palik)\n', opt.t_ox);
fprintf('  Medium RI: %.4f\n', opt.n_med);
fprintf('=====================================================\n');

% Set up dielectric functions table
% 1: surrounding medium
% 2: aluminum core
% 3: PVP shell
% 4: alumina oxide shell
eps_med = opt.n_med^2;
eps_pvp = 1.5274^2;
epstab = { epsconst(eps_med), epstable('aluminum.dat'), epsconst(eps_pvp), epstable('aluminum_oxide.dat') };

op = env.op;

% Build particle geometry
if strcmpi(opt.type, 'sphere')
    r_core = opt.size / 2;
    p_core = trisphere(144, 2 * r_core);
    
    if opt.t_pvp > 0
        r_pvp = r_core + opt.t_pvp;
        r_ox  = r_pvp + opt.t_ox;
        p_pvp = trisphere(144, 2 * r_pvp);
        p_ox  = trisphere(144, 2 * r_ox);
        
        % Composite particle with 3 nested boundaries
        comp_p = comparticle(epstab, {p_core, p_pvp, p_ox}, [2, 3; 3, 4; 4, 1], 1, 2, 3, op);
    else
        r_ox = r_core + opt.t_ox;
        p_ox = trisphere(144, 2 * r_ox);
        comp_p = comparticle(epstab, {p_core, p_ox}, [2, 4; 4, 1], 1, 2, op);
    end
    
    % Impact parameters: Center, R/2, R
    impact_pts = [0, 0; r_core * 0.5, 0; r_core * 0.98, 0];
    impact_labels = {'Center (b=0)', 'R/2', 'R'};
    
elseif strcmpi(opt.type, 'cube_conformal')
    len_core = opt.size;
    p_core = tricube(12, len_core, 'e', 0.15);
    
    if opt.t_pvp > 0
        len_pvp = len_core + 2 * opt.t_pvp;
        len_ox  = len_pvp + 2 * opt.t_ox;
        p_pvp = tricube(12, len_pvp, 'e', 0.15);
        p_ox  = tricube(12, len_ox,  'e', 0.15);
        comp_p = comparticle(epstab, {p_core, p_pvp, p_ox}, [2, 3; 3, 4; 4, 1], 1, 2, 3, op);
    else
        len_ox = len_core + 2 * opt.t_ox;
        p_ox = tricube(12, len_ox, 'e', 0.15);
        comp_p = comparticle(epstab, {p_core, p_ox}, [2, 4; 4, 1], 1, 2, op);
    end
    
    % Impact points: Corner, Edge, Face center
    half_L = len_core / 2;
    impact_pts = [half_L * 0.95, half_L * 0.95; half_L * 0.95, 0; 0, 0];
    impact_labels = {'Corner', 'Edge', 'Face'};
    
else % cube_convex
    len_core = opt.size;
    p_core = tricube(12, len_core, 'e', 0.15);
    
    half_L = len_core / 2;
    r_convex_pvp = half_L + opt.t_pvp;
    r_convex_ox  = r_convex_pvp + opt.t_ox;
    
    p_pvp = trisphere(144, 2 * r_convex_pvp);
    p_ox  = trisphere(144, 2 * r_convex_ox);
    
    comp_p = comparticle(epstab, {p_core, p_pvp, p_ox}, [2, 3; 3, 4; 4, 1], 1, 2, 3, op);
    
    impact_pts = [half_L * 0.95, half_L * 0.95; half_L * 0.95, 0; 0, 0];
    impact_labels = {'Corner', 'Edge', 'Face'};
end

% Energy points
ene = linspace(opt.ene_range(1), opt.ene_range(2), opt.n_ene);
units;
enei = eV2nm ./ ene;

% Solve BEM for Optical Scattering & EELS
bem = bemsolver(comp_p, op);
exc_plane = planewave([1, 0, 0], [0, 0, 1], op);

[width, vel] = deal(0.5, eelsbase.ene2vel(200e3));
exc_eels = electronbeam(comp_p, impact_pts, width, vel, op);

sca = zeros(size(ene));
psurf = zeros(size(impact_pts, 1), length(ene));

fprintf('Solving Maxwell boundary integrals across %d energy steps...\n', length(ene));
for i = 1:length(ene)
    % Plane wave excitation for scattering
    sig_plane = bem \ exc_plane(comp_p, enei(i));
    sca(i) = exc_plane.sca(sig_plane);
    
    % Electron beam excitation for EELS
    sig_eels = bem \ exc_eels(enei(i));
    psurf(:, i) = exc_eels.loss(sig_eels);
end
fprintf('BEM solve completed successfully.\n');

% Package results
results.ene = ene;
results.enei = enei;
results.scattering = sca;
results.psurf = psurf;
results.impact_labels = impact_labels;
results.impact_pts = impact_pts;
results.particle = comp_p;

% Plot if requested
if opt.plot_fig
    figure('Color', 'w', 'Units', 'pixels', 'Position', [150, 150, 800, 500]);
    yyaxis left
    plot(ene, psurf(1, :)*1e3, 'k-s', 'LineWidth', 1.8, 'MarkerSize', 6); hold on;
    plot(ene, psurf(2, :)*1e3, 'r-o', 'LineWidth', 1.8, 'MarkerSize', 6);
    plot(ene, psurf(3, :)*1e3, 'g-^', 'LineWidth', 1.8, 'MarkerSize', 6);
    ylabel('Loss probability (eV^{-1}) \times 10^{-3}', 'FontSize', 12, 'FontWeight', 'bold');
    
    yyaxis right
    plot(ene, sca / 1e4, 'b-', 'LineWidth', 2.2);
    ylabel('Scattering cross section (nm^2) \times 10^4', 'FontSize', 12, 'FontWeight', 'bold');
    
    xlabel('Energy (eV)', 'FontSize', 12, 'FontWeight', 'bold');
    legend([impact_labels, {'Scattering'}], 'Location', 'best');
    title(sprintf('Automated BEM: %s (PVP=%.1fnm, Ox=%.1fnm, n=%.2f)', ...
          opt.type, opt.t_pvp, opt.t_ox, opt.n_med), 'FontSize', 12, 'FontWeight', 'bold');
    grid on;
end
end
