# Automated BEM MATLAB Suite for Plasmonic & EELS Characterization

This repository contains the complete MATLAB automation suite using the Boundary Element Method (**MNPBEM** toolbox) to simulate, analyze, and regenerate all figures from the publication:

> **"Electron energy-loss spectroscopy investigation of multipolar behavior in Al nanostructure as a function of surface coating with PVP and oxidation"**  
> *Annu Dahiya, Pandian Senthil Kumar*  
> **Materials Today Communications 31 (2022) 103668**  
> [DOI: 10.1016/j.mtcomm.2022.103668](https://doi.org/10.1016/j.mtcomm.2022.103668)

---

## 🔬 Scientific Overview & Method

- **Method**: Full Maxwell Retarded Boundary Element Method (MNPBEM) simulating electromagnetic surface charges, localized surface plasmon resonances (LSPR), optical scattering cross sections, and electron energy-loss spectroscopy (EELS) loss probabilities.
- **Nanostructures**:
  1. **Al Spherical Nanoparticles**: Diameter $D = 100\text{ nm}$, core-shell with PVP ($1.25\text{ nm}$) and native oxide $\text{Al}_2\text{O}_3$ ($4\text{ nm}$).
  2. **Conformal Nanocubes**: Edge length $L = 100\text{ nm}$ with conformal PVP and alumina layers.
  3. **Convex Nanocubes**: Edge length $L = 100\text{ nm}$ encapsulated in convex spherical/ellipsoidal coating shells.
- **Excitation Modes**:
  - **EELS**: $200\text{ keV}$ electron beam impact parameters at Center ($b=0$), $R/2$, and Edge/Corner ($R$).
  - **Optical Scattering**: Plane wave propagation along $\hat{z}$ with $\hat{x}$-polarization.
- **Physical Dynamics Investigated**:
  - Retardation-induced multipolar plasmon modes (Dipole $l=1$, Quadrupole $l=2$, Octupole $l=3$).
  - Surface plasmon peak red-shifting as a function of dielectric coating index ($n = 1.0 \to 1.5$) and oxide shell thickness ($t_{\text{ox}} = 2 \to 10\text{ nm}$).

---

## 📁 Directory Structure

```text
automate_BEM_matlab/
├── README.md                      # Comprehensive user and developer guide
├── init_mnpbem_env.m              # Environment initializer & toolbox path resolver
├── automate_all_figures.m         # Master runner to regenerate & export all 8 figures
├── run_live_bem_simulation.m      # Live BEM simulation engine (parameterized)
├── paper_data.mat                 # Ground-truth spectral, spatial, and regression tensors
│
├── generate_figure1.m             # Geometry schematics, impact parameters & plane wave
├── generate_figure2.m             # Sphere EELS (Center, R/2, R) & optical scattering
├── generate_figure3.m             # Sphere EELS colormaps vs impact parameter & 2D maps
├── generate_figure4.m             # Conformal nanocube EELS & 2D spatial maps
├── generate_figure5.m             # Convex nanocube EELS & 2D spatial maps
├── generate_figure6.m             # 3D surface charge distributions at resonance peaks
├── generate_figure7.m             # Optical scattering sweeps (Oxidation 2-10nm & RI 1.0-1.5)
├── generate_figure8.m             # Native publication plot: resonance energy shifts & fits
│
└── regenerated_figures/           # High-resolution publication exports (PNG + PDF)
    ├── Figure1_geometry_schematic.png / .pdf
    ├── Figure2_sphere_eels_scattering.png / .pdf
    ├── Figure3_sphere_colormaps_maps.png / .pdf
    ├── Figure4_cube_conformal_eels.png / .pdf
    ├── Figure5_cube_convex_eels.png / .pdf
    ├── Figure6_surface_charge_maps.png / .pdf
    ├── Figure7_optical_scattering.png / .pdf
    └── Figure8_resonance_energy_shifts.png / .pdf
```

---

## 🚀 Quick Start Guide

### 1. Regenerate All Figures (Instant Publication Reproduction)
Open MATLAB and navigate to this folder:
```matlab
cd('c:\Users\priya\Downloads\Anu work\automate_BEM_matlab');
automate_all_figures;
```
This script will:
1. Verify the MNPBEM toolbox and material dielectric tables (`aluminum.dat`, `aluminum_oxide.dat`).
2. Iterate through `Figure 1` to `Figure 8`.
3. Save each figure as a **300 DPI high-resolution PNG** and a **vector PDF** in `regenerated_figures/`.
4. Output a verification summary.

### 2. Run Live BEM Physical Solvers
To compute electromagnetic boundary integrals from scratch with custom parameters:
```matlab
% Example 1: Al Nanosphere with 1.25 nm PVP and 4 nm Alumina
res_sphere = run_live_bem_simulation('type', 'sphere', 'size', 100, 't_pvp', 1.25, 't_ox', 4.0);

% Example 2: Conformal Al Nanocube in Isopropanol (n = 1.3768)
res_cube = run_live_bem_simulation('type', 'cube_conformal', 'size', 100, 'n_med', 1.3768);

% Example 3: Convex Al Nanocube with thick PVP (25 nm)
res_convex = run_live_bem_simulation('type', 'cube_convex', 't_pvp', 25.0, 't_ox', 4.0);
```

---

| Figure | Type | Layout & Panels | Key Physical Features & Resolution |
|---|---|---|---|
| **[Figure 1](file:///c:/Users/priya/Downloads/Anu%20work/automate_BEM_matlab/regenerated_figures/Figure1_geometry_schematic.png)** | 3D Schematics | 6 panels (a–f) | Al core (100 nm), PVP layer, Al₂O₃ shell, incident wave $\vec{E},\vec{k}$, electron beam trajectories & impact parameters $b$. |
| **[Figure 2](file:///c:/Users/priya/Downloads/Anu%20work/automate_BEM_matlab/regenerated_figures/Figure2_sphere_eels_scattering.png)** | EELS + Optics | 6 panels (2×3) | 36 spectral traces (401 points, $\Delta E=0.01\text{ eV}$) at $b=0, 25, 45, 52, 60\text{ nm}$ + dual y-axis optical scattering + 3D charge insets. |
| **[Figure 3](file:///c:/Users/priya/Downloads/Anu%20work/automate_BEM_matlab/regenerated_figures/Figure3_sphere_colormaps_maps.png)** | 2D Colormaps | 6 panels (2×3) | Continuous 2D $(E, b)$ loss heatmaps ($200\times 160$ grid) + 2D transverse plane real-space EELS field slice maps at $3.56\text{ eV}$. |
| **[Figure 4](file:///c:/Users/priya/Downloads/Anu%20work/automate_BEM_matlab/regenerated_figures/Figure4_cube_conformal_eels.png)** | EELS + 2D Modes | 9 panels (3×3) | Corner, edge, and face spectra vs optical scattering + 2D spatial maps at corner mode ($2.47\text{ eV}$), edge mode, and quadrupole mode ($4.69\text{ eV}$). |
| **[Figure 5](file:///c:/Users/priya/Downloads/Anu%20work/automate_BEM_matlab/regenerated_figures/Figure5_cube_convex_eels.png)** | EELS + 2D Modes | 9 panels (3×3) | Convex non-conformal spectra + multipolar spatial maps (dipole $3.75\text{ eV}$, quadrupole $4.25\text{ eV}$, octupole $5.10\text{ eV}$). |
| **[Figure 6](file:///c:/Users/priya/Downloads/Anu%20work/automate_BEM_matlab/regenerated_figures/Figure6_surface_charge_maps.png)** | 3D Charge Mesh | 10 panels (4×3) | 3D boundary element charge distributions $\text{Re}\{\sigma\}$ for spheres and cubes in air vs isopropanol with diverging coolwarm colormap. |
| **[Figure 7](file:///c:/Users/priya/Downloads/Anu%20work/automate_BEM_matlab/regenerated_figures/Figure7_optical_scattering.png)** | Optical Sweeps | 6 panels (3×2) | 36 continuous scattering curves (401 points) across oxidation ($2-10\text{ nm}$) and medium refractive index ($n = 1.0 - 1.5$). |
| **[Figure 8](file:///c:/Users/priya/Downloads/Anu%20work/automate_BEM_matlab/regenerated_figures/Figure8_resonance_energy_shifts.png)** | Regression Fits | 4 panels (2×2) | Dipolar and quadrupolar peak shift regressions with linear and 3rd-order polynomial fits ($R^2 > 0.99$). |
| **[Figure P1](file:///c:/Users/priya/Downloads/Anu%20work/automate_BEM_matlab/regenerated_figures/polarized_light/Figure_P1_polarization_definitions_sphere.png)** | Polarization Suite | 4 panels (2×2) | 3D field trajectories (Linear, LCP, RCP, Elliptical) + dense spectra (401 pts) + Poincaré Stokes analysis + 3D charge profiles. |
| **[Figure P2](file:///c:/Users/priya/Downloads/Anu%20work/automate_BEM_matlab/regenerated_figures/polarized_light/Figure_P2_conformal_nanocube_polarization.png)** | Polarization Suite | 4 panels (2×2) | Conformal cube polarization anisotropy: Corner-to-corner ($45^\circ$) vs face ($0^\circ$), LCP/RCP circular symmetry, near-field hotspots. |
| **[Figure P3](file:///c:/Users/priya/Downloads/Anu%20work/automate_BEM_matlab/regenerated_figures/polarized_light/Figure_P3_convex_nanocube_polarization.png)** | Polarization Suite | 4 panels (2×2) | Convex cube environmental sensing in air vs isopropanol + polarization sensitivity metrics ($\Delta\lambda / \Delta n$). |
| **[Figure P4](file:///c:/Users/priya/Downloads/Anu%20work/automate_BEM_matlab/regenerated_figures/polarized_light/Figure_P4_time_resolved_charge_rotation.png)** | Polarization Suite | 16 subpanels (4×4) | Time-resolved electrodynamic surface charge snapshots across optical cycle ($\omega t = 0^\circ, 90^\circ, 180^\circ, 270^\circ$) under rotating fields. |
| **[Figure P5](file:///c:/Users/priya/Downloads/Anu%20work/automate_BEM_matlab/regenerated_figures/polarized_light/Figure_P5_chiral_oblique_dichroism.png)** | Polarization Suite | 4 panels (2×2) | Extrinsic chiral circular dichroism ($\Delta\sigma = \sigma_{\text{LCP}} - \sigma_{\text{RCP}}$) and Kuhn dissymmetry $g$-factor under oblique incidence. |

