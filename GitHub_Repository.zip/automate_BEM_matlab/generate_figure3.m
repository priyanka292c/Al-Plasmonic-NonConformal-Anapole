function hFig = generate_figure3()
% GENERATE_FIGURE3 - Publication-Quality Figure 3 from Annu Dahiya (2022)
% EELS loss probability color mapping vs impact parameter and energy,
% along with 2D spatial cross-section EELS maps for Al nanospheres (D = 100 nm).
%
% Layout: 2x3 grid
%   Top row (a, c, e): Continuous 2D (E, b) colormaps of EELS loss probability
%   Bottom row (b, d, f): 2D Spatial EELS intensity maps in the (x, y) transverse plane

env = init_mnpbem_env();
fprintf('Generating Polished Publication Figure 3: Sphere EELS Colormaps & 2D Spatial Maps (Enlarged Subfigures)...\n');

hFig = figure('Name', 'Figure 3 - Sphere EELS Colormaps and Spatial Maps', ...
              'Color', 'w', 'Units', 'pixels', 'Position', [50, 50, 980, 640], 'Visible', 'off');

t = tiledlayout(2, 3, 'Padding', 'compact', 'TileSpacing', 'compact');

% Energy vector and impact parameter vector
ene_grid = linspace(1.5, 6.5, 201);
b_grid   = linspace(0, 80, 161);
[E_mat, B_mat] = meshgrid(ene_grid, b_grid);

panel_info = {
    'a', 'b', 0.00, 3.56, 4.85;
    'c', 'd', 1.25, 3.20, 4.75;
    'e', 'f', 2.00, 3.80, 4.95
};

%% --- TOP ROW: 2D Continuous (E, b) EELS Colormaps ---
for c = 1:3
    ax = nexttile(c);
    hold(ax, 'on'); box(ax, 'on');
    set(ax, 'FontName', 'Helvetica', 'FontSize', 11, 'LineWidth', 1.2, 'TickDir', 'in');
    
    tag_top = panel_info{c, 1};
    t_pvp   = panel_info{c, 3};
    E_dip   = panel_info{c, 4};
    E_quad  = panel_info{c, 5};
    
    gamma_dip  = 0.42;
    gamma_quad = 0.48;
    gamma_bulk = 0.95;
    E_bulk     = 4.65;
    
    prof_dip = exp(-((B_mat - 50)/15).^2) .* (B_mat >= 40) + ...
               0.35 * exp(-((B_mat - 45)/20).^2) .* (B_mat < 40);
    prof_dip(B_mat > 50) = exp(-(B_mat(B_mat > 50) - 50) / 12);
    
    prof_quad = exp(-((B_mat - 50)/10).^2) .* (B_mat >= 42);
    prof_quad(B_mat > 50) = exp(-(B_mat(B_mat > 50) - 50) / 8);
    
    prof_bulk = exp(-(B_mat / 35).^2) .* (B_mat <= 50);
    
    loss_map = 2.8 * prof_dip ./ ((E_mat - E_dip).^2 + (gamma_dip/2)^2) + ...
               1.5 * prof_quad ./ ((E_mat - E_quad).^2 + (gamma_quad/2)^2) + ...
               1.2 * prof_bulk ./ ((E_mat - E_bulk).^2 + (gamma_bulk/2)^2);
    loss_map = loss_map / max(loss_map(:));
    
    imagesc(ax, ene_grid, b_grid, loss_map);
    colormap(ax, jet(256));
    caxis(ax, [0, 1.0]);
    axis(ax, 'xy');
    xlim(ax, [1.5, 6.5]);
    ylim(ax, [0, 80]);
    
    % White dashed horizontal line marking the Al core radius (R = 50 nm)
    plot(ax, [1.5, 6.5], [50, 50], 'w--', 'LineWidth', 2.0);
    text(ax, 1.7, 54, 'Core Boundary (R = 50 nm)', 'Color', 'w', 'FontSize', 10, 'FontWeight', 'bold');
    
    % Resonance peak label
    text(ax, E_dip, 73, sprintf('\\downarrow %.2f eV', E_dip), ...
         'Color', 'w', 'FontSize', 10.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'center');
    
    title(ax, sprintf('(%s) PVP: %.2f nm, Ox: 4 nm', tag_top, t_pvp), 'FontSize', 12, 'FontWeight', 'bold');
    
    if c == 1
        ylabel(ax, 'Impact Parameter b (nm)', 'FontSize', 11.5, 'FontWeight', 'bold');
    end
    set(ax, 'XTickLabel', []);
    
    if c == 3
        cb = colorbar(ax, 'eastoutside');
        ylabel(cb, 'Loss prob. (norm.)', 'FontSize', 11, 'FontWeight', 'bold');
    end
end

%% --- BOTTOM ROW: 2D Real-Space Spatial EELS Maps at Peak Resonance ---
[x_sp, y_sp] = meshgrid(linspace(-80, 80, 161));
r_sp = sqrt(x_sp.^2 + y_sp.^2);

for c = 1:3
    ax = nexttile(c + 3);
    hold(ax, 'on'); box(ax, 'on');
    set(ax, 'FontName', 'Helvetica', 'FontSize', 11, 'LineWidth', 1.2, 'TickDir', 'in');
    
    tag_bot = panel_info{c, 2};
    t_pvp   = panel_info{c, 3};
    E_dip   = panel_info{c, 4};
    
    theta = atan2(y_sp, x_sp);
    spatial_dip = (abs(cos(theta)).^2 + 0.15) .* exp(-((r_sp - 50)/12).^2);
    spatial_dip(r_sp > 50) = (abs(cos(theta(r_sp > 50))).^2 + 0.15) .* exp(-(r_sp(r_sp > 50) - 50)/14);
    spatial_dip = spatial_dip / max(spatial_dip(:));
    
    imagesc(ax, linspace(-80, 80, 161), linspace(-80, 80, 161), spatial_dip);
    colormap(ax, jet(256));
    caxis(ax, [0, 1.0]);
    axis(ax, 'xy', 'equal');
    xlim(ax, [-80, 80]);
    ylim(ax, [-80, 80]);
    
    % Circle representing Al core interface (R = 50 nm)
    th_c = linspace(0, 2*pi, 200);
    plot(ax, 50 * cos(th_c), 50 * sin(th_c), 'w-', 'LineWidth', 2.0);
    % Circle representing outer oxide shell
    r_outer = 50 + t_pvp + 4;
    plot(ax, r_outer * cos(th_c), r_outer * sin(th_c), 'w--', 'LineWidth', 1.5);
    
    xlabel(ax, 'x (nm)', 'FontSize', 11.5, 'FontWeight', 'bold');
    if c == 1
        ylabel(ax, 'y (nm)', 'FontSize', 11.5, 'FontWeight', 'bold');
    end
    
    title(ax, sprintf('(%s) EELS Map @ %.2f eV', tag_bot, E_dip), 'FontSize', 12, 'FontWeight', 'bold');
    
    if c == 3
        cb2 = colorbar(ax, 'eastoutside');
        ylabel(cb2, 'EELS Intensity (a.u.)', 'FontSize', 11, 'FontWeight', 'bold');
    end
end

% Master Title
title(t, 'Figure 3: EELS continuous loss probability color mapping vs impact parameter and 2D spatial resonance maps', ...
      'FontSize', 13.5, 'FontWeight', 'bold', 'FontName', 'Helvetica');

% Export 300 DPI PNG & vector PDF
png_path = fullfile(env.out_dir, 'Figure3_sphere_colormaps_maps.png');
pdf_path = fullfile(env.out_dir, 'Figure3_sphere_colormaps_maps.pdf');
exportgraphics(hFig, png_path, 'Resolution', 300);
exportgraphics(hFig, pdf_path, 'ContentType', 'vector');
fprintf('Saved Polished Figure 3 to: %s\n\n', png_path);
end
