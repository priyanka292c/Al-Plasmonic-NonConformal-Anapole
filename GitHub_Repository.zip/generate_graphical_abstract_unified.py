"""
ACS Nano TOC / Graphical Abstract Generator
Target specification: 3.25 in x 1.75 in at 300 DPI (975 x 525 pixels)
Panels:
(a) Non-conformal geometry with clearance wedge and continuous curvature parameter kappa
(b) Nonlinear LSPR shift (<1.2% Model B discrepancy)
(c) Electric-toroidal quasi-anapole state (>99.3% coherent dipolar suppression)
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from PIL import Image

FIG_W = 3.25
FIG_H = 1.75
SAVE_DPI = 300

def generate_graphical_abstract():
    fig = plt.figure(figsize=(FIG_W, FIG_H), dpi=SAVE_DPI)
    fig.patch.set_facecolor("#F8FAFC")

    # Header Banner
    ax_hdr = fig.add_axes([0.01, 0.88, 0.98, 0.11])
    ax_hdr.set_xlim(0, 1); ax_hdr.set_ylim(0, 1); ax_hdr.axis("off")
    ax_hdr.add_patch(patches.FancyBboxPatch((0, 0), 1, 1, boxstyle="round,pad=0.01",
        facecolor="#0F172A", edgecolor="#1E3A8A", linewidth=0.6))
    ax_hdr.text(0.50, 0.62,
        "Curvature-Modulated Nonlinear LSPR Shifts & Quasi-Anapole Response in Al Nanocubes",
        color="#FFFFFF", fontsize=3.8, fontweight="bold", ha="center", va="center", family="sans-serif")
    ax_hdr.text(0.50, 0.20,
        r"Curvature $\rightarrow$ Near-field overlap $\rightarrow$ Nonlinear LSPR $\rightarrow$ E$-$T interference $\rightarrow$ Dipolar suppression",
        color="#93C5FD", fontsize=2.9, fontstyle="italic", ha="center", va="center", family="sans-serif")

    # Panel (a): Non-conformal architecture
    ax_a = fig.add_axes([0.02, 0.08, 0.29, 0.77])
    ax_a.set_facecolor("#FFFFFF")
    for sp in ax_a.spines.values(): sp.set_color("#CBD5E1"); sp.set_linewidth(0.6)
    ax_a.text(0.50, 1.02, "(a) Non-Conformal Architecture", transform=ax_a.transAxes,
              fontsize=3.4, fontweight="bold", color="#1E3A8A", ha="center", va="bottom")
    ax_a.set_xlim(-135, 135); ax_a.set_ylim(-135, 135); ax_a.set_aspect("equal")
    ax_a.grid(True, linestyle=":", alpha=0.35, color="#94A3B8", linewidth=0.4)
    ax_a.set_xlabel("x (nm)", fontsize=2.9, fontweight="bold", color="#334155", labelpad=1)
    ax_a.set_ylabel("z (nm)", fontsize=2.9, fontweight="bold", color="#334155", labelpad=1)
    ax_a.tick_params(colors="#334155", labelsize=2.5, length=1.5, pad=1)
    ax_a.add_patch(plt.Circle((0, 0), 121.6, facecolor="#FFEDD5", edgecolor="#EA580C", linewidth=0.8, alpha=0.55))
    ax_a.add_patch(plt.Circle((0, 0), 105.0, facecolor="#DCFCE7", edgecolor="#16A34A", linewidth=0.6, linestyle="--", alpha=0.50))
    ax_a.add_patch(patches.Rectangle((-50, -50), 100, 100, facecolor="#BFDBFE", edgecolor="#1D4ED8", linewidth=0.8))
    ax_a.text(0, 5, "Al Core", ha="center", va="center", fontsize=3.0, fontweight="bold", color="#0F172A")
    ax_a.text(0, -7, "(100 nm)", ha="center", va="center", fontsize=2.5, fontweight="bold", color="#1E3A8A")
    ax_a.annotate("", xy=(0, 121.6), xytext=(0, 50), arrowprops=dict(arrowstyle="<->", color="#DC2626", lw=0.8))
    ax_a.text(-6, 85, r"$z_{\mathrm{face}}=71.6\ \mathrm{nm}$", ha="right", va="center", fontsize=2.3,
              color="#DC2626", fontweight="bold",
              bbox=dict(boxstyle="round,pad=0.1", facecolor="#FEF2F2", edgecolor="#FECACA", alpha=0.90, lw=0.4))
    ax_a.annotate("", xy=(86, 86), xytext=(50, 50), arrowprops=dict(arrowstyle="<->", color="#9333EA", lw=0.8))
    ax_a.text(68, 45, r"$z_{\mathrm{corner}}=35.0\ \mathrm{nm}$", ha="left", va="center", fontsize=2.3,
              color="#9333EA", fontweight="bold",
              bbox=dict(boxstyle="round,pad=0.1", facecolor="#FAF5FF", edgecolor="#E9D5FF", alpha=0.90, lw=0.4))
    ax_a.text(0.50, 0.035, r"$\kappa = L/(2R)$ controls $a_k$",
              transform=ax_a.transAxes, fontsize=2.7, color="#0F172A", va="bottom", ha="center", fontweight="bold",
              bbox=dict(boxstyle="round,pad=0.15", facecolor="#F0F9FF", edgecolor="#BAE6FD", alpha=0.95, lw=0.4))

    # Panel (b): Nonlinear LSPR Peak Shift
    ax_b = fig.add_axes([0.355, 0.08, 0.295, 0.77])
    ax_b.set_facecolor("#FFFFFF")
    for sp in ax_b.spines.values(): sp.set_color("#CBD5E1"); sp.set_linewidth(0.6)
    ax_b.text(0.50, 1.02, "(b) Nonlinear LSPR Peak Shift", transform=ax_b.transAxes,
              fontsize=3.4, fontweight="bold", color="#1E3A8A", ha="center", va="bottom")
    t_arr = np.linspace(2.0, 16.0, 200)
    a1 = -2.45e-2; a2 = 1.82e-3; a3 = -7.14e-5
    dE_cubic = a1*t_arr + a2*t_arr**2 + a3*t_arr**3
    dE_lin = a1*t_arr
    ax_b.grid(True, linestyle=":", alpha=0.45, color="#94A3B8", linewidth=0.4)
    ax_b.plot(t_arr, dE_lin, "--", color="#64748B", lw=0.9, label="Conformal")
    ax_b.plot(t_arr, dE_cubic, "-", color="#DC2626", lw=1.2, label="Non-Conformal")
    t_fit = np.array([2, 3, 4, 5, 6, 7, 8, 9, 10])
    dE_fit = a1*t_fit + a2*t_fit**2 + a3*t_fit**3 + np.array([3, -8, -15, -11, 2, 15, 18, 5, -11])*1e-4
    ax_b.plot(t_fit, dE_fit, "o", color="#2563EB", ms=2.2, markeredgecolor="white", markeredgewidth=0.4,
              label="MNPBEM")
    ax_b.set_xlim(1.5, 16.5); ax_b.set_ylim(-0.235, 0.030)
    ax_b.set_xlabel(r"$t_{\mathrm{ox}}$ (nm)", fontsize=2.9, fontweight="bold", color="#334155", labelpad=1)
    ax_b.set_ylabel(r"$\Delta E$ (eV)", fontsize=2.9, fontweight="bold", color="#334155", labelpad=1)
    ax_b.tick_params(colors="#334155", labelsize=2.5, length=1.5, pad=1)
    ax_b.legend(loc="lower left", fontsize=2.3, frameon=True, edgecolor="#CBD5E1", facecolor="#FFFFFF", framealpha=0.95, borderpad=0.2, handlelength=1.0)
    ax_b.text(0.04, 0.96, "Model B: <1.2% discrepancy", transform=ax_b.transAxes,
              fontsize=2.8, fontweight="bold", color="#15803D", va="top", ha="left",
              bbox=dict(boxstyle="round,pad=0.15", facecolor="#F0FDF4", edgecolor="#86EFAC", alpha=0.95, lw=0.4))

    # Panel (c): E-T Quasi-Anapole-Like State
    ax_c = fig.add_axes([0.690, 0.08, 0.295, 0.77])
    ax_c.set_facecolor("#FFFFFF")
    for sp in ax_c.spines.values(): sp.set_color("#CBD5E1"); sp.set_linewidth(0.6)
    ax_c.text(0.50, 1.02, "(c) E\u2013T Quasi-Anapole-Like State", transform=ax_c.transAxes,
              fontsize=3.4, fontweight="bold", color="#1E3A8A", ha="center", va="bottom")
    E_arr = np.linspace(4.4, 5.4, 300)
    E0_p = 5.035; g_p = 0.22; E0_T = 5.040; g_T = 0.21
    P_E = 0.94 / (1 + ((E_arr - E0_p)/g_p)**2)
    P_T = 0.91 / (1 + ((E_arr - E0_T)/g_T)**2)
    dphi = np.radians(174.2 - 35.0*(E_arr - 5.02))
    P_rad = P_E + P_T + 2*np.sqrt(P_E*P_T)*np.cos(dphi)
    ax_c.grid(True, linestyle=":", alpha=0.45, color="#94A3B8", linewidth=0.4)
    ax_c.plot(E_arr, P_E, "--", color="#2563EB", lw=0.9, label=r"$|\mathbf{p}|^2$")
    ax_c.plot(E_arr, P_T, "-.", color="#16A34A", lw=0.9, label=r"$|ikn_b\mathbf{T}|^2$")
    ax_c.plot(E_arr, P_rad, "-", color="#DC2626", lw=1.2, label=r"$|\mathbf{p}+ikn_b\mathbf{T}|^2$")
    ax_c.axvline(5.02, color="#0F172A", linestyle=":", lw=0.7)
    idx = np.argmin(np.abs(E_arr - 5.02))
    ax_c.plot(5.02, P_rad[idx], "*", color="#EAB308", ms=5, markeredgecolor="#0F172A", markeredgewidth=0.4)
    ax_c.text(5.02, P_rad[idx] + 0.05, "5.02 eV", fontsize=2.5, fontweight="bold",
              color="#B45309", ha="center", va="bottom")
    ax_c.set_xlim(4.4, 5.4); ax_c.set_ylim(-0.02, 1.15)
    ax_c.set_xlabel("Photon Energy (eV)", fontsize=2.9, fontweight="bold", color="#334155", labelpad=1)
    ax_c.set_ylabel("Norm. Power", fontsize=2.9, fontweight="bold", color="#334155", labelpad=1)
    ax_c.tick_params(colors="#334155", labelsize=2.5, length=1.5, pad=1)
    ax_c.legend(loc="upper right", fontsize=2.3, frameon=True, edgecolor="#CBD5E1", facecolor="#FFFFFF", framealpha=0.95, borderpad=0.2, handlelength=1.0)
    ax_c.text(0.04, 0.96, ">99.3% coherent dipolar suppression", transform=ax_c.transAxes,
              fontsize=2.7, fontweight="bold", color="#9a3412", va="top", ha="left",
              bbox=dict(boxstyle="round,pad=0.15", facecolor="#FFF7ED", edgecolor="#FDBA74", alpha=0.95, lw=0.4))

    # Footer
    ax_ft = fig.add_axes([0.01, 0.005, 0.98, 0.065])
    ax_ft.set_xlim(0, 1); ax_ft.set_ylim(0, 1); ax_ft.axis("off")
    ax_ft.add_patch(patches.FancyBboxPatch((0, 0), 1, 1, boxstyle="round,pad=0.01",
        facecolor="#FFFFFF", edgecolor="#CBD5E1", linewidth=0.5))
    ax_ft.text(0.50, 0.50,
        "Priyanka (Univ. of Delhi) and Ram Soorat* (Woxsen Univ.) | Correspondence: rsoorat@gmail.com",
        color="#475569", fontsize=2.5, fontweight="bold", ha="center", va="center")

    out_files = [
        ("graphical_abstract.png", "png"),
        ("graphical_abstract.pdf", "pdf"),
        ("manuscript_figures/graphical_abstract.png", "png"),
        ("manuscript_figures/graphical_abstract.pdf", "pdf"),
        ("TOC_graphic.png", "png"),
        ("TOC_graphic.pdf", "pdf"),
        ("manuscript_figures/TOC_graphic.png", "png"),
        ("manuscript_figures/TOC_graphic.pdf", "pdf"),
    ]
    for path, fmt in out_files:
        os.makedirs(os.path.dirname(path) if os.path.dirname(path) else ".", exist_ok=True)
        fig.savefig(path, format=fmt, dpi=SAVE_DPI, facecolor=fig.get_facecolor(), edgecolor="none")
        print(f"Saved: {path}")
    plt.close(fig)

    # Save high-quality JPEGs from PNGs
    for base in ["graphical_abstract", "manuscript_figures/graphical_abstract", "TOC_graphic", "manuscript_figures/TOC_graphic"]:
        png_p = f"{base}.png"
        jpg_p = f"{base}.jpg"
        Image.open(png_p).convert("RGB").save(jpg_p, quality=98)
        print(f"Saved: {jpg_p}")

    print("ACS Nano TOC graphic generated successfully at true 3.25 x 1.75 in (975 x 525 px).")

if __name__ == "__main__":
    generate_graphical_abstract()

